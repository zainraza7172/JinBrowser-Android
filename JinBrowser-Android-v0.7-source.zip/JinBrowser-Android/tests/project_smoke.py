"""v0.7 structural smoke tests; complements Android SDK compile & device tests."""
from pathlib import Path
from xml.etree import ElementTree as ET
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/jinbrowser/app'
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
perms={tag.get(ns+'name') for tag in manifest.findall('uses-permission')}
needed={'android.permission.INTERNET','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_DATA_SYNC',
        'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.WAKE_LOCK'}
assert needed<=perms,needed-perms
app=manifest.find('application')
activities={el.get(ns+'name'):el for el in app.findall('activity')}
expected={'.MainActivity','.PrivateActivity','.DownloadActivity','.SettingsActivity','.HistoryActivity','.VpnActivity','.WelcomeActivity'}
assert expected<=activities.keys()
assert activities['.PrivateActivity'].get(ns+'process')==':private'
launchers=[a.get(ns+'name') for a in app.findall('activity') for f in a.findall('intent-filter')
          if any(cat.get(ns+'name')=='android.intent.category.LAUNCHER' for cat in f.findall('category'))]
assert launchers==['.WelcomeActivity'],launchers
service_names={s.get(ns+'name'):s for s in app.findall('service')}
assert {'.TurboDownloadService','.BackgroundAudioService'}<=service_names.keys()
assert service_names['.TurboDownloadService'].get(ns+'foregroundServiceType')=='dataSync'
assert service_names['.BackgroundAudioService'].get(ns+'foregroundServiceType')=='mediaPlayback'
for f in (root/'app/src/main/res').rglob('*.xml'):ET.parse(f)
assert "versionName '0.7.0'" in (root/'app/build.gradle').read_text()
main=(src/'MainActivity.java').read_text()
history=(src/'HistoryActivity.java').read_text()
welcome=(src/'WelcomeActivity.java').read_text()
audio=(src/'BackgroundAudioService.java').read_text()
shield=(src/'AdShield.java').read_text()
filterlist=(src/'FilterLists.java').read_text()
downloader=(src/'TurboDownloadService.java').read_text()
settings=(src/'SettingsActivity.java').read_text()
start=(root/'app/src/main/assets/start.html').read_text()
checks={
 'homepage URL dispatch':('"jin.home".equalsIgnoreCase(uri.getHost())','"/search".equals(uri.getPath())','navigate(uri.getQueryParameter("q")', 'loadDataWithBaseURL("https://jin.home/"'),
 'desktop mode persists':('"desktop_global"','desktopAddress(Tab t','setUserAgentString(wanted?desktopUserAgent():null)', 'authority("www.youtube.com")'),
 'history navigation':('HistoryActivity.class', 'startActivity(new Intent(this, HistoryActivity.class))'),
 'downloads':('Resume link (editable direct file URL)','TurboDownloadService.enqueue','ACTION_OPEN_DOCUMENT_TREE'),
 'site media':('registerReceiver(mediaControls','BackgroundAudioService.START','evaluateJavascript(script,null)'),
 'native onResume':('adShield.reload(this)','recreate();return;'),
}
for title,terms in checks.items():
    for term in terms: assert term in main,(title,term)
for term in ('"ts"','Search your history','Select','Delete selected','Clear last hour','Clear today','Clear all history'):
    assert term in history,term
for term in ('onboarding_done','RoleManager.ROLE_BROWSER','Not now','Get Started'):
    assert term in welcome,term
for term in ('Notification.MediaStyle','MediaSession','START_STICKY','sendToBrowser(STOP)'):
    assert term in audio,term
for term in ('FilterLists.load','youtubeScript','isThirdPartyAdPath','cosmeticScript'):
    assert term in shield,term
for term in ('EASYLIST','EASYPRIVACY','parseDomainRule','ATOMIC_MOVE'):
    assert term in filterlist,term
for term in ('START_STICKY','wakeLock.acquire','Android interrupted download · reconnecting','verifyExistingParts','ACTION_UPDATE'):
    assert term in downloader,term
for term in ('Home wallpaper','Update filter lists','Background audio','YouTube ad controls','Desktop mode'):
    assert term in settings,term
for term in ('id="search"','https://jin.home/search?q=','id="clock"','id="date"','id="weatherTemp"',
             '__RECENTS_JSON__','__WALLPAPER_MODE__','__WALLPAPER_INDEX__','id="wallChange"','https://api.open-meteo.com/'):
    assert term in start,term
assert 'Your space' not in start
for i in range(1,7): assert (root/f'app/src/main/assets/wallpaper/mountain_{i}.webp').is_file()
class ScriptCollector(HTMLParser):
    def __init__(self):super().__init__();self.scripts=[];self.in_script=False
    def handle_starttag(self,tag,attrs):
        if tag=='script':self.in_script=True
    def handle_endtag(self,tag):
        if tag=='script':self.in_script=False
    def handle_data(self,s):
        if self.in_script:self.scripts.append(s)
sc=ScriptCollector();sc.feed(start)
assert len(sc.scripts)==1
(root/'tests/home-script-check.js').write_text(sc.scripts[0].replace('__RECENTS_JSON__','[]').replace('__WALLPAPER_MODE__','daily').replace('__WALLPAPER_INDEX__','1'))
print('PASS: v0.7 manifest, welcome, premium home, daily scenes, search, history, desktop, ad shield, VPN, downloads and media checks')
