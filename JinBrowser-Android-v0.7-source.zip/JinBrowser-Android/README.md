# Jin Browser v0.7 — final build kit

## Next step to compile the APK

1. Upload `JinBrowser-Android-v0.7-source.zip` to https://github.com/zainraza7172/JinBrowser-Android/upload/main
2. Open https://github.com/zainraza7172/JinBrowser-Android/edit/main/.github/workflows/build-apk.yml and replace the entire YAML with `build-apk-v0.7.yml` contents; commit to main.
3. Open GitHub Actions > Build Jin Browser v0.7 APK and select the latest completed run. Download artifact `JinBrowser-v0.7-debug-APK`. Unzip to get `app-debug.apk`.

This source ZIP has top-level `JinBrowser-Android/` as required by the workflow. Do not upload the complete kit ZIP in place of the source ZIP.

## Changes from v0.6
- Original panda app icon; first-run welcome, then Android's real default-browser chooser, or Not now.
- Light/dark homepage with 6 offline original mountain images, daily/on-launch/fixed setting and manual change. Working middle search routes directly to Android native search/address navigation; real clock/date, selectable live Open-Meteo city weather when online. Removes Your space cards.
- Premium native history with search, per-row delete, multiple selection, clear last hour/today/all.
- Global desktop mode across tabs/sites with mobile YouTube host rewriting, supported website permitting.
- Built-in native Ad Shield, manual EasyList/EasyPrivacy domain subset update, site-specific allowlist, optional experimental YouTube controls. Not a full browser extension engine and not guaranteed to block all YouTube video ads.
- Existing multipart range downloader, partial file identity checks and Replace Resume Link; Android foreground service, resume interrupted non-private downloads after service recreation where allowed by OS. OS Force Stop or battery restrictions can stop downloads; no fixed network speed guarantee.
- Opt-in background media service with notification Play/Pause/Stop; website/Android limitations apply.
- Jin VPN screen links official VPN Gate public directory, but VPN Gate OpenVPN/L2TP configs are **not** compatible with Jin's built-in Android IKEv2 support. To use built-in VPN you must provide a genuine compatible IKEv2 VPN server and credentials. No automatic random free foreign IP.

## Validation status
Source XML, Java-independent calculations, JavaScript syntax and simulated homepage actions pass offline tests. **This machine has no Android SDK and has not compiled v0.7 APK.** GitHub Actions will compile it after source/workflow upload; Android on-device QA and VPN/server testing remain necessary. This is a debug build, not security-audited or Play-Store-signed. Do not use experimental browser for sensitive banking/passwords until further testing.
