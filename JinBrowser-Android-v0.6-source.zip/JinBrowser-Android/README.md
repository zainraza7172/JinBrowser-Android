# Jin Browser v0.6 — JIN RESUME 71

An original minimalist **Android browser** based on Android System WebView. The start page and native navigation are redesigned around the supplied home, bottom-menu and Settings references. The browser uses **Jin Browser** branding, not an imitation of Nexa or Firefox.

## What the code implements

- Original white alpine-themed start screen with a functioning main search field; native address bar with local suggestions and **opt-in** online autocomplete. Time/date are generated from the phone clock every second.
- Weather from Open-Meteo for a **manually selected city**. No location permission or fabricated readings. Select a city on the home screen; weather shows an explicit failure when offline. Before commercial launch review Open-Meteo's licensing.
- Theme-aware **Light / Dark / System** colors across the native shell and the HTML home, four-button footer (Back / Forward / Tabs / Menu), real native **bottom-up menu** and a separate **Settings** screen.
- Only actionable Settings are shown: search engine, start-page behavior, theme, optional suggestions, default desktop mode, configurable download connections, native Ad Shield, HTTPS-only browsing, external app-link preferences, selective data deletion, Android notification control, WebView remote debugging, default browser and engine info.
- **Jin Ad Shield:** optional request-domain filtering of known advertising and tracker hosts, blocked-redirect checks, a conservative cosmetic filter and per-site exceptions. Rule list is packaged offline and unit-tested. Unlike a full extension-based engine this is *not* a claim that every video ad, including all YouTube in-stream ads, can be blocked. Sites may break; disable the filter per site.
- **Jin VPN:** a real interface to Android's platform **IKEv2/IPsec** VPN manager on supported Android 11+ devices. It requires a valid VPN provider's server hostname, IKE identity, username and password, plus the user's Android consent. The app does **not** invent or bundle foreign servers, claim a random IP, or report connected until Android confirms it (Android 13+ supplies state). It does not retain the provider password in Jin's preferences; the Android VPN framework stores a provisioned profile.
- Existing resumable multi-connection foreground download engine, editable initial direct URL in the save popup, **Resume link** replacement from the Downloads screen, source-link copy, pause, retry, chunk verification and safe MediaStore/SAF file publishing. Same-size plus sample matching lowers corruption risk; it cannot prove arbitrary files identical. Servers must support HTTP byte ranges to resume in place.
- Independent private profile process, up to 12 live tab WebViews, per-tab close, HTTPS certificate rejection, Android file-upload picker, sharing, installed app links and Gmail app handoff. Tab URL restoration is available if Android kills the renderer, but pages may reload; Android will not guarantee permanently loaded background pages.

## Explicit boundaries

This is a **debug/testing build**, not an audited browser for banking, not a Play Store release, and not yet device tested. WebView is not the Chrome application and does not support Chrome Web Store extensions. Desktop site mode changes user agent and viewport; not every desktop feature will work. Network congestion and server limits mean no fixed download speed. Google may disallow account sign-in within embedded WebViews; *Open Gmail app* hands off to the phone's installed, signed-in Gmail when available.

The app ships **no fake subscription, password-sync or AI panels**. VPN requires your real provider account; without one Connect cannot work. The app cannot guarantee complete YouTube ad removal or a foreign IP by itself. An optional button looks up your real public IP via ipify.org only when you tap it; this discloses your public IP to that service.

## Build (GitHub Actions)

1. Upload `JinBrowser-Android-v0.6-source.zip` to repository root.
2. Replace `.github/workflows/build-apk.yml` with `build-apk-v0.6.yml`.
3. In GitHub Actions run `Build Jin Browser v0.6 APK` (or let `push` trigger it).
4. Download `JinBrowser-v0.6-debug-APK` artifact, unzip and install `app-debug.apk`.

The workflow runs offline source tests, pure Java tests and the **real Android SDK build**. Manual tests on a physical Android 10+ device remain necessary; VPN integration requires Android 11+ with IPsec tunneling and a valid service account.

### Manual testing checklist

- Search a phrase and a URL from both address bar and home; test online autocomplete opt-in.
- Change theme light → dark → system. Close/reopen settings. Navigate via bottom sheet; tabs and private window.
- Change city and ensure time/date remain correct and weather doesn't show a made-up temperature offline.
- On a site with test banner resources compare Ad Shield OFF/ON; verify per-site allowlist and no false positives on common sites.
- Verify the VPN status never falsely displays Connected without a provisioned provider.
- Download a test file using a server supporting byte ranges, pause it, copy URL, paste a new URL for the same file, resume and compare the **full file hash** to the original.
- Open and Show in Files for a PDF, JPG, ZIP and APK; verify external app chooser and Android security consent.
- Check Android battery saver and low-memory renderer recovery; do not expect an impossible zero-reload guarantee.

