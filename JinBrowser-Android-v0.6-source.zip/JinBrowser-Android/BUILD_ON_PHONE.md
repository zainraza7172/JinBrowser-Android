# Build Jin Browser v0.6 on GitHub (no PC required)

Using your phone's browser, open your `zainraza7172/JinBrowser-Android` repository. Upload the sibling file `JinBrowser-Android-v0.6-source.zip` at the repository root. Then open `.github/workflows/build-apk.yml`, select Edit, replace its contents with sibling `build-apk-v0.6.yml` and commit. A push triggers GitHub Actions automatically; alternatively click Actions → Build Jin Browser v0.6 APK → Run workflow.

After the green build appears, open the latest run, download the `JinBrowser-v0.6-debug-APK` artifact, unzip it in Files and tap `app-debug.apk`. Android may ask to allow installs from the current installer.

The artifact is a debug app for functional testing, not a production release. Do not use it for banking or sensitive passwords until security review and phone testing. Built-in VPN requires an actual trusted IKEv2 provider/server and Android 11+.
