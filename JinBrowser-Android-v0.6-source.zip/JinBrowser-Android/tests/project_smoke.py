"""v0.6 structural checks. Android SDK and real device tests are still required."""
from pathlib import Path
from xml.etree import ElementTree as ET
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/jinbrowser/app'
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
perms={e.attrib[ns+'name'] for e in manifest.findall('uses-permission')}
assert {'android.permission.INTERNET','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_DATA_SYNC'}<=perms
app=manifest.find('application')
activities={e.get(ns+'name'):e for e in app.findall('activity')}
assert {'.MainActivity','.PrivateActivity','.DownloadActivity','.SettingsActivity','.VpnActivity'}<=activities.keys()
assert activities['.PrivateActivity'].get(ns+'process')==':private'
assert activities['.VpnActivity'].get(ns+'exported')=='false'
assert '0.6.0' in (root/'app/build.gradle').read_text()
for xml in (root/'app/src/main/res').rglob('*.xml'):ET.parse(xml)
main=(pkg/'MainActivity.java').read_text()
settings=(pkg/'SettingsActivity.java').read_text()
vpn=(pkg/'VpnActivity.java').read_text()
shield=(pkg/'AdShield.java').read_text()
service=(pkg/'TurboDownloadService.java').read_text()
download=(pkg/'DownloadActivity.java').read_text()
html=(root/'app/src/main/assets/start.html').read_text()
for word in ('class="hero"','class="clock-card"','id="clock"','id="date"',
             'id="weatherTemp"','https://api.open-meteo.com/v1/forecast','location.href=\'jin://search?q=','jin://vpn','jin://settings','jin://downloads','html.dark'):
 assert word in html,word
assert 'Your privacy is guaranteed' not in html
for word in ('new Dialog(this)','Gravity.BOTTOM','SettingsActivity.class','VpnActivity.class','AdShield',
             'AdShield.cosmeticScript()','adShield.intercept','onPageStarted','https_only','open_last_tab',
             'makeDownloadJob(chosenUrl','Resume link (editable direct file URL)','sharePage()',
             'findOnPage()','switchDesktop(boolean','siteAdToggle()','setSupportMultipleWindows(true)',
             'onShowFileChooser','ACTION_OPEN_DOCUMENT_TREE','WebView.setWebContentsDebuggingEnabled'):
 assert word in main,word
for word in ('Ad Shield','setOnCheckedChangeListener','getBoolean','VPN','RoleManager.ROLE_BROWSER',
             'Clear browsing data','clearData()','developer_debugging','Settings.ACTION_APP_NOTIFICATION_SETTINGS'):
 assert word in settings,word
for word in ('Ikev2VpnProfile.Builder','provisionVpnProfile','startProvisionedVpnProfileSession',
             'VpnProfileState.STATE_CONNECTED','stopProvisionedVpnProfile','setAuthUsernamePassword'):
 assert word in vpn,word
assert 'putString("vpn_password"' not in vpn
assert 'private final AtomicLong blocked' in shield
for word in ('Resume link','updateLink(j)','ACTION_UPDATE','Open','showFile','ACTION_OPEN_DOCUMENT_TREE'):
 assert word in download,word
for word in ('verifyExistingParts','ACTION_UPDATE','ACTION_PAUSE','ACTION_RESUME','MediaStore.Downloads.IS_PENDING','Content-Range'):
 assert word in service,word
class ScriptCollector(HTMLParser):
 def __init__(self):super().__init__();self.in_script=False;self.scripts=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script':self.in_script=True
 def handle_endtag(self,tag):
  if tag=='script':self.in_script=False
 def handle_data(self,data):
  if self.in_script:self.scripts.append(data)
p=ScriptCollector();p.feed(html);assert p.scripts
script='\n'.join(p.scripts)
(root/'tests/home-script-check.js').write_text(script)
print('PASS: v0.6 source structure, native menu, settings, VPN, ad shield, weather, resume link and manifest')
