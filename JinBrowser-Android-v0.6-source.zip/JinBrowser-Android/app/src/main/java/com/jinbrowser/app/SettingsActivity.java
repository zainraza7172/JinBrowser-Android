package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import java.util.Locale;

/** Only implemented features have a setting; this is a separate native screen. */
public final class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout content;
    @Override public void onCreate(Bundle b) {
        Ui.init(this);setTheme(Ui.DARK?R.style.Theme_JinBrowser_Dark:R.style.Theme_JinBrowser);
        super.onCreate(b);Ui.status(this);
        prefs=getSharedPreferences("browser",MODE_PRIVATE);
        build();
    }
    private void build(){
        ScrollView scroll = new ScrollView(this);scroll.setBackgroundColor(Ui.BG);
        content=new LinearLayout(this);content.setOrientation(1);
        content.setPadding(Ui.dp(this,20),Ui.dp(this,14),Ui.dp(this,20),Ui.dp(this,35));
        scroll.addView(content);setContentView(scroll);Ui.fitSystemBars(this,scroll,0,0,0,0);
        LinearLayout bar = new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=Ui.text(this,"‹",34,Ui.WHITE,false);back.setGravity(Gravity.CENTER);
        bar.addView(back,Ui.layout(this,40,58));back.setOnClickListener(v->finish());
        TextView heading=Ui.text(this,"Settings",26,Ui.WHITE,true);
        bar.addView(heading,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));
        content.addView(bar);
        category("General");
        entry("Search engine",searchLabel(),this::searchEngine);
        entry("Start page",prefs.getBoolean("open_last_tab",true)?"Restore last tabs":"Open a new tab",this::startPage);
        entry("Appearance",themeLabel(),this::theme);
        entry("Search suggestions",prefs.getBoolean("online_suggestions",false)?"Online + local history":"Local history only",this::suggestions);
        toggle("Desktop sites by default","Remember individual site choices", "default_desktop", false);
        entry("Downloads", "Default connections: "+prefs.getInt("download_connections",4),this::downloadConnections);
        category("Privacy and security");
        toggle("Jin Ad Shield","Block known ad and tracker requests; may not catch all video ads", "ad_block", true);
        entry("VPN","Real IKEv2 · Your provider credentials",()->startActivity(new Intent(this,VpnActivity.class)));
        toggle("HTTPS-only browsing","Upgrade HTTP pages to HTTPS; sites without HTTPS may fail", "https_only",false);
        entry("External app links",prefs.getString("external_links","ask"),this::externalLinks);
        entry("Clear browsing data","Choose exactly what to delete",this::clearData);
        entry("App notifications","Open Android notification controls",()->{
            Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());startActivity(i);
        });
        category("Advanced");
        toggle("Remote WebView debugging","Only enable while connected to a trusted PC", "developer_debugging",false);
        entry("Default browser","Choose Jin in Android",this::defaultBrowser);
        entry("Browser engine","Show Android System WebView version",this::engineInfo);
        entry("About Jin Browser","Version 0.6 · Personal test build",()->new AlertDialog.Builder(this)
                .setTitle("Jin Browser 0.6")
                .setMessage("A personal Android WebView browser. No fake password-sync, extensions, or VPN exit servers. Some websites restrict Google sign-in within embedded browsers.")
                .setPositiveButton("OK",null).show());
    }
    private void category(String name){
        TextView t=Ui.text(this,name.toUpperCase(Locale.ROOT),12,Ui.CYAN,true);
        t.setLetterSpacing(.11f);t.setPadding(Ui.dp(this,7),Ui.dp(this,24),0,Ui.dp(this,10));
        content.addView(t,Ui.layout(this,-1,56));
    }
    private void entry(String title,String subtitle,Runnable click){
        LinearLayout box = new LinearLayout(this);box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(Ui.dp(this,15),Ui.dp(this,9),Ui.dp(this,10),Ui.dp(this,9));
        box.setBackground(Ui.pill(this,Ui.PANEL,16));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(1);
        TextView head=Ui.text(this,title,16,Ui.WHITE,true);
        TextView desc=Ui.text(this,subtitle,12,Ui.MUTED,false);
        desc.setMaxLines(3);labels.addView(head,Ui.layout(this,-1,27));labels.addView(desc);
        box.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=Ui.text(this,"›",28,Ui.MUTED,false);arrow.setGravity(Gravity.CENTER);
        box.addView(arrow,Ui.layout(this,24,54));
        LinearLayout.LayoutParams lp=Ui.layout(this,-1,-2);lp.bottomMargin=Ui.dp(this,9);
        box.setMinimumHeight(Ui.dp(this,76));content.addView(box,lp);box.setOnClickListener(v->click.run());
    }
    private void toggle(String title,String subtitle,String key,boolean def){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this,15),Ui.dp(this,10),Ui.dp(this,9),Ui.dp(this,10));
        row.setBackground(Ui.pill(this,Ui.PANEL,16));
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);
        words.addView(Ui.text(this,title,16,Ui.WHITE,true),Ui.layout(this,-1,28));
        TextView detail=Ui.text(this,subtitle,12,Ui.MUTED,false);detail.setMaxLines(3);words.addView(detail);
        row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this);sw.setChecked(prefs.getBoolean(key,def));
        row.addView(sw);sw.setOnCheckedChangeListener((button,value)->{
            prefs.edit().putBoolean(key,value).apply();
            if("developer_debugging".equals(key)) android.webkit.WebView.setWebContentsDebuggingEnabled(value);
        });
        row.setOnClickListener(v->sw.setChecked(!sw.isChecked()));
        LinearLayout.LayoutParams lp=Ui.layout(this,-1,-2);lp.bottomMargin=Ui.dp(this,9);
        row.setMinimumHeight(Ui.dp(this,80));content.addView(row,lp);
    }
    private String searchLabel(){String s=prefs.getString("engine","google");
        return s.equals("duckduckgo")?"DuckDuckGo":s.equals("bing")?"Bing":"Google";}
    private void searchEngine(){
        String[] opts={"Google","DuckDuckGo","Bing"};String[] ids={"google","duckduckgo","bing"};
        int selected=prefs.getString("engine","google").equals("duckduckgo")?1:
                prefs.getString("engine","google").equals("bing")?2:0;
        new AlertDialog.Builder(this).setTitle("Search engine").setSingleChoiceItems(opts,selected,(d,n)->{
            prefs.edit().putString("engine",ids[n]).apply();d.dismiss();build();
        }).setNegativeButton("Cancel",null).show();
    }
    private void startPage(){String[] choices={"Restore last tabs","Open new tab on launch"};
        new AlertDialog.Builder(this).setTitle("Start page").setSingleChoiceItems(choices,prefs.getBoolean("open_last_tab",true)?0:1,(d,n)->{
            prefs.edit().putBoolean("open_last_tab",n==0).apply();d.dismiss();build();
        }).setNegativeButton("Cancel",null).show();}
    private String themeLabel(){String t=prefs.getString("theme","system");
        return t.equals("dark")?"Dark":t.equals("light")?"Light":"Follow device";}
    private void theme(){String[] opts={"Follow device","Light","Dark"};String[] ids={"system","light","dark"};
        String t=prefs.getString("theme","system");int selected=t.equals("dark")?2:t.equals("light")?1:0;
        new AlertDialog.Builder(this).setTitle("Appearance").setSingleChoiceItems(opts,selected,(d,n)->{
            prefs.edit().putString("theme",ids[n]).apply();d.dismiss();recreate();
        }).setNegativeButton("Cancel",null).show();}
    private void suggestions(){
        new AlertDialog.Builder(this).setTitle("Online suggestions")
                .setMessage("If enabled, your typed text is sent to Google's suggestion service. Local history suggestions never need this. Online suggestions stay OFF in private tabs.")
                .setNegativeButton("Cancel",null).setNeutralButton("Turn OFF",(d,n)->{
                    prefs.edit().putBoolean("online_suggestions",false).apply();build();
                }).setPositiveButton("Turn ON",(d,n)->{
                    prefs.edit().putBoolean("online_suggestions",true).apply();build();
                }).show();
    }
    private void downloadConnections(){String[] options={"1 (compatible)","4 (balanced)","8 (if server allows)","16 (may be rate-limited)"};
        int[] ids={1,4,8,16};int prev=prefs.getInt("download_connections",4);int sel=prev==1?0:prev==8?2:prev==16?3:1;
        new AlertDialog.Builder(this).setTitle("Download connections").setSingleChoiceItems(options,sel,(d,n)->{
            prefs.edit().putInt("download_connections",ids[n]).apply();d.dismiss();build();
        }).setNegativeButton("Cancel",null).show();}
    private void externalLinks(){String[] options={"Ask before opening","Open installed app","Stay in browser where possible"};
        String[] ids={"ask","open","browser"};String choice=prefs.getString("external_links","ask");
        int selected=choice.equals("open")?1:choice.equals("browser")?2:0;
        new AlertDialog.Builder(this).setTitle("External app links").setSingleChoiceItems(options,selected,(d,n)->{
            prefs.edit().putString("external_links",ids[n]).apply();d.dismiss();build();
        }).setNegativeButton("Cancel",null).show();}
    private void clearData(){
        String[] opts={"History and recent searches","Cookies","Website storage","Bookmarks"};
        boolean[] selected={true,true,true,false};
        new AlertDialog.Builder(this).setTitle("Delete browsing data").setMultiChoiceItems(opts,selected,(d,n,value)->selected[n]=value)
            .setNegativeButton("Cancel",null).setPositiveButton("Delete selected",(d,n)->{
                SharedPreferences.Editor edit=prefs.edit();
                if(selected[0]){edit.remove("history");edit.remove("queries");}
                if(selected[1])CookieManager.getInstance().removeAllCookies(null);
                if(selected[2])WebStorage.getInstance().deleteAllData();
                if(selected[3])edit.remove("bookmarks");
                edit.apply();
                new AlertDialog.Builder(this).setMessage("Selected browsing data has been cleared. Open tabs may need a reload.")
                        .setPositiveButton("OK",null).show();
            }).show();
    }
    private void defaultBrowser(){
        try{RoleManager roles=getSystemService(RoleManager.class);
            if(roles!=null&&roles.isRoleAvailable(RoleManager.ROLE_BROWSER)){
                if(roles.isRoleHeld(RoleManager.ROLE_BROWSER)){
                    new AlertDialog.Builder(this).setMessage("Jin is already the default browser.").setPositiveButton("OK",null).show();
                }else startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_BROWSER),785);
            }else startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        }catch(Exception e){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:"+getPackageName())));}
    }
    private void engineInfo(){android.content.pm.PackageInfo p=android.webkit.WebView.getCurrentWebViewPackage();
        new AlertDialog.Builder(this).setTitle("WebView engine")
                .setMessage(p==null?"Provider unavailable":p.packageName+"\nVersion "+p.versionName+"\n\nChromium WebView is not full Chrome or Firefox.")
                .setPositiveButton("OK",null).show();}
}
