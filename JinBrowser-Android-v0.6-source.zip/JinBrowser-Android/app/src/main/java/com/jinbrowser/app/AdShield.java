package com.jinbrowser.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/** Request-level filter: transparent, configurable, offline and deliberately conservative. */
final class AdShield {
    private final SharedPreferences prefs;
    private final AtomicLong blocked = new AtomicLong();
    AdShield(Context c) {
        prefs = c.getSharedPreferences("browser", Context.MODE_PRIVATE);
        blocked.set(prefs.getLong("blocked_requests", 0));
    }
    boolean enabled() { return prefs.getBoolean("ad_block", true); }
    boolean allowedFor(String topHost) {
        return enabled() && (topHost == null || !prefs.getBoolean("ad_exception:" + topHost.toLowerCase(Locale.ROOT), false));
    }
    long count() { return blocked.get(); }
    void persist() { prefs.edit().putLong("blocked_requests", blocked.get()).apply(); }
    static boolean isAdHost(String host){ return AdBlockRules.isAdHost(host); }
    private static boolean sameDomain(String host,String topHost){ return AdBlockRules.sameSite(host,topHost); }
    boolean blocksNavigation(Uri target, String topHost) {
        return allowedFor(topHost) && isAdHost(target.getHost()) && !sameDomain(target.getHost(), topHost);
    }
    WebResourceResponse intercept(WebResourceRequest request, String topHost) {
        if (request.isForMainFrame() || !allowedFor(topHost)) return null;
        Uri u = request.getUrl();
        String scheme = u.getScheme();
        if (!("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))) return null;
        String host = u.getHost();
        if (host == null || sameDomain(host, topHost) || !isAdHost(host)) return null;
        blocked.incrementAndGet();
        return emptyResponse();
    }
    static WebResourceResponse emptyResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
    }
    /** Cosmetic hiding complements network blocking; it does not claim to remove every video ad. */
    static String cosmeticScript() {
        return "(function(){if(document.getElementById('jin-ad-css'))return;"+
                "var s=document.createElement('style');s.id='jin-ad-css';"+
                "s.textContent='ins.adsbygoogle,[id^=google_ads_],.adsbygoogle,.ad-banner,.ad-slot,div[data-ad-slot],"+
                "[aria-label=Advertisement]{display:none!important}';document.head.appendChild(s)})();";
    }
}
