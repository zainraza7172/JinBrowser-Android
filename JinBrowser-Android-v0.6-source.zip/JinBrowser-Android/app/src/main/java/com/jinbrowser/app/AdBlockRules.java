package com.jinbrowser.app;

import java.util.Locale;
/** Pure Java domain matching, tested independently from Android. */
final class AdBlockRules {
    private static final String[] HOSTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "smartadserver.com", "lijit.com",
        "casalemedia.com", "sharethrough.com", "sovrn.com", "yieldmo.com", "indexexchange.com",
        "advertising.com", "amazon-adsystem.com", "media.net", "bidswitch.net", "spotxchange.com",
        "moatads.com", "scorecardresearch.com", "quantserve.com", "2mdn.net", "adsafeprotected.com",
        "googletagmanager.com", "google-analytics.com", "connect.facebook.net", "facebook.net",
        "hotjar.com", "segment.io", "mixpanel.com", "branch.io", "onesignal.com",
        "popads.net", "propellerads.com", "exoclick.com", "adsterra.com", "mgid.com",
        "clickadu.com", "trafficjunky.net", "revcontent.com", "inmobi.com", "unityads.unity3d.com"
    };
    private AdBlockRules() {}
    static boolean isAdHost(String host) {
        if(host == null || host.isEmpty()) return false;
        String h=host.toLowerCase(Locale.ROOT);
        for(String entry:HOSTS) if(h.equals(entry)||h.endsWith("."+entry))return true;
        return false;
    }
    static boolean sameSite(String host,String topHost) {
        if(host==null||topHost==null||topHost.isEmpty())return false;
        String h=host.toLowerCase(Locale.ROOT),top=topHost.toLowerCase(Locale.ROOT);
        return h.equals(top)||h.endsWith("."+top);
    }
}
