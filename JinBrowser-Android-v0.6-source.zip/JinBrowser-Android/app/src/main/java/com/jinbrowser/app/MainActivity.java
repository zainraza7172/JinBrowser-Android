package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.view.KeyEvent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.AutoCompleteTextView;
import android.widget.AdapterView;
import android.text.TextWatcher;
import android.text.Editable;
import android.os.Handler;
import android.os.Looper;
import android.content.res.ColorStateList;
import android.content.ActivityNotFoundException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.widget.ScrollView;
import android.widget.Switch;
import android.view.Window;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.io.ByteArrayOutputStream;

/** Android WebView browser with a minimal new tab and a native download manager. */
public class MainActivity extends Activity {
    private static final int MAX_TABS = 12;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private FrameLayout viewport;
    private AutoCompleteTextView address;
    private ArrayAdapter<String> suggestionAdapter;
    private final Handler suggestHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService suggestWorker = Executors.newFixedThreadPool(2);
    private Runnable suggestPending;
    private volatile int suggestionRevision = 0;
    private ProgressBar loading;
    private TextView tabCounter, modeTag, back, forward, securityIndicator;
    private int lastSelectedTab = 0;
    private AdShield adShield;
    private boolean appliedDark;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int UPLOAD_REQUEST = 418;
    private static final int NOTIFICATION_REQUEST = 419;
    private static final int DOWNLOAD_FOLDER_REQUEST = 420;
    private DownloadJob pendingFolderJob;
    private String pendingFolderCookie;

    protected boolean privateMode() { return false; }
    protected void prepareProcess() {}

    @Override public void onCreate(Bundle savedState) {
        // Pick the native Android theme before inflating any menus, dialogs or controls.
        Ui.init(this);
        setTheme(Ui.DARK ? R.style.Theme_JinBrowser_Dark : R.style.Theme_JinBrowser);
        super.onCreate(savedState);
        prepareProcess(); // Must run before creating a WebView in the private process.
        WebView.setWebContentsDebuggingEnabled(!privateMode() && getSharedPreferences("browser", MODE_PRIVATE).getBoolean("developer_debugging", false));
        Ui.status(this);
        appliedDark = Ui.DARK;
        adShield = new AdShield(this);
        if (privateMode()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        makeChrome();
        // Android 13+ asks separately before displaying ordinary download notifications.
        if (!privateMode() && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        if (!privateMode()) {
            lastSelectedTab = getSharedPreferences("browser", MODE_PRIVATE).getInt("current_tab", 0);
            restoreTabs();
            if (!getSharedPreferences("browser", MODE_PRIVATE).getBoolean("open_last_tab",true) && !tabs.isEmpty()) newTab(null);
        }
        String launchUrl = externalPage(getIntent());
        if (tabs.isEmpty()) newTab(launchUrl);
        else if (launchUrl == null) showTab(Math.min(Math.max(0, lastSelectedTab), tabs.size() - 1));
        else if (tabs.size() < MAX_TABS) newTab(launchUrl);
        else { showTab(Math.max(0, tabs.size() - 1)); tab().view.loadUrl(launchUrl); }
    }

    /** Single streamlined browser bar. Web pages fill the entire viewport, without borders. */
    private void makeChrome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        Ui.fitSystemBars(this, root, 0, 0, 0, 0);

        LinearLayout header = new LinearLayout(this);
        header.setPadding(Ui.dp(this, 12), Ui.dp(this, 7), Ui.dp(this, 8), Ui.dp(this, 8));
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, Ui.layout(this, -1, 67));

        LinearLayout omnibox = new LinearLayout(this);
        omnibox.setGravity(Gravity.CENTER_VERTICAL);
        omnibox.setBackground(Ui.glass(this, 18));
        omnibox.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 4), 0);
        TextView vpn = Ui.text(this, "◇", 29, Ui.CYAN, true);
        vpn.setGravity(Gravity.CENTER);vpn.setContentDescription("Jin VPN");
        vpn.setOnClickListener(v -> startActivity(new Intent(this, VpnActivity.class)));
        header.addView(vpn, Ui.layout(this, 43, 50));
        header.addView(omnibox, new LinearLayout.LayoutParams(0, Ui.dp(this, 49), 1));

        securityIndicator = Ui.text(this, "⌕", 22, Ui.CYAN, true);
        securityIndicator.setGravity(Gravity.CENTER);
        securityIndicator.setContentDescription("Page connection information");
        securityIndicator.setOnClickListener(v -> {
            String url = tab().view.getUrl();
            String message = url != null && url.startsWith("https://") && !url.startsWith("https://jin.home/")
                    ? "HTTPS connection. A padlock does not prove that this website is trustworthy."
                    : url != null && url.startsWith("http://") ? "Unencrypted connection. Avoid entering passwords."
                    : "New tab or local browser page.";
            new AlertDialog.Builder(this).setTitle("Connection information")
                    .setMessage(message).setPositiveButton("OK", null).show();
        });
        omnibox.addView(securityIndicator, Ui.layout(this, 29, 49));

        address = new AutoCompleteTextView(this) {
            @Override protected void performFiltering(CharSequence query, int keyCode) {
                // Suggestions are explicitly managed and debounced by scheduleSuggestions().
                // The framework's default ArrayAdapter filter would overwrite newer results.
            }
        };
        address.setSingleLine(true);
        address.setTextColor(Ui.WHITE);
        address.setHintTextColor(Ui.MUTED);
        address.setTextSize(15);
        address.setHint("Search or enter address");
        address.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
        address.setBackgroundColor(Color.TRANSPARENT);
        address.setSelectAllOnFocus(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setThreshold(1);
        address.setDropDownVerticalOffset(Ui.dp(this, 9));
        address.setDropDownHeight(Ui.dp(this, 330));
        address.setDropDownBackgroundDrawable(Ui.pill(this, Ui.PANEL, 14));
        suggestionAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,
                new ArrayList<>()) {
            @Override public View getView(int position, View convert, ViewGroup parent) {
                View row = super.getView(position, convert, parent);
                if (row instanceof TextView) {
                    ((TextView) row).setTextColor(Ui.WHITE);
                    row.setBackgroundColor(Ui.PANEL);
                    row.setPadding(Ui.dp(MainActivity.this, 17), 0, Ui.dp(MainActivity.this, 10), 0);
                    row.setMinimumHeight(Ui.dp(MainActivity.this, 47));
                }
                return row;
            }
        };
        address.setAdapter(suggestionAdapter);
        address.setOnItemClickListener((parent, v, position, id) -> {
            String selected = (String) parent.getItemAtPosition(position);
            navigate(selected);
            hideKeyboard();
        });
        address.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                if (address.hasFocus()) scheduleSuggestions(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        address.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) scheduleSuggestions(address.getText().toString());
            else { suggestionRevision++; address.dismissDropDown(); }
        });
        address.setOnEditorActionListener((v, action, e) -> {
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH ||
                (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER && e.getAction() == KeyEvent.ACTION_DOWN)) {
                navigate(address.getText().toString()); hideKeyboard(); return true;
            }
            return false;
        });
        omnibox.addView(address, new LinearLayout.LayoutParams(0, Ui.dp(this, 49), 1));
        TextView go = Ui.text(this, "→", 24, Ui.CYAN, true);
        go.setGravity(Gravity.CENTER);
        go.setContentDescription("Search or go");
        go.setOnClickListener(v -> { navigate(address.getText().toString()); hideKeyboard(); });
        omnibox.addView(go, Ui.layout(this, 38, 49));

        modeTag = Ui.text(this, "⋮", 26, Ui.WHITE, true);
        modeTag.setGravity(Gravity.CENTER);
        modeTag.setContentDescription("Browser menu");
        modeTag.setOnClickListener(v -> openMenu());
        header.addView(modeTag, Ui.layout(this, 49, 50));

        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(ColorStateList.valueOf(Ui.CYAN));
        loading.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        loading.setVisibility(View.INVISIBLE);
        root.addView(loading, Ui.layout(this, -1, 2));
        viewport = new FrameLayout(this);
        viewport.setBackgroundColor(Ui.DARK ? Ui.BG : Color.WHITE);
        root.addView(viewport, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        nav.setBackgroundColor(Ui.BG);
        back = navButton(nav, "‹", "Back", () -> { if (tab().view.canGoBack()) tab().view.goBack(); });
        forward = navButton(nav, "›", "Forward", () -> { if (tab().view.canGoForward()) tab().view.goForward(); });
        tabCounter = navButton(nav, "1", "Tabs", this::openTabs);
        navButton(nav, "☰", "Menu", this::openMenu);
        root.addView(nav, Ui.layout(this, -1, 53));
    }

    private void focusAddress() {
        address.requestFocus();
        address.setSelection(address.length());
        address.postDelayed(() -> {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(address, InputMethodManager.SHOW_IMPLICIT);
            scheduleSuggestions(address.getText().toString());
        }, 125);
    }

    /** Local history is instant. Online suggestions are optional and disabled for private tabs. */
    private void scheduleSuggestions(String input) {
        if (suggestPending != null) suggestHandler.removeCallbacks(suggestPending);
        int revision = ++suggestionRevision;
        String query = input.trim();
        ArrayList<String> local = localSuggestions(query);
        presentSuggestions(local);
        // Site URLs, email addresses and query-string secrets should not be sent
        // to the search suggestion server; local history still works for these.
        if (query.length() < 1 || privateMode() || query.contains("://") ||
                query.contains("/") || query.contains("@") || query.contains("?") ||
                !getSharedPreferences("browser", MODE_PRIVATE).getBoolean("online_suggestions", false)) return;
        suggestPending = () -> suggestWorker.execute(() -> {
            if (revision != suggestionRevision) return;
            ArrayList<String> online = new ArrayList<>();
            HttpURLConnection c = null;
            try {
                URL endpoint = new URL("https://suggestqueries.google.com/complete/search?client=firefox&q=" +
                        URLEncoder.encode(query, "UTF-8"));
                c = (HttpURLConnection) endpoint.openConnection();
                c.setConnectTimeout(1800); c.setReadTimeout(1800);
                c.setRequestProperty("Accept", "application/json");
                if (c.getResponseCode() == 200) {
                    StringBuilder json = new StringBuilder();
                    try (BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                        String line;
                        while ((line = in.readLine()) != null && json.length() < 16000) json.append(line);
                    }
                    JSONArray terms = new JSONArray(json.toString()).optJSONArray(1);
                    if (terms != null) for (int i=0; i<Math.min(6,terms.length()); i++) {
                        String value = terms.optString(i, "").trim();
                        if (!value.isEmpty()) online.add(value);
                    }
                }
            } catch (Exception ignored) { /* Offline: local history still works. */ }
            finally { if (c != null) c.disconnect(); }
            runOnUiThread(() -> {
                if (revision != suggestionRevision || !address.hasFocus() ||
                        !query.equals(address.getText().toString().trim())) return;
                LinkedHashSet<String> combined = new LinkedHashSet<>(local);
                combined.addAll(online);
                presentSuggestions(new ArrayList<>(combined));
            });
        });
        suggestHandler.postDelayed(suggestPending, 280);
    }

    private ArrayList<String> localSuggestions(String input) {
        LinkedHashSet<String> terms = new LinkedHashSet<>();
        if (privateMode()) return new ArrayList<>();
        String q = input.toLowerCase(Locale.ROOT);
        try {
            JSONArray searches = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("queries", "[]"));
            for (int i=0;i<searches.length() && terms.size()<4;i++) {
                String term = searches.optString(i, "");
                if (!term.isEmpty() && term.toLowerCase(Locale.ROOT).contains(q) && !term.equalsIgnoreCase(input)) terms.add(term);
            }
            for (String kind : new String[]{"history", "bookmarks"}) {
                JSONArray items = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString(kind, "[]"));
                for (int i=0;i<Math.min(items.length(),100) && terms.size()<6;i++) {
                    JSONObject item = items.optJSONObject(i); if (item == null) continue;
                    String url = item.optString("url", "");
                    if (!url.isEmpty() && (item.optString("title", "").toLowerCase(Locale.ROOT).contains(q) ||
                            url.toLowerCase(Locale.ROOT).contains(q))) terms.add(url);
                }
            }
        } catch (Exception ignored) {}
        return new ArrayList<>(terms);
    }

    private void presentSuggestions(ArrayList<String> values) {
        if (suggestionAdapter == null || !address.hasFocus()) return;
        suggestionAdapter.clear();
        suggestionAdapter.addAll(values);
        suggestionAdapter.notifyDataSetChanged();
        if (values.isEmpty()) address.dismissDropDown();
        else address.showDropDown();
    }

    private void saveQuery(String value) {
        if (privateMode() || value.isEmpty()) return;
        try {
            JSONArray old = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("queries", "[]"));
            JSONArray updated = new JSONArray(); updated.put(value);
            for (int i=0;i<old.length() && updated.length()<40;i++)
                if (!value.equalsIgnoreCase(old.optString(i))) updated.put(old.optString(i));
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("queries", updated.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void hideKeyboard() {
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.dismissDropDown();
        suggestionRevision++;
        address.clearFocus();
    }

    private TextView navButton(LinearLayout nav, String glyph, String desc, Runnable click) {
        TextView v = Ui.text(this, glyph, 26, Ui.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setContentDescription(desc);
        v.setOnClickListener(w -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1);
        nav.addView(v, lp);
        return v;
    }
    private static class Tab {
        WebView view;
        String title = "New tab";
        String lastUrl = "";
        boolean pinned = false;
        boolean desktop = false;
    }
    private Tab tab() { return tabs.get(current); }

    private void newTab(String url) {
        if (tabs.size() >= MAX_TABS) {
            Toast.makeText(this, "Maximum " + MAX_TABS + " tabs. Close one first.", Toast.LENGTH_LONG).show();
            return;
        }
        Tab t = new Tab();
        t.view = createWebView(t);
        tabs.add(t);
        showTab(tabs.size() - 1);
        if (url == null || url.isEmpty()) showHome(t);
        else { applySiteDesktop(t, url); t.view.loadUrl(url); }
        persist();
    }
    private WebView createWebView(Tab t) {
        WebView w = new WebView(this);
        w.setBackgroundColor(Ui.DARK ? Ui.BG : Color.WHITE);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // WebViews stay instantiated across switches, so tab switching doesn't reload pages.
        // A user can also pin an important tab to increase renderer priority.
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(privateMode() ? WebSettings.LOAD_NO_CACHE : WebSettings.LOAD_DEFAULT);
        if (privateMode()) {
            // Avoid intentionally writing page resources to the on-disk WebView HTTP cache.
            // This is a privacy improvement, not a guarantee that Android never caches anything.
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setSaveFormData(false);
        }
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // Android document picker grants temporary access to selected file uploads.
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(true); // Open user-initiated target=_blank links as tabs.
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                t.lastUrl = url == null || url.startsWith("https://jin.home/") ? "" : url;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("jin".equalsIgnoreCase(uri.getScheme())) {
                    // Only the bundled start page may trigger internal browser commands.
                    if (req.isForMainFrame() && "https://jin.home/".equals(view.getUrl())) handleJinUrl(uri);
                    return true;
                }
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (req.isForMainFrame() && adShield.blocksNavigation(uri,
                            Uri.parse(t.lastUrl == null ? "" : t.lastUrl).getHost())) {
                        Toast.makeText(MainActivity.this, "Jin Shield blocked an ad redirect", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                    if (req.isForMainFrame() && "http".equalsIgnoreCase(scheme) &&
                            getSharedPreferences("browser",MODE_PRIVATE).getBoolean("https_only",false)) {
                        view.loadUrl("https" + uri.toString().substring(4));return true;
                    }
                    if (req.isForMainFrame()) applySiteDesktop(t, uri.toString());
                    return false;
                }
                if (req.isForMainFrame() && req.hasGesture()) openExternalLink(uri.toString(), view);
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                return adShield.intercept(req, Uri.parse(t.lastUrl == null ? "" : t.lastUrl).getHost());
            }
            @Override public void onPageFinished(WebView view, String url) {
                t.lastUrl = url == null || url.equals("about:blank") || url.startsWith("https://jin.home/") ? "" : url;
                if (!privateMode() && url != null && URLUtil.isNetworkUrl(url) && !url.startsWith("https://jin.home/"))
                    saveHistory(url, t.title);
                if (adShield.allowedFor(Uri.parse(url == null ? "" : url).getHost()) &&
                        url != null && !url.startsWith("https://jin.home/"))
                    view.evaluateJavascript(AdShield.cosmeticScript(), null);
                if (current >= 0 && tab() == t) updateChrome();
                persist();
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError err) {
                handler.cancel(); // Never automatically bypass an invalid certificate.
                Toast.makeText(MainActivity.this, "Blocked: invalid HTTPS certificate", Toast.LENGTH_LONG).show();
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // On memory-limited devices the OS may kill WebView's renderer.
                // Recover the browser shell rather than crashing the entire app.
                int index = tabs.indexOf(t);
                if (index < 0) return true;
                boolean visible = index == current;
                String recovery = t.lastUrl;
                if (view.getParent() instanceof ViewGroup)
                    ((ViewGroup)view.getParent()).removeView(view);
                tabs.remove(index);
                view.destroy();
                if (tabs.isEmpty()) newTab(null);
                else if (visible) showTab(Math.min(index, tabs.size() - 1));
                else if (index < current) current--;
                persist();
                if (visible) new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Tab closed by Android")
                        .setMessage("Android stopped this page to free memory. The browser recovered. Reopen the last URL?")
                        .setNegativeButton("Stay here", null)
                        .setPositiveButton("Reopen", (d, w) -> {
                            if (recovery != null && URLUtil.isNetworkUrl(recovery)) newTab(recovery);
                        }).show();
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                    boolean isUserGesture, android.os.Message resultMsg) {
                if (!isUserGesture || tabs.size() >= MAX_TABS) return false;
                // The transport needs a fresh WebView; loading the home page first
                // can interfere with window.open / target=_blank navigation.
                Tab popup = new Tab();
                popup.view = createWebView(popup);
                tabs.add(popup);
                showTab(tabs.size() - 1);
                persist();
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup.view);
                resultMsg.sendToTarget();
                return true;
            }
            @Override public void onProgressChanged(WebView view, int progress) {
                if (current < 0 || tab() != t) return;
                loading.setVisibility(progress == 100 ? View.INVISIBLE : View.VISIBLE);
                loading.setProgress(progress);
            }
            @Override public void onReceivedTitle(WebView v, String title) {
                t.title = title == null || title.trim().isEmpty() ? "New tab" : title;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try { startActivityForResult(params.createIntent(), UPLOAD_REQUEST); return true; }
                catch (Exception e) { uploadCallback.onReceiveValue(null); uploadCallback = null; return false; }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                // Never silently grant camera/microphone to arbitrary websites.
                runOnUiThread(request::deny);
            }
        });
        w.setDownloadListener((url, agent, disposition, mime, size) -> {
            if (privateMode()) {
                new AlertDialog.Builder(this)
                    .setTitle("Private download")
                    .setMessage("Downloaded files and download records remain visible in the normal Downloads screen. Continue?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Continue", (d, x) -> onDownload(url, agent, disposition, mime, size))
                    .show();
            } else onDownload(url, agent, disposition, mime, size);
        });
        return w;
    }
    private void showTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        viewport.removeAllViews();
        current = index;
        WebView w = tab().view;
        if (w.getParent() instanceof ViewGroup) ((ViewGroup) w.getParent()).removeView(w);
        viewport.addView(w, new FrameLayout.LayoutParams(-1, -1));
        updateChrome();
    }
    private void updateChrome() {
        if (current < 0) return;
        String url = tab().view.getUrl();
        if (!address.hasFocus()) address.setText(url == null || url.equals("about:blank") ||
                url.startsWith("https://jin.home/") ? "" : url, false);
        boolean secure = url != null && url.startsWith("https://") && !url.startsWith("https://jin.home/");
        boolean insecure = url != null && url.startsWith("http://");
        securityIndicator.setText(insecure ? "!" : secure ? "◆" : "✧");
        securityIndicator.setTextColor(insecure ? 0xffffae80 : Ui.CYAN);
        securityIndicator.setContentDescription(insecure ? "Unencrypted HTTP connection" :
                secure ? "HTTPS connection (identity not verified)" : "New tab");
        tabCounter.setText("▢" + tabs.size());
        back.setTextColor(tab().view.canGoBack() ? Ui.CYAN : Ui.MUTED);
        forward.setTextColor(tab().view.canGoForward() ? Ui.CYAN : Ui.MUTED);
    }
    private void showHome(Tab t) {
        try (InputStream stream = getAssets().open("start.html")) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = stream.read(buffer)) != -1) bytes.write(buffer, 0, n);
            String html = bytes.toString("UTF-8").replace("<html lang=\"en\">",
                    "<html lang=\"en\" class=\"" + (Ui.DARK ? "dark" : "light") + "\">")
                    .replace("__SHIELD_STATUS__", adShield.enabled() ? "Ad Shield on" : "Ad Shield off");
            t.view.loadDataWithBaseURL("https://jin.home/", html, "text/html", "UTF-8", null);
            t.lastUrl = "";
        } catch (Exception e) { t.view.loadData("<h1>Jin Browser</h1>", "text/html", "UTF-8"); }
    }
    private void home() { showHome(tab()); }
    /** Only explicit HTTPS/HTTP links from external intents are opened. */
    private static String externalPage(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return null;
        Uri data = intent.getData();
        if (data == null) return null;
        String scheme = data.getScheme();
        return "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme) ? data.toString() : null;
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = externalPage(intent);
        if (url == null || tabs.isEmpty()) return;
        if (tabs.size() < MAX_TABS) newTab(url);
        else tab().view.loadUrl(url);
    }
    private void navigate(String raw) {
        String value = raw.trim(); if (value.isEmpty()) return;
        String target;
        if (value.matches("(?i)^https?://.+")) target = value;
        else if (!value.contains(" ") && (value.matches("(?i)^localhost(:\\d+)?(/.*)?$") || value.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:\\d+)?(/.*)?$"))) target = "https://" + value;
        else {
            String engine = getSharedPreferences("browser", MODE_PRIVATE).getString("engine", "google");
            target = "duckduckgo".equals(engine) ? "https://duckduckgo.com/?q=" + Uri.encode(value)
                    : "bing".equals(engine) ? "https://www.bing.com/search?q=" + Uri.encode(value)
                    : "https://www.google.com/search?q=" + Uri.encode(value);
        }
        if (!URLUtil.isNetworkUrl(target)) return;
        suggestionRevision++;
        if (suggestPending != null) suggestHandler.removeCallbacks(suggestPending);
        if (!value.matches("(?i)^https?://.*") && (value.contains(" ") || !value.contains("."))) saveQuery(value);
        if (getSharedPreferences("browser", MODE_PRIVATE).getBoolean("https_only",false) && target.startsWith("http://"))
            target="https://"+target.substring(7);
        applySiteDesktop(tab(), target);
        tab().view.loadUrl(target);
        address.dismissDropDown();
        address.clearFocus();
    }
    private void handleJinUrl(Uri uri) {
        switch (uri.getHost() == null ? "" : uri.getHost()) {
            case "search": navigate(uri.getQueryParameter("q") == null ? "" : uri.getQueryParameter("q")); break;
            case "focus": focusAddress(); break;
            case "gmail": openGmail(); break;
            case "downloads": startActivity(new Intent(this, DownloadActivity.class)); break;
            case "vpn": startActivity(new Intent(this, VpnActivity.class)); break;
            case "settings": startActivity(new Intent(this, SettingsActivity.class)); break;
            case "private": if (!privateMode()) startActivity(new Intent(this, PrivateActivity.class));
                else Toast.makeText(this, "Already in private mode", Toast.LENGTH_SHORT).show(); break;
            default: break;
        }
    }
    private void onDownload(String url, String agent, String disposition, String mime, long declaredSize) {
        if (!URLUtil.isNetworkUrl(url)) return;
        String name = URLUtil.guessFileName(url, disposition, mime);
        final EditText rename = new EditText(this);
        rename.setSingleLine(true); rename.setText(name); rename.selectAll();
        rename.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), Ui.dp(this, 18), 0);
        form.addView(Ui.text(this, "File name", 12, Ui.MUTED, true));
        form.addView(rename, Ui.layout(this, -1, 55));
        form.addView(Ui.text(this, "Resume link (editable direct file URL)", 12, Ui.MUTED, true));
        EditText resumeLink = new EditText(this);resumeLink.setSingleLine(true);resumeLink.setText(url);
        resumeLink.setSelectAllOnFocus(true);
        resumeLink.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        form.addView(resumeLink, Ui.layout(this, -1, 55));
        form.addView(Ui.text(this, "If this link expires later, open Downloads → Resume link to replace it without losing safe partial files.", 12, Ui.MUTED, false));
        form.addView(Ui.text(this, "Connections (server permitting)", 12, Ui.MUTED, true));
        Spinner connections = new Spinner(this);
        String[] speeds = {"1 connection", "4 connections", "8 connections", "16 connections"};
        connections.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, speeds));
        int connectionsPref=getSharedPreferences("browser", MODE_PRIVATE).getInt("download_connections",4);
        connections.setSelection(connectionsPref==1?0:connectionsPref==8?2:connectionsPref==16?3:1);
        form.addView(connections, Ui.layout(this, -1, 50));
        form.addView(Ui.text(this, "Location: Downloads / JinBrowser (or choose a folder)", 12, Ui.MUTED, false));
        ScrollView downloadFormScroll=new ScrollView(this);downloadFormScroll.addView(form);
        new AlertDialog.Builder(this)
                .setTitle("Download file")
                .setMessage("Select where to save. If a link expires, paste its replacement in Downloads." +
                        (privateMode() ? " Private browsing downloads remain visible in Downloads." : ""))
                .setView(downloadFormScroll)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Choose folder", (dialog, which) -> {
                    String chosenUrl=resumeLink.getText().toString().trim();
                    if(!chosenUrl.matches("(?i)^https?://.+")){Toast.makeText(this,"Enter a direct HTTP(S) URL",Toast.LENGTH_LONG).show();return;}
                    DownloadJob j = makeDownloadJob(chosenUrl, agent, mime, declaredSize, rename, connections);
                    pendingFolderJob = j;
                    pendingFolderCookie = CookieManager.getInstance().getCookie(url);
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try { startActivityForResult(pick, DOWNLOAD_FOLDER_REQUEST); }
                    catch (Exception error) { pendingFolderJob=null; pendingFolderCookie=null;
                        Toast.makeText(this,"Folder picker unavailable", Toast.LENGTH_LONG).show(); }
                })
                .setPositiveButton("Save to Downloads", (dialog, which) -> {
                    String chosenUrl=resumeLink.getText().toString().trim();
                    if(!chosenUrl.matches("(?i)^https?://.+")){Toast.makeText(this,"Enter a direct HTTP(S) URL",Toast.LENGTH_LONG).show();return;}
                    DownloadJob j = makeDownloadJob(chosenUrl, agent, mime, declaredSize, rename, connections);
                    TurboDownloadService.enqueue(this, j, CookieManager.getInstance().getCookie(url));
                    startActivity(new Intent(this, DownloadActivity.class));
                }).show();
    }
    private DownloadJob makeDownloadJob(String url, String agent, String mime, long declaredSize,
                                        EditText rename, Spinner connections) {
        int[] options = {1, 4, 8, 16};
        DownloadJob job = DownloadJob.create(url, rename.getText().toString(), agent, mime, declaredSize,
                options[Math.max(0, Math.min(3, connections.getSelectedItemPosition()))]);
        job.privateDownload = privateMode();
        return job;
    }
    /** Individual close buttons, tab switch and new/private actions in one screen. */
    private void openTabs() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        TextView heading = Ui.text(this, privateMode() ? "Private tabs" : "Your tabs", 21, Ui.WHITE, true);
        panel.addView(heading, Ui.layout(this, -1, 48));
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel)
                .setNegativeButton("Done", null).create();
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView add = Ui.text(this, "+  New tab", 15, Ui.CYAN, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(Ui.pill(this, Ui.PANEL, 12));
        add.setOnClickListener(v -> { dialog.dismiss(); newTab(null); });
        actions.addView(add, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1));
        TextView privateAction = Ui.text(this, privateMode() ? "Close private" : "◈  Private", 14, Ui.WHITE, true);
        privateAction.setGravity(Gravity.CENTER);
        privateAction.setOnClickListener(v -> {
            dialog.dismiss();
            if (privateMode()) finish();
            else startActivity(new Intent(this, PrivateActivity.class));
        });
        actions.addView(privateAction, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1));
        panel.addView(actions, Ui.layout(this, -1, 50));
        View line = new View(this); line.setBackgroundColor(Ui.STROKE);
        panel.addView(line, Ui.layout(this, -1, 1));
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        panel.addView(scroll, Ui.layout(this, -1, -2));
        for (int i=0; i<tabs.size(); i++) {
            final int index = i;
            Tab item = tabs.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
            row.setBackground(Ui.pill(this, index == current ? Ui.PANEL : Ui.BG, 10));
            LinearLayout.LayoutParams rp = Ui.layout(this, -1, 65); rp.topMargin=Ui.dp(this,7);
            rows.addView(row, rp);
            TextView title = Ui.text(this, item.title, 14, Ui.WHITE, true);
            title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.addView(title, Ui.layout(this,-1,27));
            TextView url = Ui.text(this, item.lastUrl == null || item.lastUrl.isEmpty() ? "New tab" : item.lastUrl,
                    11, Ui.MUTED, false);
            url.setSingleLine(true); url.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(url, Ui.layout(this,-1,22));
            row.addView(info, new LinearLayout.LayoutParams(0,Ui.dp(this,52),1));
            info.setOnClickListener(v -> { showTab(index); dialog.dismiss(); });
            TextView close = Ui.text(this, "×", 27, Ui.MUTED, false);
            close.setGravity(Gravity.CENTER);
            close.setContentDescription("Close tab: " + item.title);
            close.setOnClickListener(v -> { dialog.dismiss(); closeTabAt(index); openTabs(); });
            row.addView(close,Ui.layout(this, 47, 50));
        }
        dialog.show();
    }

    private void closeTabAt(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (tabs.size() == 1) { showTab(0); home(); return; }
        Tab old = tabs.remove(index);
        if (old.view.getParent() instanceof ViewGroup)
            ((ViewGroup) old.view.getParent()).removeView(old.view);
        old.view.destroy();
        if (index < current) current--;
        else if (index == current) current = Math.min(index, tabs.size()-1);
        showTab(current);
        persist();
    }
    private void closeTab() {
        closeTabAt(current);
    }
    /** Native bottom sheet, not a tiny popup. Every shown control is connected. */
    private void openMenu() {
        Dialog sheet=new Dialog(this);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        LinearLayout content=new LinearLayout(this);content.setOrientation(1);
        content.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,28));
        GradientDrawable backdrop=new GradientDrawable();backdrop.setColor(Ui.BG);
        backdrop.setCornerRadii(new float[]{Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,28),Ui.dp(this,28),0,0,0,0});
        scroll.setBackground(backdrop);content.setBackground(backdrop);scroll.addView(content);
        TextView grab=Ui.text(this,"━",22,Ui.MUTED,false);grab.setGravity(Gravity.CENTER);
        content.addView(grab,Ui.layout(this,-1,22));
        LinearLayout quick=new LinearLayout(this);quick.setGravity(Gravity.CENTER);
        content.addView(quick,Ui.layout(this,-1,81));
        menuQuick(quick,"‹","Back",()->{if(tab().view.canGoBack())tab().view.goBack();sheet.dismiss();});
        menuQuick(quick,"›","Forward",()->{if(tab().view.canGoForward())tab().view.goForward();sheet.dismiss();});
        menuQuick(quick,"♧","Share",()->{sharePage();sheet.dismiss();});
        menuQuick(quick,"↻","Refresh",()->{tab().view.reload();sheet.dismiss();});
        sheetRow(content,"☆","Bookmark page",()->{addBookmark();sheet.dismiss();});
        sheetRow(content,"⌕","Find in page",()->{sheet.dismiss();findOnPage();});
        LinearLayout desktop=new LinearLayout(this);desktop.setGravity(Gravity.CENTER_VERTICAL);
        desktop.setPadding(Ui.dp(this,18),0,Ui.dp(this,13),0);desktop.setBackground(Ui.pill(this,Ui.PANEL,16));
        TextView desktopText=Ui.text(this,"▣    Desktop site",16,Ui.WHITE,true);
        desktop.addView(desktopText,new LinearLayout.LayoutParams(0,Ui.dp(this,68),1));
        Switch sw=new Switch(this);sw.setChecked(tab().desktop);desktop.addView(sw);
        sw.setOnCheckedChangeListener((button,isOn)->{switchDesktop(isOn);sheet.dismiss();});
        desktop.setOnClickListener(v->sw.setChecked(!sw.isChecked()));
        LinearLayout.LayoutParams dp=Ui.layout(this,-1,68);dp.bottomMargin=Ui.dp(this,7);content.addView(desktop,dp);
        sheetRow(content,"···","More page tools",()->{sheet.dismiss();morePageTools();});
        LinearLayout tiles=new LinearLayout(this);
        LinearLayout.LayoutParams tlp=Ui.layout(this,-1,85);tlp.topMargin=Ui.dp(this,9);
        content.addView(tiles,tlp);
        menuTile(tiles,"◷","History",()->{sheet.dismiss();showSaved("history");});
        menuTile(tiles,"☆","Bookmarks",()->{sheet.dismiss();showSaved("bookmarks");});
        menuTile(tiles,"↓","Downloads",()->{sheet.dismiss();startActivity(new Intent(this,DownloadActivity.class));});
        sheetRow(content,"◇","Jin VPN",()->{sheet.dismiss();startActivity(new Intent(this,VpnActivity.class));});
        sheetRow(content,"⚙","Settings",()->{sheet.dismiss();startActivity(new Intent(this,SettingsActivity.class));});
        sheet.setContentView(scroll);
        Window window=sheet.getWindow();
        if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);window.setDimAmount(.35f);
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,(int)(getResources().getDisplayMetrics().heightPixels*.87f));}
        sheet.show();
        if(window!=null)window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                (int)(getResources().getDisplayMetrics().heightPixels*.87f));
    }
    private void menuQuick(LinearLayout row,String glyph,String title,Runnable click){
        LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setGravity(Gravity.CENTER);
        TextView symbol=Ui.text(this,glyph,27,Ui.WHITE,false);symbol.setGravity(Gravity.CENTER);
        item.addView(symbol,Ui.layout(this,-1,45));
        TextView label=Ui.text(this,title,12,Ui.MUTED,false);label.setGravity(Gravity.CENTER);
        item.addView(label,Ui.layout(this,-1,26));
        row.addView(item,new LinearLayout.LayoutParams(0,Ui.dp(this,77),1));
        item.setOnClickListener(v->click.run());
    }
    private void sheetRow(LinearLayout parent,String glyph,String title,Runnable click){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this,19),0,Ui.dp(this,18),0);row.setBackground(Ui.pill(this,Ui.PANEL,16));
        TextView symbol=Ui.text(this,glyph,23,Ui.CYAN,false);row.addView(symbol,Ui.layout(this,43,67));
        TextView label=Ui.text(this,title,16,Ui.WHITE,true);row.addView(label,new LinearLayout.LayoutParams(0,Ui.dp(this,67),1));
        row.addView(Ui.text(this,"›",24,Ui.MUTED,false),Ui.layout(this,16,67));
        LinearLayout.LayoutParams lp=Ui.layout(this,-1,67);lp.bottomMargin=Ui.dp(this,7);
        parent.addView(row,lp);row.setOnClickListener(v->click.run());
    }
    private void menuTile(LinearLayout row,String glyph,String label,Runnable click){
        LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER);item.setOrientation(1);
        item.setBackground(Ui.pill(this,Ui.PANEL,16));
        TextView symbol=Ui.text(this,glyph,25,Ui.CYAN,false);symbol.setGravity(Gravity.CENTER);
        item.addView(symbol,Ui.layout(this,-1,40));
        TextView name=Ui.text(this,label,12,Ui.WHITE,true);name.setGravity(Gravity.CENTER);
        item.addView(name,Ui.layout(this,-1,28));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,79),1);lp.rightMargin=Ui.dp(this,6);
        row.addView(item,lp);item.setOnClickListener(v->click.run());
    }
    private void sharePage(){String url=tab().view.getUrl();if(url==null||!URLUtil.isNetworkUrl(url)||url.startsWith("https://jin.home/"))return;
        Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,url);
        startActivity(Intent.createChooser(i,"Share page"));}
    private void findOnPage(){EditText query=new EditText(this);query.setSingleLine(true);query.setHint("Find text");
        new AlertDialog.Builder(this).setTitle("Find on page").setView(query)
                .setPositiveButton("Find",(d,w)->tab().view.findAllAsync(query.getText().toString()))
                .setNeutralButton("Clear",(d,w)->tab().view.clearMatches())
                .setNegativeButton("Cancel",null).show();}
    private void switchDesktop(boolean enabled){Tab t=tab();t.desktop=enabled;
        WebSettings st=t.view.getSettings();st.setUseWideViewPort(enabled);st.setLoadWithOverviewMode(enabled);
        st.setUserAgentString(enabled?desktopUserAgent():null);
        String currentUrl=t.view.getUrl();String host=Uri.parse(currentUrl==null?"":currentUrl).getHost();
        if(host!=null&&!privateMode())getSharedPreferences("browser",MODE_PRIVATE).edit()
                .putBoolean("desktop:"+host.toLowerCase(Locale.ROOT),enabled).apply();
        t.view.reload();}
    private void morePageTools(){String[] choices={"Home","New tab",privateMode()?"Close private window":"New private window","Copy page URL",
            "Open page in another app","Open Gmail app","Reload","Ad Shield for this website"};
        new AlertDialog.Builder(this).setTitle("More page tools").setItems(choices,(d,choice)->{
            switch(choice){
                case 0:home();break;
                case 1:newTab(null);break;
                case 2:if(!privateMode())startActivity(new Intent(this,PrivateActivity.class));else finish();break;
                case 3:{String url=tab().view.getUrl();if(url!=null&&URLUtil.isNetworkUrl(url)){
                    ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Page URL",url));
                    Toast.makeText(this,"Copied URL",Toast.LENGTH_SHORT).show();}break;}
                case 4:openExternally(tab().view.getUrl());break;
                case 5:openGmail();break;
                case 6:tab().view.reload();break;
                case 7:siteAdToggle();break;
            }
        }).show();}
    private void siteAdToggle(){String raw=tab().view.getUrl();String host=Uri.parse(raw==null?"":raw).getHost();
        if(host==null||host.equals("jin.home")){Toast.makeText(this,"Open a website first",Toast.LENGTH_SHORT).show();return;}
        String key="ad_exception:"+host.toLowerCase(Locale.ROOT);
        boolean except=getSharedPreferences("browser",MODE_PRIVATE).getBoolean(key,false);
        new AlertDialog.Builder(this).setTitle("Jin Ad Shield · "+host)
            .setMessage("Ad Shield is "+(except?"disabled":"enabled")+" for this site. Change and reload?")
            .setNegativeButton("Cancel",null).setPositiveButton(except?"Enable":"Disable",(d,w)->{
                getSharedPreferences("browser",MODE_PRIVATE).edit().putBoolean(key,!except).apply();tab().view.reload();
            }).show();}
    private String desktopUserAgent() {
        String base = WebSettings.getDefaultUserAgent(this);
        Matcher m = Pattern.compile("Chrome/[0-9.]+").matcher(base);
        String version = m.find() ? m.group() : "Chrome/131.0.0.0";
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                + version + " Safari/537.36";
    }
    private void applySiteDesktop(Tab t, String url) {
        if (privateMode() || url == null) return;
        String host = Uri.parse(url).getHost();
        if (host == null) return;
        boolean wanted = getSharedPreferences("browser", MODE_PRIVATE)
                .getBoolean("desktop:" + host.toLowerCase(Locale.ROOT),
                        getSharedPreferences("browser",MODE_PRIVATE).getBoolean("default_desktop",false));
        if (t.desktop == wanted) return;
        t.desktop = wanted;
        t.view.getSettings().setUseWideViewPort(wanted);
        t.view.getSettings().setLoadWithOverviewMode(wanted);
        t.view.getSettings().setUserAgentString(wanted ? desktopUserAgent() : null);
    }
    private void showThemeSelector() {
        String[] options = {"Follow system", "Light", "Dark"};
        String currentTheme = getSharedPreferences("browser", MODE_PRIVATE).getString("theme", "system");
        int selection = "dark".equals(currentTheme) ? 2 : "light".equals(currentTheme) ? 1 : 0;
        new AlertDialog.Builder(this).setTitle("Appearance")
            .setSingleChoiceItems(options, selection, (dialog, which) -> {
                getSharedPreferences("browser", MODE_PRIVATE).edit()
                    .putString("theme", which == 2 ? "dark" : which == 1 ? "light" : "system").apply();
                dialog.dismiss(); recreate();
            }).setNegativeButton("Cancel", null).show();
    }
    private void showSuggestionsSettings() {
        boolean enabled = getSharedPreferences("browser", MODE_PRIVATE)
                .getBoolean("online_suggestions", false);
        new AlertDialog.Builder(this).setTitle("Online search suggestions")
                .setMessage("When enabled, Jin sends words you type into the address bar to Google's suggestions endpoint. Local history suggestions work offline. Private tabs never send online suggestions.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton(enabled ? "Turn OFF" : "Turn ON", (d, which) -> {
                    getSharedPreferences("browser", MODE_PRIVATE).edit()
                            .putBoolean("online_suggestions", !enabled).apply();
                    Toast.makeText(this, !enabled ? "Online suggestions enabled" : "Online suggestions disabled", Toast.LENGTH_SHORT).show();
                }).show();
    }
    private void openGmail() {
        try {
            Intent gmail = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
            if (gmail != null) { startActivity(gmail); return; }
        } catch (Exception ignored) {}
        openExternally("https://mail.google.com/mail/u/0/");
    }
    private void openExternally(String url) {
        if (!URLUtil.isNetworkUrl(url)) return;
        try {
            Intent external = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            external.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(Intent.createChooser(external, "Open in another app"));
        } catch (Exception e) { Toast.makeText(this,"No installed app can open this page",Toast.LENGTH_LONG).show(); }
    }
    private void openExternalLink(String raw, WebView source) {
        try {
            Uri uri = Uri.parse(raw); String scheme = uri.getScheme();
            if (scheme == null) return;
            if ("intent".equalsIgnoreCase(scheme)) {
                String linkPref=getSharedPreferences("browser",MODE_PRIVATE).getString("external_links","ask");
                if("browser".equals(linkPref)){Toast.makeText(this,"External app links disabled",Toast.LENGTH_SHORT).show();return;}
                if("ask".equals(linkPref)){
                    new AlertDialog.Builder(this).setTitle("Open another app?")
                        .setMessage("A website wants to open an installed app. Continue only if you trust this site.")
                        .setNegativeButton("Cancel",null).setPositiveButton("Open",(d,w)->launchIntentLink(raw,source)).show();
                    return;
                }
                launchIntentLink(raw,source);return;
            }
            if ("mailto".equalsIgnoreCase(scheme)) {
                startActivity(new Intent(Intent.ACTION_SENDTO, uri)); return;
            }
            if ("tel".equalsIgnoreCase(scheme)) {
                startActivity(new Intent(Intent.ACTION_DIAL, uri)); return;
            }
            if ("javascript".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme) ||
                    "data".equalsIgnoreCase(scheme)) return;
            Intent external = new Intent(Intent.ACTION_VIEW, uri);
            external.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(external);
        } catch (Exception error) { Toast.makeText(this,"No compatible app found",Toast.LENGTH_SHORT).show(); }
    }
    private void launchIntentLink(String raw,WebView source){
        try{
            Intent target=Intent.parseUri(raw,Intent.URI_INTENT_SCHEME);
            String fallback=target.getStringExtra("browser_fallback_url");
            target.removeExtra("browser_fallback_url");target.addCategory(Intent.CATEGORY_BROWSABLE);
            target.setComponent(null);target.setSelector(null);
            try{startActivity(target);}catch(ActivityNotFoundException e){
                if(fallback!=null&&URLUtil.isNetworkUrl(fallback))source.loadUrl(fallback);
                else Toast.makeText(this,"App not installed",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Cannot open app link",Toast.LENGTH_SHORT).show();}
    }
    private void showDeveloperOptions() {
        if (privateMode()) {
            new AlertDialog.Builder(this).setTitle("Developer options")
                    .setMessage("Remote WebView inspection is disabled in private mode.")
                    .setPositiveButton("OK", null).show(); return;
        }
        boolean active = getSharedPreferences("browser", MODE_PRIVATE).getBoolean("developer_debugging", false);
        new AlertDialog.Builder(this).setTitle("Developer options")
                .setMessage("Remote WebView debugging is " + (active ? "ON" : "OFF") +
                        ".\n\nWith USB debugging enabled, connect your Android phone to a trusted PC and visit chrome://inspect/#devices in desktop Chrome. " +
                        "This is not Chrome extension support or a built-in mobile inspector. " +
                        "Turn debugging off after use; a connected computer may inspect opened pages.")
                .setNegativeButton("Close", null)
                .setNeutralButton("Turn OFF", (d, w) -> setDeveloperDebugging(false))
                .setPositiveButton("Turn ON", (d, w) -> setDeveloperDebugging(true)).show();
    }
    private void setDeveloperDebugging(boolean enabled) {
        getSharedPreferences("browser", MODE_PRIVATE).edit().putBoolean("developer_debugging", enabled).apply();
        WebView.setWebContentsDebuggingEnabled(enabled);
        Toast.makeText(this, enabled ? "Remote inspection enabled" : "Remote inspection disabled", Toast.LENGTH_SHORT).show();
    }
    private void addBookmark() {
        String url = tab().view.getUrl();
        if (url == null || !URLUtil.isNetworkUrl(url) || url.startsWith("https://jin.home/")) return;
        try {
            JSONArray saved = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("bookmarks", "[]"));
            for (int i=0;i<saved.length();i++) if (url.equals(saved.getJSONObject(i).optString("url"))) {
                Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show(); return;
            }
            JSONObject item = new JSONObject().put("url", url).put("title", tab().title);
            saved.put(item);
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("bookmarks", saved.toString()).apply();
            Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { Toast.makeText(this, "Could not save bookmark", Toast.LENGTH_SHORT).show(); }
    }
    private void saveHistory(String url, String title) {
        try {
            JSONArray previous = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("history", "[]"));
            JSONArray next = new JSONArray();
            next.put(new JSONObject().put("url", url).put("title", title));
            for (int i=0;i<Math.min(previous.length(),199);i++) {
                JSONObject item = previous.optJSONObject(i);
                if (item != null && !url.equals(item.optString("url"))) next.put(item);
            }
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("history", next.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void showSaved(String kind) {
        try {
            JSONArray a = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString(kind, "[]"));
            if (a.length() == 0) { Toast.makeText(this, "No " + kind + " yet", Toast.LENGTH_SHORT).show(); return; }
            String[] labels = new String[a.length()];
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                labels[i]=o.optString("title", "Page") + "\n" + o.optString("url", "");
            }
            new AlertDialog.Builder(this).setTitle(kind.equals("history") ? "Recent history" : "Bookmarks")
                .setItems(labels, (dialog,which)->navigate(a.optJSONObject(which).optString("url")))
                .setNegativeButton("Close", null).show();
        } catch (Exception ignored) { Toast.makeText(this,"Unable to read saved pages",Toast.LENGTH_SHORT).show(); }
    }
    private void clearBrowsingData() {
        new AlertDialog.Builder(this).setTitle("Clear browsing data?")
            .setMessage("Delete normal browsing history, bookmarks, cookies and website storage. Downloads are preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (dialog,which)->{
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                for (Tab t : tabs) { t.view.clearCache(true); t.view.clearHistory(); }
                getSharedPreferences("browser", MODE_PRIVATE).edit()
                        .remove("bookmarks").remove("history").remove("queries").apply();
                Toast.makeText(this,"Browsing data cleared",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void persist() {
        if (privateMode() || current < 0) return;
        JSONArray arr = new JSONArray();
        for (Tab t : tabs) arr.put(t.lastUrl == null ? "" : t.lastUrl);
        getSharedPreferences("browser", MODE_PRIVATE).edit().putString("tabs", arr.toString())
                .putInt("current_tab", current).apply();
    }
    private void restoreTabs() {
        String raw = getSharedPreferences("browser", MODE_PRIVATE).getString("tabs", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < Math.min(a.length(), MAX_TABS); i++) {
                String url = a.optString(i, "");
                if (!url.isEmpty() && URLUtil.isNetworkUrl(url)) newTab(url);
                else newTab(null);
            }
        } catch (Exception ignored) { tabs.clear(); }
    }
    @Override public void onBackPressed() {
        if (tab().view.canGoBack()) tab().view.goBack();
        else if (tabs.size() > 1) closeTab();
        else super.onBackPressed();
    }
    @Override protected void onPause() {
        super.onPause();persist();adShield.persist(); /* Keep WebViews alive; do not pauseTimers. */
    }
    @Override protected void onResume() {
        super.onResume();
        boolean was=appliedDark;Ui.init(this);
        if(was!=Ui.DARK){recreate();return;}
        Ui.status(this);
    }
    @Override protected void onDestroy() {
        suggestHandler.removeCallbacksAndMessages(null);
        suggestWorker.shutdownNow();
        if(adShield!=null)adShield.persist();
        for (Tab t : tabs) { if (t.view.getParent() instanceof ViewGroup) ((ViewGroup)t.view.getParent()).removeView(t.view); t.view.destroy(); }
        tabs.clear();
        if (privateMode()) { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); }
        super.onDestroy();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DOWNLOAD_FOLDER_REQUEST) {
            DownloadJob job = pendingFolderJob;
            String cookie = pendingFolderCookie;
            pendingFolderJob = null; pendingFolderCookie = null;
            if (resultCode == RESULT_OK && job != null && data != null && data.getData() != null) {
                Uri folder = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(folder,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    job.folderUri = folder.toString();
                    TurboDownloadService.enqueue(this, job, cookie);
                    startActivity(new Intent(this, DownloadActivity.class));
                } catch (Exception error) {
                    Toast.makeText(this,"Cannot access selected folder. Choose Downloads instead.",Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == UPLOAD_REQUEST && uploadCallback != null) {
            uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            uploadCallback = null;
        }
    }
}
