
'use strict';
const wallpaperMode='daily';
let chosen=Number('1');
function localDay(){const d=new Date();return Math.floor(new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime()/86400000)}
let currentDay=localDay();
function pickWallpaper(){if(wallpaperMode==='fixed')return Math.min(6,Math.max(1,chosen));if(wallpaperMode==='open')return 1+Math.floor(Math.random()*6);return 1+(currentDay%6)}
function setWallpaper(number){chosen=number;document.getElementById('hero').style.backgroundImage='url("https://jin.home/wallpaper/mountain_'+number+'.webp")'}
setWallpaper(pickWallpaper());
document.getElementById('wallChange').addEventListener('click',()=>setWallpaper(chosen%6+1));
setInterval(()=>{let day=localDay();if(day!==currentDay){currentDay=day;if(wallpaperMode==='daily')setWallpaper(pickWallpaper())}},3600000);
const clock=document.getElementById('clock'),date=document.getElementById('date');
function tick(){let n=new Date();clock.textContent=new Intl.DateTimeFormat(undefined,{hour:'numeric',minute:'2-digit'}).format(n);date.textContent=new Intl.DateTimeFormat(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(n)}tick();setInterval(tick,30000);
const form=document.getElementById('searchForm'),input=document.getElementById('search'),box=document.getElementById('suggestions');
const recents=[];
function submit(value){let q=(value||'').trim();if(!q)return;box.classList.remove('visible');location.assign('https://jin.home/search?q='+encodeURIComponent(q))}
form.addEventListener('submit',event=>{event.preventDefault();submit(input.value)});
function renderSuggestions(){let q=input.value.trim().toLowerCase();box.replaceChildren();if(!q){box.classList.remove('visible');return;}let seen=new Set();let match=recents.filter(s=>{let v=String(s||'').trim();if(!v.toLowerCase().includes(q)||seen.has(v.toLowerCase()))return false;seen.add(v.toLowerCase());return true}).slice(0,5);for(let value of match){let b=document.createElement('button');b.type='button';let icon=document.createElement('span');icon.className='mark';icon.textContent='◷';let label=document.createElement('span');label.textContent=value;b.append(icon,label);b.addEventListener('click',()=>submit(value));box.append(b)}box.classList.toggle('visible',!!match.length)}
input.addEventListener('input',renderSuggestions);input.addEventListener('focus',renderSuggestions);
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))box.classList.remove('visible')});
const select=document.getElementById('city'),temperature=document.getElementById('weatherTemp'),description=document.getElementById('weatherDesc'),icon=document.getElementById('weatherIcon');
const weatherNames=code=>{if(code===0)return['☀','Clear'];if(code<=3)return['⛅','Cloudy'];if(code<=48)return['☁','Fog'];if(code<=67)return['☂','Rain'];if(code<=77)return['❄','Snow'];if(code<=82)return['☂','Showers'];if(code<=86)return['❄','Snow'];return['⚡','Storm']};
const saved=localStorage.getItem('jin-city');if(saved){if(![...select.options].some(x=>x.value===saved)){let e=document.createElement('option');e.value=saved;e.textContent=saved.split('|')[0];select.add(e,select.options.length-1)}select.value=saved}
async function weather(){if(!select.value||select.value==='Other')return;const[name,lat,lon]=select.value.split('|');temperature.textContent='Loading…';description.textContent=name;let ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),10000);try{const r=await fetch('https://api.open-meteo.com/v1/forecast?latitude='+lat+'&longitude='+lon+'&current=temperature_2m,weather_code&timezone=auto',{signal:ctl.signal});if(!r.ok)throw Error('Unavailable');const j=await r.json();if(typeof j?.current?.temperature_2m!=='number')throw Error('Invalid');let[g,l]=weatherNames(j.current.weather_code);icon.textContent=g;temperature.textContent=Math.round(j.current.temperature_2m)+'°C';description.textContent=name+' · '+l;}catch(e){temperature.textContent='Offline';description.textContent=name+' · Retry later';}finally{clearTimeout(timer)}}
const extra=document.getElementById('citySearch'),name=document.getElementById('cityName'),find=document.getElementById('cityFind'),matches=document.getElementById('cityMatches');
select.addEventListener('change',()=>{if(select.value==='Other'){extra.hidden=false;return;}extra.hidden=true;if(select.value)localStorage.setItem('jin-city',select.value);else localStorage.removeItem('jin-city');weather()});
find.addEventListener('click',async()=>{let q=name.value.trim();if(q.length<2)return;find.disabled=true;find.textContent='Finding…';matches.hidden=true;try{let r=await fetch('https://geocoding-api.open-meteo.com/v1/search?name='+encodeURIComponent(q)+'&count=5&language=en&format=json');if(!r.ok)throw Error('Offline');let j=await r.json();matches.replaceChildren();let first=document.createElement('option');first.value='';first.textContent='Select city';matches.add(first);for(let x of j.results||[]){let option=document.createElement('option');option.value=[x.name+', '+x.country,x.latitude,x.longitude].join('|');option.textContent=x.name+', '+x.country;matches.add(option)}matches.hidden=false}catch(e){temperature.textContent='City unavailable';description.textContent='Check connection'}finally{find.disabled=false;find.textContent='Find'}});
matches.addEventListener('change',()=>{if(!matches.value)return;let x=document.createElement('option');x.value=matches.value;x.textContent=matches.selectedOptions[0].textContent;select.add(x,select.options.length-1);select.value=x.value;localStorage.setItem('jin-city',x.value);extra.hidden=true;weather()});
if(select.value)weather();setInterval(()=>{if(!document.hidden)weather()},900000);
