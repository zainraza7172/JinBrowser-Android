package com.jinbrowser.app;

import java.util.Random;

public final class RangeMathTest {
    public static void main(String[] args) {
        long[] totals={0,1,2,3,9,13,1024,262143,262144,256611,1000000000L,5L*1024*1024*1024,Long.MAX_VALUE/1000};
        int cases=0;
        for(long total:totals) for(int parts: new int[]{1,4,8,16}) {
            long next=0,sum=0;
            for(int i=0;i<parts;i++) {
                long start=RangeMath.start(total,parts,i), end=RangeMath.end(total,parts,i);
                if(start!=next || end<start-1) throw new AssertionError("Non-contiguous range: "+total+" part "+i+" -> "+start+"-"+end+" expected "+next);
                long len=end-start+1;
                if(len<0) throw new AssertionError("Negative segment");
                sum+=len;
                next=end+1;
            }
            if(sum!=total || next!=total) throw new AssertionError("Lost or duplicated bytes: "+total+" / "+parts);
            cases++;
        }
        Random r = new Random(71);
        for (int sample = 0; sample < 10_000; sample++) {
            long total = (sample % 9 == 0) ? Math.abs(r.nextLong() / 1024) : Math.abs(r.nextLong() % 1_000_000_000L);
            int parts = new int[]{1,4,8,16}[sample % 4];
            long next = 0, sum = 0;
            for (int i = 0; i < parts; i++) {
                long start = RangeMath.start(total,parts,i);
                long end = RangeMath.end(total,parts,i);
                if (start != next || end < start - 1) throw new AssertionError("Overlapping or missing bytes");
                sum += end - start + 1;
                next = end + 1;
            }
            if (sum != total || next != total) throw new AssertionError("Incorrect total partition size");
            cases++;
        }
        for (int invalid = 0; invalid < 3; invalid++) {
            try {
                if (invalid == 0) RangeMath.start(100,0,0);
                else if (invalid == 1) RangeMath.end(100,8,-1);
                else RangeMath.start(-1,1,0);
                throw new AssertionError("Invalid input accepted");
            } catch (IllegalArgumentException expected) { /* correct */ }
        }
        System.out.println("PASS: "+cases+" byte-range partition tests (52 fixed + 10,000 seeded random) and 3 invalid-input checks.");
    }
}
