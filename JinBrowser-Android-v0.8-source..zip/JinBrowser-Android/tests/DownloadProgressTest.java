package com.jinbrowser.app;

public final class DownloadProgressTest {
    private static int count;
    private static void equal(long actual, long expected, String label) {
        if (actual != expected) throw new AssertionError(label+": expected "+expected+", got "+actual);
        count++;
    }
    public static void main(String[] args) {
        equal(DownloadProgress.bytesPerSecond(1048576,1000),1048576,"1MiB/s");
        equal(DownloadProgress.bytesPerSecond(1024,500),2048,"2KiB/s");
        equal(DownloadProgress.bytesPerSecond(-10,300),0,"negative byte delta");
        equal(DownloadProgress.bytesPerSecond(10,0),0,"zero elapsed");
        equal(DownloadProgress.bytesPerSecond(Long.MAX_VALUE,1),Long.MAX_VALUE,"rate overflow");
        equal(DownloadProgress.etaSeconds(2000,1000,500),2,"remaining time");
        equal(DownloadProgress.etaSeconds(2000,2000,500),0,"complete");
        equal(DownloadProgress.etaSeconds(2000,3000,500),0,"overcomplete");
        equal(DownloadProgress.etaSeconds(-1,100,100),-1,"unknown total");
        equal(DownloadProgress.etaSeconds(3000,1000,0),-1,"unknown speed");
        equal(DownloadProgress.etaSeconds(100,0,30),4,"ceil ETA");
        equal(DownloadProgress.smooth(300,0),200,"smoothing slow down");
        equal(DownloadProgress.smooth(0,100),100,"initial speed");
        System.out.println("PASS: " + count + " download speed, smoothing and ETA tests.");
    }
}
