package com.jinbrowser.app;

/** Standalone Java regression tests for Open File MIME resolution. */
public final class MimeTypesTest {
    private static int passed = 0;
    private static void assertMime(String name, String reported, String expected) {
        String actual = MimeTypes.resolve(name, reported);
        if (!expected.equals(actual)) throw new AssertionError(name + ": expected " + expected + " but was " + actual);
        passed++;
    }
    public static void main(String[] args) {
        assertMime("release.apk", "application/octet-stream", "application/vnd.android.package-archive");
        assertMime("release.APK", "binary/octet-stream", "application/vnd.android.package-archive");
        assertMime("report.pdf", null, "application/pdf");
        assertMime("archive.zip", "application/octet-stream", "application/zip");
        assertMime("holiday.JPG", "application/octet-stream", "image/jpeg");
        assertMime("holiday.jpeg", "", "image/jpeg");
        assertMime("screenshot.png", null, "image/png");
        assertMime("video.mp4", "application/octet-stream", "video/mp4");
        assertMime("movie.mkv", null, "video/x-matroska");
        assertMime("audio.mp3", null, "audio/mpeg");
        assertMime("notes.txt", "text/plain; charset=UTF-8", "text/plain");
        assertMime("noextension", null, "application/octet-stream");
        assertMime("unknown.custom", "application/vnd.example.special", "application/vnd.example.special");
        System.out.println("PASS: " + passed + " download filename / MIME regression tests.");
    }
}
