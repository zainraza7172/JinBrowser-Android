import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;
import javax.tools.*;

/** Parse every source, even Android-only classes, before a full SDK build. */
public final class JavaSourceParseTest {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new AssertionError("JDK required");
        DiagnosticCollector<JavaFileObject> problems = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager=compiler.getStandardFileManager(problems,null,null)) {
            List<java.io.File> sources=new ArrayList<>();
            try(var paths=Files.walk(Path.of("app/src/main/java"))) {
                paths.filter(p->p.toString().endsWith(".java")).forEach(p->sources.add(p.toFile()));
            }
            JavacTask task=(JavacTask)compiler.getTask(null,manager,problems,
                    List.of("-proc:none"),null,manager.getJavaFileObjectsFromFiles(sources));
            task.parse();
            long errors=problems.getDiagnostics().stream()
                    .filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
            if(errors>0)throw new AssertionError("Java syntax: "+problems.getDiagnostics());
            System.out.println("PASS: "+sources.size()+" Android Java source files parse without syntax errors");
        }
    }
}
