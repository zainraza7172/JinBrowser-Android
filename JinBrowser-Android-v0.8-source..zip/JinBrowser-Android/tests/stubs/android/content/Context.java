package android.content;
import java.io.File;
public class Context {
  public static final int MODE_PRIVATE=0;
  public File getFilesDir(){return new File(".");}
  public SharedPreferences getSharedPreferences(String s,int m){return new SharedPreferences();}
}
