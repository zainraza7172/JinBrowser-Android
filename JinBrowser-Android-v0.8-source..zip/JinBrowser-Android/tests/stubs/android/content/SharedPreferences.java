package android.content;
public class SharedPreferences {
  public Editor edit(){return new Editor();}
  public static class Editor {
    public Editor putLong(String s,long value){return this;}
    public Editor putInt(String s,int value){return this;}
    public void apply(){}
  }
}
