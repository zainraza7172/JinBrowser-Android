package com.jinbrowser.app;
public class DesktopRoutingTest {
    private static void eq(String a, String b) { if(!a.equals(b)) throw new AssertionError(a+" != "+b); }
    public static void main(String[] args) {
        eq(DesktopRouting.normalize("https://m.youtube.com/watch?v=A&list=B#top",true),"https://www.youtube.com/watch?v=A&list=B#top");
        eq(DesktopRouting.normalize("http://m.youtube.com/results?search_query=music",true),"https://www.youtube.com/results?search_query=music");
        eq(DesktopRouting.normalize("https://M.GOOGLE.COM/search?q=abc",true),"https://www.google.com/search?q=abc");
        eq(DesktopRouting.normalize("https://m.youtube.com/watch?v=A",false),"https://m.youtube.com/watch?v=A");
        eq(DesktopRouting.normalize("https://m.youtube.com.evil.net",true),"https://m.youtube.com.evil.net");
        eq(DesktopRouting.normalize("https://youtube.com/@creator",true),"https://youtube.com/@creator");
        eq(DesktopRouting.normalize("about:blank",true),"about:blank");
        eq(DesktopRouting.normalize("https://m.facebook.com/photo?id=5",true),"https://www.facebook.com/photo?id=5");
        System.out.println("PASS: DesktopRouting, mobile redirects, host safety, URL paths and OFF mode");
    }
}
