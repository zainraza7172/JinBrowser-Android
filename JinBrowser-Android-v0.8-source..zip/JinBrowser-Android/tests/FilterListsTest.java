package com.jinbrowser.app;
import java.util.HashSet;
public class FilterListsTest {
  static void ok(boolean v,String label){if(!v)throw new AssertionError(label);}
  public static void main(String[] args){
    ok("ads.example.com".equals(FilterLists.parseDomainRule("||ads.example.com^")),"plain ABP host");
    ok("cdn.badads.net".equals(FilterLists.parseDomainRule("||cdn.badads.net^$third-party")),"3rd party host");
    ok(FilterLists.parseDomainRule("@@||allow.example.com^")==null,"whitelist must not become blocklist");
    ok(FilterLists.parseDomainRule("||example.com/path^")==null,"path rule unsupported");
    ok(FilterLists.parseDomainRule("||example.com^$important,domain=foo.com")==null,"complex modifier unsupported");
    ok(FilterLists.parseDomainRule("||...^")==null,"invalid host");
    HashSet<String> hosts=new HashSet<>();hosts.add("ads.example.com");hosts.add("track.badads.net");
    ok(FilterLists.matches(hosts,"ads.example.com"),"direct host");
    ok(FilterLists.matches(hosts,"a.b.ads.example.com"),"child host");
    ok(!FilterLists.matches(hosts,"notads.example.com"),"collision");
    ok(!FilterLists.matches(hosts,"example.com"),"top site");
    for(int i=0;i<10000;i++){
        ok(FilterLists.matches(hosts,"layer"+i+".ads.example.com"),"stress allow match");
        ok(!FilterLists.matches(hosts,"layer"+i+".safe.example.com"),"stress false positive");
    }
    System.out.println("PASS: 20,010 downloaded filter-parser/matcher checks");
  }
}
