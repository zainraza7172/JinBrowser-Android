package com.jinbrowser.app;
public final class AdBlockRulesTest {
    private static void ok(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        ok(AdBlockRules.isAdHost("doubleclick.net"),"exact host");
        ok(AdBlockRules.isAdHost("ad.doubleclick.net"),"subdomain");
        ok(AdBlockRules.isAdHost("AA.TABOOLA.COM"),"case-insensitive");
        ok(!AdBlockRules.isAdHost("notdoubleclick.net"),"suffix collision");
        ok(!AdBlockRules.isAdHost("doubleclick.net.example.com"),"prefix collision");
        ok(!AdBlockRules.isAdHost("youtube.com"),"do not break regular video playback");
        ok(AdBlockRules.sameSite("images.example.com","example.com"),"same site");
        ok(!AdBlockRules.sameSite("evil-example.com","example.com"),"different site");
        for(int i=0;i<10000;i++){
            String sub="node"+i+".doubleclick.net";
            ok(AdBlockRules.isAdHost(sub),sub);
            ok(!AdBlockRules.isAdHost("node"+i+".example.com"),"false positive");
        }
        System.out.println("PASS: 20,008 ad-domain rules checks");
    }
}
