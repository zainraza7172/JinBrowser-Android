package com.jinbrowser.app;
public class SheetGestureTest {
    public static void main(String[] args) {
        if (SheetGesture.shouldClose(50,1) || !SheetGesture.shouldClose(74,1)) throw new AssertionError("dp threshold");
        if (SheetGesture.shouldClose(100,2) || !SheetGesture.shouldClose(160,2)) throw new AssertionError("density threshold");
        if (SheetGesture.dragProgress(-15,1)!=0f || SheetGesture.dragProgress(900,1)!=1f) throw new AssertionError("bounded drag");
        System.out.println("PASS: SheetGesture swipe-to-close thresholds and animation bounds");
    }
}
