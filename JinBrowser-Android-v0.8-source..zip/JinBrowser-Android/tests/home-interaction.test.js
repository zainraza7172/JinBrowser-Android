const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const raw=fs.readFileSync('app/src/main/assets/start.html','utf8');
const script=raw.match(/<script>([\s\S]*?)<\/script>/)[1]
   .replace('__WALLPAPER_MODE__','daily').replace('__WALLPAPER_INDEX__','1')
   .replace('__RECENTS_JSON__',JSON.stringify(['zain news','zebra pictures','weather']));
const nodes=new Map();
function node(id){if(!nodes.has(id))nodes.set(id,{
    id,value:'',textContent:'',hidden:true,style:{},options:[],events:{},children:[],
    classList:{visible:false,add(){this.visible=true},remove(){this.visible=false},toggle(_cls,v){this.visible=!!v}},
    addEventListener(event,fn){this.events[event]=fn},replaceChildren(){this.children=[]},
    append(...children){this.children.push(...children)},add(el){this.options.push(el)},
    closest(){return null},
} );return nodes.get(id)}
const urls=[];
const env={document:{getElementById:node,createElement:()=>node('created'+Math.random()),
     addEventListener(){}},localStorage:{getItem(){return null},setItem(){},removeItem(){}},
  location:{assign(value){urls.push(value)}},console,Date,Intl,Math,Number,String,
  setInterval(){},setTimeout(){},clearTimeout(){},fetch(){throw new Error('Unexpected weather fetch')},
  AbortController};
vm.runInNewContext(script,env);
assert.notEqual(node('clock').textContent,'--:--','real local clock is displayed');
assert(node('hero').style.backgroundImage.includes('mountain_'),'wallpaper present');
const original=node('hero').style.backgroundImage;
node('wallChange').events.click();
assert.notEqual(node('hero').style.backgroundImage,original,'wallpaper manually changes');
node('search').value='z';node('search').events.input();
assert(node('suggestions').classList.visible,'local search suggestions are visible');
assert.equal(node('suggestions').children.length,2,'both matching queries suggested');
node('search').value='zain graphics';node('searchForm').events.submit({preventDefault(){}});
assert.equal(urls[0],'https://jin.home/search?q=zain%20graphics','center search routes through native browser');
console.log('PASS: daily wallpaper, refresh, local clock, search suggestion display and center search interaction');
