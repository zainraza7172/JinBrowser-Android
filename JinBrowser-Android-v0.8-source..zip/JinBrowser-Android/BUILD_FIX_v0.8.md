# Jin Browser v0.8 build repair

GitHub Actions Build #20 stopped while compiling `SettingsActivity.java`: `Settings.ACTION_PICTURE_IN_PICTURE_SETTINGS` is not defined by Android SDK 35.

Fixed by using the corresponding intent action string `android.settings.PICTURE_IN_PICTURE_SETTINGS` with the already-existing fallback to `Settings.ACTION_APPLICATION_DETAILS_SETTINGS` if the target settings screen is unsupported. Added a source regression check so the undefined constant cannot be reintroduced unnoticed.

The existing `.github/workflows/build-apk.yml` watches `JinBrowser-Android-v0.8-source.zip` on `main`. Replace the existing source ZIP with this corrected archive in the repository, commit it, and GitHub Actions should start automatically. A completed SDK build is needed before calling the APK verified.
