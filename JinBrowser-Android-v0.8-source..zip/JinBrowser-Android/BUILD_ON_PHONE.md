Android source, see README.md for the current build and GitHub Actions instructions.
