# Jin Browser v0.8 — desktop, background media and bottom sheet fixes

This is the Android **source project**, not a tested APK. To produce an installable debug APK:

1. Upload `JinBrowser-Android-v0.8-source.zip` (not the full kit ZIP) to `https://github.com/zainraza7172/JinBrowser-Android/upload/main`.
2. Replace `.github/workflows/build-apk.yml` with the `build-apk-v0.8.yml` from the complete kit and commit to `main`.
3. In GitHub Actions open the latest successful **Build Jin Browser v0.8 APK** run. Download the `JinBrowser-v0.8-debug-APK` artifact; extract `app-debug.apk`.

## Changes from v0.7

- Desktop setting is applied **before the first request** of each tab, is retained across links and new tabs, uses desktop Chrome UA and desktop viewport (including an opt-in desktop-width CSS override), and rewrites known mobile URLs (including `m.youtube.com` and `m.google.com`) to their desktop hosts with a redirect-loop guard. User-agent mode persists until turned off in Settings or Menu. Sites may still deliver responsive/mobile layouts or block embedded WebView browsing.
- Background media **is opt-in**. When HTML5 audio/video is playing the app starts an Android foreground media session with Play/Pause/Stop notification. Video sites can use Android picture-in-picture (PiP) when Jin is minimized, helping the WebView stay visible and its video/audio continue. The media session retains playback controls when paused. A manual **Picture-in-picture now** menu item covers embedded players that cannot be detected from the top-level page; Android settings has a PiP permission shortcut. Supports HTML5 `audio` and `video`; website-specific background playback restrictions and OS battery restrictions still apply. This is **not** a separate Media3 player, a YouTube Premium substitute, or a guarantee that every site's music plays invisibly when minimized.
- Browser menu is a bottom sheet with a clear **swipe-down grab handle**, tap-to-close `✕`, Android back dismissal, and tap-outside dismissal. Short drags snap back.
- Implements HTML5 video full-screen via WebChromeClient custom view handling.
- All existing v0.7 home/wallpapers/search/downloads/history/ad-shield code remains.

## Verify on phone

1. Switch Desktop Site ON. Open `google.com`, click multiple search results, open `m.youtube.com`, click several videos, open a link in a new tab, close/reopen Jin. Inspect whether desktop mode stays enabled. Turn it OFF to verify mobile layout returns.
2. Enable **Play in background**, start a *supported HTML5* video, wait for playback, then press Home. The PiP window and playback controls should be available on devices where PiP is enabled. Pause/resume from the notification. Test Android's PiP app setting if no window appears. Check one audio-only site separately; its background behavior may differ.
3. Open Menu and drag the **top grab handle down**, tap its `✕`, tap outside and press Android Back. Menu should dismiss in all four cases.
4. Confirm downloads, Save Folder / Open File and replacement Resume Link still work. Test original download links on servers supporting HTTP byte ranges.

## Build & security limitations

Automated host tests cover code structure, Java syntax, Android XML, mobile-host rewriting, swipe thresholds, home interactions and downloader/ad-filter calculations. A GitHub SDK build and real Android device tests are separate requirements. Debug APKs built on different GitHub runners may use different signing keys; if Android reports a signature conflict, export anything you need from the older app before uninstalling it. To distribute updates without losing local data, configure a consistent private release signing key and store it securely in GitHub secrets. Do not commit a private signing key into a public repo. Do not use this experimental browser for banking or sensitive account passwords until it has been security reviewed.
