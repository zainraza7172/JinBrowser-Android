(function () {
  // Opt-in Desktop Site: force a desktop-width CSS viewport even if a mobile
  // page includes width=device-width. Only injected on the user's desktop tabs.
  if (window.__jinDesktopViewportInstalled || !document.head) return;
  window.__jinDesktopViewportInstalled = true;
  var desired = 'width=1024, user-scalable=yes';
  function apply() {
    var viewport = document.querySelector('meta[name="viewport"]');
    if (!viewport) {
      viewport = document.createElement('meta');
      viewport.setAttribute('name', 'viewport');
      document.head.appendChild(viewport);
    }
    if (viewport.getAttribute('content') !== desired)
      viewport.setAttribute('content', desired);
  }
  apply();
  var watcher = new MutationObserver(apply);
  watcher.observe(document.head, {
    attributes: true,
    childList: true,
    subtree: true,
    attributeFilter: ['content']
  });
})();
