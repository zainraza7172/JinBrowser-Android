package com.jinbrowser.app;

/** Pure Java byte-range partitioning; also compiled by the offline self-test. */
final class RangeMath {
    private RangeMath() {}
    static long start(long total, int parts, int index) {
        if (total < 0 || parts < 1 || index < 0 || index >= parts) throw new IllegalArgumentException("Invalid range");
        return (total / parts) * index + (total % parts) * index / parts;
    }
    static long end(long total, int parts, int index) {
        if (total < 0 || parts < 1 || index < 0 || index >= parts) throw new IllegalArgumentException("Invalid range");
        return (total / parts) * (index + 1L) + (total % parts) * (index + 1L) / parts - 1;
    }
}
