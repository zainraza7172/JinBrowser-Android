package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Ikev2VpnProfile;
import android.net.VpnManager;
import android.net.VpnProfileState;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Real Android platform IKEv2 client. A genuine server and credentials are required. */
public final class VpnActivity extends Activity {
    private static final int CONSENT = 761;
    private TextView status, publicIp;
    private EditText server, identity, user, password;
    private VpnManager manager;
    @Override public void onCreate(Bundle b) {
        Ui.init(this);
        setTheme(Ui.DARK ? R.style.Theme_JinBrowser_Dark : R.style.Theme_JinBrowser);
        super.onCreate(b); Ui.status(this);
        manager = Build.VERSION.SDK_INT >= 30 ? getSystemService(VpnManager.class) : null;
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true); sc.setBackgroundColor(Ui.BG);
        LinearLayout base = new LinearLayout(this); base.setOrientation(1);
        base.setPadding(Ui.dp(this,22), Ui.dp(this,24),Ui.dp(this,22),Ui.dp(this,28));
        sc.addView(base); setContentView(sc);
        TextView back = Ui.text(this,"‹    Jin VPN",26,Ui.WHITE,true);
        back.setOnClickListener(v->finish());base.addView(back,Ui.layout(this,-1,60));
        TextView intro = Ui.text(this,"Secure IKEv2 connection",19,Ui.WHITE,true);
        base.addView(intro,Ui.layout(this,-1,54));
        TextView info=Ui.text(this,"Add your own trusted VPN provider or server below. A foreign IP cannot be generated without a real provider. Jin never pretends to be connected.",14,Ui.MUTED,false);
        info.setPadding(0,0,0,Ui.dp(this,18)); base.addView(info);
        status=Ui.text(this,"Checking connection…",16,Ui.CYAN,true);
        status.setPadding(Ui.dp(this,16),Ui.dp(this,12),Ui.dp(this,16),Ui.dp(this,12));
        status.setBackground(Ui.pill(this,Ui.PANEL,16));base.addView(status,Ui.layout(this,-1,68));
        TextView source=Ui.text(this,"Need a free VPN server? VPN Gate lists volunteer servers, but its OpenVPN and L2TP profiles cannot be imported into Jin's IKEv2 screen.",13,Ui.MUTED,false);
        source.setPadding(0,Ui.dp(this,17),0,Ui.dp(this,8));base.addView(source);
        button(base,"🌐  Browse free VPN Gate servers",()->{
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.vpngate.net/en/")));}
            catch(Exception e){error("No app could open the official VPN Gate website.");}
        });

        if (manager == null || !getPackageManager().hasSystemFeature(PackageManager.FEATURE_IPSEC_TUNNELS)) {
            TextView unavailable=Ui.text(this,"This device needs Android 11+ with platform IKEv2 support. You can still open Android's VPN settings.",15,Ui.MUTED,false);
            base.addView(unavailable,Ui.layout(this,-1,110));
            button(base,"Android VPN settings",()->startActivity(new Intent(Settings.ACTION_VPN_SETTINGS)));
            return;
        }
        server=field(base,"Server hostname (from provider)",false);
        identity=field(base,"IKE identity (from provider)",false);
        user=field(base,"VPN username",false);
        password=field(base,"VPN password",true);
        TextView caution=Ui.text(this,"Use a trusted service. Android handles the VPN tunnel and user consent. Credentials are passed to the Android VPN profile, not stored in Jin's preferences.",13,Ui.MUTED,false);
        caution.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,14));base.addView(caution);
        button(base,"Connect",this::connect);
        button(base,"Disconnect",()->{try{manager.stopProvisionedVpnProfile();updateStatus();}
                catch(Exception e){error("Could not disconnect: "+e.getMessage());}});
        button(base,"Refresh connection status",this::updateStatus);
        button(base,"Check public IP (ipify.org)",this::checkPublicIp);
        publicIp=Ui.text(this,"IP check is optional and sends your connection's public IP to ipify.org.",13,Ui.MUTED,false);
        publicIp.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,8));base.addView(publicIp);
        updateStatus();
    }
    private EditText field(LinearLayout root,String hint,boolean secret){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(Ui.WHITE);
        e.setHintTextColor(Ui.MUTED);e.setTextSize(15);e.setPadding(Ui.dp(this,12),0,Ui.dp(this,12),0);
        e.setBackground(Ui.pill(this,Ui.PANEL,12));
        e.setInputType(secret?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout.LayoutParams lp=Ui.layout(this,-1,52);lp.topMargin=Ui.dp(this,12);root.addView(e,lp);return e;
    }
    private void button(LinearLayout root,String name,Runnable click){
        TextView t=Ui.text(this,name,16,Ui.WHITE,true);t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.pill(this,Ui.PANEL,13));
        LinearLayout.LayoutParams p=Ui.layout(this,-1,52);p.topMargin=Ui.dp(this,10);root.addView(t,p);
        t.setOnClickListener(v->click.run());
    }
    private void connect(){
        String s=server.getText().toString().trim(), id=identity.getText().toString().trim();
        String u=user.getText().toString().trim(),pw=password.getText().toString();
        if(s.isEmpty()||id.isEmpty()||u.isEmpty()||pw.isEmpty()){
            error("Enter the actual server address, IKE identity, username and password from your VPN provider.");return;
        }
        if(s.contains("://")||s.contains("/")||s.contains(" ")){error("Use a server hostname, not a web URL.");return;}
        try {
            Ikev2VpnProfile profile = new Ikev2VpnProfile.Builder(s,id)
                    .setAuthUsernamePassword(u,pw,null).setBypassable(false).build();
            Intent consent=manager.provisionVpnProfile(profile);
            if(consent!=null){status.setText("Awaiting Android VPN consent…");startActivityForResult(consent,CONSENT);}
            else startProvisioned();
        }catch(Exception e){error("VPN setup failed: "+e.getMessage());}
    }
    @Override protected void onActivityResult(int r,int result,Intent data){
        super.onActivityResult(r,result,data);
        if(r==CONSENT){if(result==RESULT_OK)startProvisioned();else status.setText("Consent denied · Disconnected");}
    }
    private void startProvisioned(){
        try{ if(Build.VERSION.SDK_INT>=33)manager.startProvisionedVpnProfileSession();
            else manager.startProvisionedVpnProfile();
            status.setText("Connecting… Check status in a moment.");
            status.postDelayed(this::updateStatus,2500);
        }catch(Exception e){error("Connection could not start: "+e.getMessage());}
    }
    private void updateStatus(){
        if(manager==null){status.setText("VPN not supported on this Android version");return;}
        try{
            if(Build.VERSION.SDK_INT>=33){
                VpnProfileState st=manager.getProvisionedVpnProfileState();
                int state=st==null?VpnProfileState.STATE_DISCONNECTED:st.getState();
                status.setText(state==VpnProfileState.STATE_CONNECTED?"Connected · Android IKEv2":
                        state==VpnProfileState.STATE_CONNECTING?"Connecting…":
                        state==VpnProfileState.STATE_FAILED?"Connection failed · Check provider credentials":"Disconnected");
            }else status.setText("Android 11–12: view connection status in system VPN settings");
        }catch(Exception e){status.setText("Status unavailable: "+e.getMessage());}
    }
    private void checkPublicIp(){
        if(Build.VERSION.SDK_INT>=33){
            try{VpnProfileState current=manager.getProvisionedVpnProfileState();
                if(current==null||current.getState()!=VpnProfileState.STATE_CONNECTED){
                    error("Connect your VPN first. No external IP-check request was sent.");return;
                }
            }catch(Exception e){error("Cannot verify VPN status: "+e.getMessage());return;}
        }
        publicIp.setText("Checking public IP…");
        new Thread(()->{
            java.net.HttpURLConnection c=null;
            try{
                c=(java.net.HttpURLConnection)new java.net.URL("https://api.ipify.org?format=json").openConnection();
                c.setConnectTimeout(4500);c.setReadTimeout(4500);
                if(c.getResponseCode()!=200)throw new java.io.IOException("IP-check service unavailable");
                byte[] data=new byte[256];int n;
                try(java.io.InputStream input=c.getInputStream()){n=input.read(data);}
                if(n<1)throw new java.io.IOException("Empty response");
                String value=new org.json.JSONObject(new String(data,0,n,java.nio.charset.StandardCharsets.UTF_8)).optString("ip","");
                if(value.isEmpty())throw new java.io.IOException("Missing public IP");
                runOnUiThread(()->publicIp.setText("Public IP: "+value+" · Provider/country is not verified here"));
            }catch(Exception error){runOnUiThread(()->publicIp.setText("IP lookup failed: "+error.getMessage()));}
            finally{if(c!=null)c.disconnect();}
        },"jin-ip-check").start();
    }
    private void error(String message){new AlertDialog.Builder(this).setTitle("Jin VPN").setMessage(message).setPositiveButton("OK",null).show();}
    @Override protected void onResume(){super.onResume();if(status!=null)updateStatus();}
}
