package com.jinbrowser.app;

import java.util.Locale;

/** File extension fallback when servers return generic application/octet-stream. */
final class MimeTypes {
    private MimeTypes() {}
    static String resolve(String filename, String advertised) {
        String mime = advertised == null ? "" : advertised.trim().split(";", 2)[0].toLowerCase(Locale.ROOT);
        if (!mime.isEmpty() && !"application/octet-stream".equals(mime) && !"binary/octet-stream".equals(mime))
            return mime;
        String name = filename == null ? "" : filename.toLowerCase(Locale.ROOT);
        if (name.endsWith(".apk")) return "application/vnd.android.package-archive";
        if (name.endsWith(".pdf")) return "application/pdf";
        if (name.endsWith(".zip")) return "application/zip";
        if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".webp")) return "image/webp";
        if (name.endsWith(".mp4")) return "video/mp4";
        if (name.endsWith(".mkv")) return "video/x-matroska";
        if (name.endsWith(".mp3")) return "audio/mpeg";
        if (name.endsWith(".txt")) return "text/plain";
        return mime.isEmpty() ? "application/octet-stream" : mime;
    }
}
