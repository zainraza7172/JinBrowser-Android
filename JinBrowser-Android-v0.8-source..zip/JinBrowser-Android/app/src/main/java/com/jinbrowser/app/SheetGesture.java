package com.jinbrowser.app;

/** Deterministic gesture thresholds for the dismissible browser bottom sheet. */
public final class SheetGesture {
    private SheetGesture() {}
    public static boolean shouldClose(float distancePx, float density) {
        return distancePx >= 72f * Math.max(0.75f, density);
    }
    public static float dragProgress(float distancePx, float density) {
        return Math.max(0f, Math.min(1f, distancePx / (180f * Math.max(0.75f, density))));
    }
}
