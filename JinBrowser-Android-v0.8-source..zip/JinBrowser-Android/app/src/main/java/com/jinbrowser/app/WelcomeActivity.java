package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** First-launch welcome + real Android default browser consent, never a fake settings prompt. */
public final class WelcomeActivity extends Activity {
    private static final int DEFAULT_BROWSER_REQUEST=901;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle saved){
        Ui.init(this);setTheme(Ui.DARK?R.style.Theme_JinBrowser_Dark:R.style.Theme_JinBrowser);
        super.onCreate(saved);Ui.status(this);
        prefs=getSharedPreferences("browser",MODE_PRIVATE);
        if(prefs.getBoolean("onboarding_done",false)){openBrowser();return;}
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(1);shell.setGravity(Gravity.CENTER_HORIZONTAL);
        shell.setPadding(Ui.dp(this,27),Ui.dp(this,27),Ui.dp(this,27),Ui.dp(this,27));
        shell.setBackgroundColor(Ui.BG);setContentView(shell);Ui.fitSystemBars(this,shell,0,25,0,18);
        View spaceTop=new View(this);shell.addView(spaceTop,new LinearLayout.LayoutParams(1,0,1));
        ImageView panda=new ImageView(this);panda.setImageResource(R.mipmap.ic_launcher);
        shell.addView(panda,Ui.layout(this,120,120));
        TextView logo=Ui.text(this,"JIN BROWSER",31,Ui.WHITE,true);logo.setGravity(Gravity.CENTER);
        logo.setLetterSpacing(.14f);LinearLayout.LayoutParams logoLayout=Ui.layout(this,-1,56);
        logoLayout.topMargin=Ui.dp(this,19);shell.addView(logo,logoLayout);
        TextView title=Ui.text(this,"A beautiful way to explore.",20,Ui.CYAN,false);
        title.setGravity(Gravity.CENTER);title.setPadding(0,Ui.dp(this,8),0,0);shell.addView(title,Ui.layout(this,-1,50));
        TextView tagline=Ui.text(this,"Your space. Your choices.\nA cleaner home for the open web.",15,Ui.MUTED,false);
        tagline.setGravity(Gravity.CENTER);tagline.setLineSpacing(Ui.dp(this,5),1f);
        shell.addView(tagline,Ui.layout(this,-1,110));
        View gap=new View(this);shell.addView(gap,new LinearLayout.LayoutParams(1,0,1));
        TextView start=Ui.text(this,"Get Started   →",17,Color.WHITE,true);start.setGravity(Gravity.CENTER);
        start.setBackground(Ui.pill(this,0xff286d57,19));
        shell.addView(start,Ui.layout(this,-1,60));
        start.setOnClickListener(v->askDefault());
        TextView foot=Ui.text(this,"PRIVATE BY CHOICE · POWERED BY ANDROID WEBVIEW",10,Ui.MUTED,false);
        foot.setLetterSpacing(.07f);foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fl=Ui.layout(this,-1,55);fl.topMargin=Ui.dp(this,15);shell.addView(foot,fl);
    }
    private void askDefault(){
        new AlertDialog.Builder(this).setTitle("Make Jin your default browser?")
            .setMessage("Open website links in Jin Browser. You can change this any time in Android Settings.")
            .setNegativeButton("Not now",(d,w)->finishWelcome())
            .setPositiveButton("Choose default",(d,w)->requestDefault()).show();
    }
    private void requestDefault(){try{
        RoleManager roles=getSystemService(RoleManager.class);
        if(roles!=null&&roles.isRoleAvailable(RoleManager.ROLE_BROWSER)){
            if(roles.isRoleHeld(RoleManager.ROLE_BROWSER)){finishWelcome();return;}
            startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_BROWSER),DEFAULT_BROWSER_REQUEST);
        }else finishWelcome();
    }catch(Exception e){finishWelcome();}}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==DEFAULT_BROWSER_REQUEST)finishWelcome(); // Cancel is always allowed.
    }
    private void finishWelcome(){prefs.edit().putBoolean("onboarding_done",true).apply();openBrowser();}
    private void openBrowser(){startActivity(new Intent(this,MainActivity.class));finish();}
}
