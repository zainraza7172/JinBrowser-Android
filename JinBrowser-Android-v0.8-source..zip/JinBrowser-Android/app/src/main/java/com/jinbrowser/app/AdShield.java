package com.jinbrowser.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

/** Native WebView network and cosmetic filtering, with a small explicit ABP subset. */
final class AdShield {
    private final SharedPreferences prefs;
    private final AtomicLong blocked = new AtomicLong();
    private volatile Set<String> listHosts;
    AdShield(Context c) {
        prefs=c.getSharedPreferences("browser",Context.MODE_PRIVATE);
        blocked.set(prefs.getLong("blocked_requests",0));
        listHosts=FilterLists.load(c);
    }
    void reload(Context c){listHosts=FilterLists.load(c);}
    boolean enabled(){return prefs.getBoolean("ad_block",true);}
    boolean allowedFor(String topHost){
        return enabled()&&(topHost==null||!prefs.getBoolean("ad_exception:"+topHost.toLowerCase(Locale.ROOT),false));
    }
    long count(){return blocked.get();}
    int ruleCount(){return listHosts.size();}
    void persist(){prefs.edit().putLong("blocked_requests",blocked.get()).apply();}
    private boolean adHost(String host){
        if(host==null)return false;
        // Never block actual video CDN hosts: ads and content can share a delivery network.
        String h=host.toLowerCase(Locale.ROOT);
        if(h.equals("googlevideo.com")||h.endsWith(".googlevideo.com")||
           h.equals("ytimg.com")||h.endsWith(".ytimg.com"))return false;
        return AdBlockRules.isAdHost(host)||FilterLists.matches(listHosts,host);
    }
    boolean blocksNavigation(Uri target,String topHost){
        String host=target.getHost();
        if(!allowedFor(topHost)||host==null||AdBlockRules.sameSite(host,topHost))return false;
        boolean block=adHost(host)||AdBlockRules.adRedirectPath(target.toString());
        if(block)blocked.incrementAndGet();return block;
    }
    WebResourceResponse intercept(WebResourceRequest request,String topHost){
        if(request.isForMainFrame()||!allowedFor(topHost))return null;
        Uri uri=request.getUrl();String scheme=uri.getScheme();
        if(!("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)))return null;
        String host=uri.getHost();
        if(host==null||AdBlockRules.sameSite(host,topHost))return null;
        if(!adHost(host)&&!AdBlockRules.isThirdPartyAdPath(uri.toString()))return null;
        blocked.incrementAndGet();return emptyResponse();
    }
    static WebResourceResponse emptyResponse(){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
    static String cosmeticScript(){
        return "(function(){if(document.getElementById('jin-ad-css'))return;"+
               "var style=document.createElement('style');style.id='jin-ad-css';"+
               "style.textContent='ins.adsbygoogle,[id^=google_ads_],.adsbygoogle,.ad-banner,.ad-slot,div[data-ad-slot],"+
               "[aria-label=Advertisement],[data-testid=ad-banner],iframe[src*=doubleclick],.ad-container{display:none!important}';"+
               "(document.head||document.documentElement).appendChild(style);"+
               "var last=0;new MutationObserver(function(){if(Date.now()-last<1000)return;last=Date.now();"+
               "if(!document.getElementById('jin-ad-css'))(document.head||document.documentElement).appendChild(style)})"+
               ".observe(document.documentElement,{childList:true,subtree:true})})();";
    }
    /** Experimental YouTube visual/skip controls. Ad delivery is shared with video CDN, so no 100% claim. */
    static String youtubeScript(){
        return "(function(){if(window.__jinYouTubeShield)return;window.__jinYouTubeShield=1;"+
               "var css=document.createElement('style');css.textContent='.ytp-ad-overlay-container,.ytp-ad-player-overlay,"+
               ".ytd-display-ad-renderer,ytd-promoted-video-renderer,ytd-ad-slot-renderer,"+
               "ytd-promoted-sparkles-web-renderer{display:none!important}';"+
               "(document.head||document.documentElement).appendChild(css);"+
               "function skip(){var btn=document.querySelector('.ytp-ad-skip-button-modern,.ytp-ad-skip-button,.ytp-skip-ad-button');"+
               "if(btn&&btn.offsetParent!==null)btn.click();"+
               "var close=document.querySelector('.ytp-ad-overlay-close-button');if(close)close.click();"+
               "if(document.querySelector('.ad-showing')){var v=document.querySelector('video');"+
               "if(v&&isFinite(v.duration)&&v.duration>0&&v.duration<600){try{v.currentTime=v.duration-0.15}catch(e){}}}}"+
               "setInterval(skip,1300);new MutationObserver(skip).observe(document.documentElement,{childList:true,subtree:true});skip();})();";
    }
}
