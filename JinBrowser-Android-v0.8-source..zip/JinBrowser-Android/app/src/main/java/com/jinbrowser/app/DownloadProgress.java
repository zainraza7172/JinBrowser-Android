package com.jinbrowser.app;

/** Dependency-free download rate and ETA calculations for both UI and tests. */
final class DownloadProgress {
    private DownloadProgress() { }

    static long bytesPerSecond(long bytesDelta, long elapsedMillis) {
        if (bytesDelta < 0 || elapsedMillis <= 0) return 0;
        return bytesDelta > Long.MAX_VALUE / 1000 ? Long.MAX_VALUE : bytesDelta * 1000 / elapsedMillis;
    }
    static long smooth(long previous, long current) {
        if (current < 0) current = 0;
        if (previous <= 0) return current;
        return previous / 3 * 2 + current / 3 + (previous % 3 * 2 + current % 3) / 3;
    }
    static long etaSeconds(long total, long completed, long speedBps) {
        if (total <= 0 || completed < 0 || speedBps <= 0) return -1;
        long remaining = Math.max(0, total - Math.min(total, completed));
        if (remaining == 0) return 0;
        return remaining / speedBps + (remaining % speedBps == 0 ? 0 : 1);
    }
}
