package com.jinbrowser.app;

import android.content.Context;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;
import java.io.File;

/** Runs in a separate Android process so its WebView profile cannot use the normal cookie jar. */
public final class PrivateActivity extends MainActivity {
    private static boolean processPrepared = false;
    @Override protected boolean privateMode() { return true; }
    @Override protected synchronized void prepareProcess() {
        if (!processPrepared) {
            // Best effort removal of private profile data left by a crashed/killed process.
            // This MUST precede the first WebView / CookieManager use in this process.
            File oldProfile = new File(getDataDir(), "app_webview_jin_private");
            deleteTree(oldProfile);
            WebView.setDataDirectorySuffix("jin_private");
            processPrepared = true;
        }
        CookieManager.getInstance().removeAllCookies(null);
        WebStorage.getInstance().deleteAllData();
    }
    private static void deleteTree(File f) {
        if (!f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        // Failure can happen if a stale renderer holds a file; start-up cleanup is best effort.
        if (!f.delete()) android.util.Log.w("JinPrivate", "Could not delete stale profile item");
    }
}
