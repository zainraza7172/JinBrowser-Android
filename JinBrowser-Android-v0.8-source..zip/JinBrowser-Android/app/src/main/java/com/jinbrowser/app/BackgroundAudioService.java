package com.jinbrowser.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.IBinder;

/**
 * User-initiated foreground media session. WebView media remains in the Activity;
 * this service keeps a foreground session and routes notification controls.
 * Websites/Android may still suspend or disallow background playback.
 */
public final class BackgroundAudioService extends Service {
    static final String START="com.jinbrowser.app.AUDIO_START";
    static final String PLAY="com.jinbrowser.app.AUDIO_PLAY";
    static final String PAUSE="com.jinbrowser.app.AUDIO_PAUSE";
    static final String STOP="com.jinbrowser.app.AUDIO_STOP";
    static final String CONTROL="com.jinbrowser.app.AUDIO_CONTROL";
    static final String STATUS_PLAYING="com.jinbrowser.app.AUDIO_STATUS_PLAYING";
    static final String STATUS_PAUSED="com.jinbrowser.app.AUDIO_STATUS_PAUSED";
    private static final String CHANNEL="jin_media_v1";
    private static final int ID=889;
    private MediaSession session;
    private boolean playing=true;

    @Override public void onCreate(){super.onCreate();
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Background playback",NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Control media playing in Jin Browser");
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        session=new MediaSession(this,"Jin Browser audio");
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,"Jin Browser")
                .putString(MediaMetadata.METADATA_KEY_ARTIST,"Background audio").build());
        session.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){command(PLAY);}
            @Override public void onPause(){command(PAUSE);}
            @Override public void onStop(){command(STOP);}
        });
        session.setActive(true);
        state();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        // Without the Activity's WebView there is no actual media player to resume.
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        String action=intent.getAction();
        if(STOP.equals(action)){sendToBrowser(STOP);
            getSharedPreferences("browser",MODE_PRIVATE).edit().putBoolean("background_audio",false).apply();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        if(PAUSE.equals(action)){playing=false;sendToBrowser(PAUSE);}
        else if(PLAY.equals(action)){playing=true;sendToBrowser(PLAY);}
        else if(STATUS_PAUSED.equals(action)) playing=false;
        else if(STATUS_PLAYING.equals(action)) playing=true;
        else if(START.equals(action))playing=true;
        state();startForeground(ID,notification());
        return START_NOT_STICKY;
    }
    private void command(String action){startService(new Intent(this,BackgroundAudioService.class).setAction(action));}
    private void sendToBrowser(String command){sendBroadcast(new Intent(CONTROL).setPackage(getPackageName()).putExtra("command",command));}
    private PendingIntent serviceAction(String action,int request){
        Intent i=new Intent(this,BackgroundAudioService.class).setAction(action);
        return PendingIntent.getService(this,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void state(){if(session==null)return;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_STOP)
                .setState(playing?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN,playing?1f:0f).build());
    }
    private Notification notification(){
        PendingIntent open=PendingIntent.getActivity(this,885,new Intent(this,MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Jin Browser · Background audio")
            .setContentText(playing?"Media playing · Return to Jin to manage playback":"Paused · Tap Play to resume")
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true);
        builder.addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,
                        playing?"Pause":"Play",serviceAction(playing?PAUSE:PLAY,1)).build());
        builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Stop",serviceAction(STOP,2)).build());
        builder.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(0,1));
        return builder.build();
    }
    @Override public void onDestroy(){if(session!=null){session.setActive(false);session.release();session=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
