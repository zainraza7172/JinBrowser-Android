package com.jinbrowser.app;

import android.content.Context;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Conservative ABP host-only subset: ignores unsupported filter syntax rather than
 * pretending this WebView browser has full extension / WebRequest support.
 * Original lists are retrieved only on explicit user request.
 */
final class FilterLists {
    static final String EASYLIST="https://easylist.to/easylist/easylist.txt";
    static final String EASYPRIVACY="https://easylist.to/easylist/easyprivacy.txt";
    private static final String STORAGE="jin_ad_hosts_v1.txt";
    private static final int MAX_BYTES=9_000_000;
    private FilterLists(){}
    static Set<String> load(Context context) {
        File f=new File(context.getFilesDir(),STORAGE);
        if(!f.isFile())return Collections.emptySet();
        HashSet<String> hosts=new HashSet<>();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"))){
            String line;while((line=r.readLine())!=null){if(isValidHost(line))hosts.add(line);}
        }catch(IOException ignored){}
        return hosts;
    }
    static int update(Context context) throws IOException {
        HashSet<String> hosts=new HashSet<>();
        readUrl(EASYLIST,hosts);readUrl(EASYPRIVACY,hosts);
        if(hosts.size()<40)throw new IOException("Not enough verified domain rules; previous lists preserved");
        File file=new File(context.getFilesDir(),STORAGE);
        File temp=new File(context.getFilesDir(),STORAGE+".new");
        try(BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(temp),"UTF-8"))){
            for(String h:hosts){w.write(h);w.newLine();}
        }
        try {java.nio.file.Files.move(temp.toPath(),file.toPath(),
                java.nio.file.StandardCopyOption.ATOMIC_MOVE,java.nio.file.StandardCopyOption.REPLACE_EXISTING);}
        catch(java.nio.file.AtomicMoveNotSupportedException ex) {
            java.nio.file.Files.move(temp.toPath(),file.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        context.getSharedPreferences("browser",Context.MODE_PRIVATE).edit()
                .putLong("filter_updated",System.currentTimeMillis()).putInt("filter_count",hosts.size()).apply();
        return hosts.size();
    }
    private static void readUrl(String address,Set<String> target) throws IOException {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setConnectTimeout(10000);c.setReadTimeout(18000);
        c.setRequestProperty("User-Agent","JinBrowser/0.7 (manual filter update)");
        c.setRequestProperty("Accept-Encoding","identity");
        try{
            if(c.getResponseCode()!=200)throw new IOException("Filter server HTTP "+c.getResponseCode());
            int read=0;
            try(InputStream stream=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(stream,"UTF-8"))){
                String line;while((line=r.readLine())!=null){
                    read+=line.length()+1;
                    if(read>MAX_BYTES)throw new IOException("Filter list exceeded size limit");
                    String host=parseDomainRule(line);if(host!=null)target.add(host);
                    if(target.size()>80000)throw new IOException("Too many rules");
                }
            }
        }finally{c.disconnect();}
    }
    static String parseDomainRule(String raw) {
        if(raw==null||!raw.startsWith("||"))return null;
        int end=raw.indexOf('^',2);if(end<5)return null;
        String host=raw.substring(2,end).toLowerCase(Locale.ROOT);
        if(!isValidHost(host))return null;
        String suffix=raw.substring(end+1);
        if(!suffix.isEmpty()&&!suffix.equals("$third-party")&&!suffix.equals("$third-party,script")&&
                !suffix.equals("$script,third-party")&&!suffix.equals("$third-party,image")&&
                !suffix.equals("$image,third-party"))return null;
        return host;
    }
    static boolean isValidHost(String value){return value!=null&&value.length()<=255&&value.length()>=4&&
            value.indexOf('.')>0&&value.indexOf(' ')<0&&value.matches("[a-z0-9][a-z0-9.-]+[a-z0-9]")&&
            !value.contains("..")&&!value.startsWith("-");}
    static boolean matches(Set<String> hosts,String raw){
        if(raw==null||hosts.isEmpty())return false;
        String h=raw.toLowerCase(Locale.ROOT);
        for(int i=0;i<32;i++){
            if(hosts.contains(h))return true;
            int dot=h.indexOf('.');if(dot<0)return false;h=h.substring(dot+1);
        }
        return false;
    }
}
