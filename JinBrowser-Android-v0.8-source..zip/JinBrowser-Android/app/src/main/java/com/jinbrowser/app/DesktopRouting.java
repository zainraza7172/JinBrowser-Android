package com.jinbrowser.app;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Rewrite a site's well-known mobile host only when desktop mode is active.
 * Never touch path/query/fragment or rewrite arbitrary third-party hosts. */
public final class DesktopRouting {
    private static final Pattern URL = Pattern.compile("^(https?)://([^/?#:]+)(:[0-9]+)?(.*)$", Pattern.CASE_INSENSITIVE);
    private DesktopRouting() {}
    public static String normalize(String raw, boolean desktop) {
        if (!desktop || raw == null) return raw;
        Matcher m = URL.matcher(raw);
        if (!m.matches()) return raw;
        String host = m.group(2).toLowerCase(Locale.ROOT);
        String canonical;
        switch (host) {
            case "m.youtube.com":
            case "mobile.youtube.com": canonical = "www.youtube.com"; break;
            case "m.google.com": canonical = "www.google.com"; break;
            case "m.facebook.com": canonical = "www.facebook.com"; break;
            case "m.reddit.com": canonical = "www.reddit.com"; break;
            default: return raw;
        }
        return "https://" + canonical + (m.group(3) == null ? "" : m.group(3)) + m.group(4);
    }
}
