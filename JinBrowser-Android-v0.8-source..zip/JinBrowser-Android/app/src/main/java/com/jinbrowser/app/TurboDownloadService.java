package com.jinbrowser.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Foreground HTTP downloader with parallel RFC 7233 byte ranges, per-part checkpoints,
 * link replacement, bounded retries and sampled file identity verification.
 * NOTE: It cannot override Android bandwidth management or fix a server without Range support.
 */
public final class TurboDownloadService extends Service {
    static final String ACTION_START = "jin.action.START";
    static final String ACTION_RESUME = "jin.action.RESUME";
    static final String ACTION_PAUSE = "jin.action.PAUSE";
    static final String ACTION_UPDATE = "jin.action.UPDATE";
    static final String ACTION_RESET = "jin.action.RESET";
    private static final String EXTRA_ID = "job_id", EXTRA_JOB = "job_json", EXTRA_URL = "new_url", EXTRA_COOKIE = "cookie";
    private static final int NOTIFICATION_ID = 811;
    private static final String CHANNEL = "jin_downloads_v1";
    private static final Pattern CONTENT_RANGE = Pattern.compile("bytes\\s+(\\d+)-(\\d+)/(\\d+|\\*)", Pattern.CASE_INSENSITIVE);
    private final ExecutorService taskPool = Executors.newFixedThreadPool(2);
    private final Map<String, AtomicBoolean> active = new ConcurrentHashMap<>();
    private final Map<String, String> ephemeralCookies = new ConcurrentHashMap<>();
    private final Set<String> resumeAfterStop = ConcurrentHashMap.newKeySet();
    private final Map<String, long[]> rateSamples = new ConcurrentHashMap<>();
    private volatile boolean serviceForeground = false;
    private PowerManager.WakeLock wakeLock;
    private volatile long nextWakeRenewal;

    static void enqueue(Context context, DownloadJob job, String cookie) {
        Intent i = new Intent(context, TurboDownloadService.class).setAction(ACTION_START);
        try { i.putExtra(EXTRA_JOB, job.toJson().toString()); } catch (Exception ignored) { return; }
        if (cookie != null) i.putExtra(EXTRA_COOKIE, cookie);
        context.startForegroundService(i);
    }
    static void send(Context context, String action, String id, String newUrl, String cookie) {
        Intent i = new Intent(context, TurboDownloadService.class).setAction(action).putExtra(EXTRA_ID, id);
        if (newUrl != null) i.putExtra(EXTRA_URL, newUrl);
        if (cookie != null) i.putExtra(EXTRA_COOKIE, cookie);
        context.startForegroundService(i);
    }
    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Turbo downloads", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"JinBrowser:active-downloads");
            wakeLock.setReferenceCounted(false);}
        // Preserve interrupted jobs for automatic restart if Android recreates the foreground service.
        for (DownloadJob j : DownloadStore.all(this)) {
            if ("running".equals(j.state)) {j.state="paused";
                j.error="Android interrupted download · reconnecting";DownloadStore.put(this,j);}
        }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        showNotification("Jin Browser", "Preparing download…", 0, true);
        if (intent == null || intent.getAction() == null) {
            // START_STICKY restart: resume only jobs Android previously interrupted.
            // Deliberately paused jobs are never restarted without user action.
            for(DownloadJob j:DownloadStore.all(this))
                if("paused".equals(j.state)&&"Android interrupted download · reconnecting".equals(j.error)
                        && !j.privateDownload)startJob(j.id);
            stopIfIdle();return START_STICKY;
        }
        String action = intent.getAction();
        String id = intent.getStringExtra(EXTRA_ID);
        if (ACTION_START.equals(action)) {
            try {
                DownloadJob j = DownloadJob.fromJson(new org.json.JSONObject(intent.getStringExtra(EXTRA_JOB)));
                if (j.id == null || j.id.isEmpty() || !isHttp(j.url)) throw new IOException("Invalid URL");
                DownloadStore.put(this, j);
                String cookie = intent.getStringExtra(EXTRA_COOKIE);
                if (cookie != null && !cookie.isEmpty()) ephemeralCookies.put(j.id, cookie);
                startJob(j.id);
            } catch (Exception e) { showNotification("Download rejected", "Invalid download request", 0, false); stopIfIdle(); }
        } else if (id != null) {
            switch (action) {
                case ACTION_RESUME: {
                    DownloadJob j = DownloadStore.get(this, id);
                    if (j != null && !"done".equals(j.state)) {
                        if (!j.privateDownload && !ephemeralCookies.containsKey(id)) {
                            try {
                                String savedCookie = android.webkit.CookieManager.getInstance().getCookie(j.url);
                                if (savedCookie != null && !savedCookie.isEmpty()) ephemeralCookies.put(id, savedCookie);
                            } catch (Exception ignored) {}
                        }
                        startJob(id);
                    }
                    else stopIfIdle();
                    break;
                }
                case ACTION_PAUSE: {
                    AtomicBoolean stop = active.get(id);
                    if (stop != null) stop.set(true);
                    resumeAfterStop.remove(id);
                    DownloadJob j = DownloadStore.get(this, id);
                    if (j != null && !"done".equals(j.state)) {
                        j.state = "paused"; j.error = ""; j.bytes = partBytes(j);
                        DownloadStore.put(this, j);
                    }
                    stopIfIdle();
                    break;
                }
                case ACTION_UPDATE: {
                    DownloadJob j = DownloadStore.get(this, id);
                    String url = intent.getStringExtra(EXTRA_URL);
                    if (j != null && isHttp(url) && !"done".equals(j.state)) {
                        AtomicBoolean oldWorker = active.get(id);
                        if (oldWorker != null) {
                            oldWorker.set(true);
                            resumeAfterStop.add(id); // Restart safely after old part writers exit.
                        }
                        j.url = url.trim(); j.state = "paused"; j.error = "Checking replacement link before resuming…";
                        DownloadStore.put(this, j);
                        ephemeralCookies.remove(id); // Never send old site's cookies to a new URL.
                        if (oldWorker == null) startJob(id); // Auto-resume one-tap when idle.
                    }
                    stopIfIdle();
                    break;
                }
                case ACTION_RESET: {
                    if (!active.containsKey(id)) {
                        DownloadJob j = DownloadStore.get(this, id);
                        if (j != null && !"done".equals(j.state)) {
                            File dir = DownloadStore.partsFolder(this, id);
                            File[] files = dir.listFiles();
                            if (files != null) for (File f : files) f.delete();
                            j.bytes=0; j.total=-1; j.etag=""; j.lastModified="";
                            j.state="paused"; j.error="Reset. Tap Resume to start from zero.";
                            DownloadStore.put(this, j);
                        }
                    }
                    stopIfIdle();
                    break;
                }
                default: stopIfIdle();
            }
        } else stopIfIdle();
        return START_STICKY;
    }
    private synchronized void startJob(String id) {
        if (active.containsKey(id)) {
            if (active.get(id).get()) resumeAfterStop.add(id);
            return;
        }
        DownloadJob j = DownloadStore.get(this, id);
        if (j == null) { stopIfIdle(); return; }
        AtomicBoolean stop = new AtomicBoolean(false);
        active.put(id, stop);
        keepAwake();
        j.state = "running"; j.error = ""; j.speedBps = 0;
        rateSamples.remove(id);
        DownloadStore.put(this, j);
        taskPool.submit(() -> {
            try { perform(j, stop); }
            catch (NeedNewLink e) { setResult(j, "link-needed", e.getMessage()); }
            catch (Cancelled ignored) { setResult(j, "paused", ""); }
            catch (Exception e) { setResult(j, "error", e.getMessage() == null ? "Download failed" : e.getMessage()); }
            finally {
                active.remove(id, stop);
                ephemeralCookies.remove(id);
                if (resumeAfterStop.remove(id)) startJob(id);
                stopIfIdle();
            }
        });
    }
    private void perform(DownloadJob job, AtomicBoolean stop) throws Exception {
        Probe probe = inspect(job.url, job.userAgent, ephemeralCookies.get(job.id));
        if (stop.get()) throw new Cancelled();
        long existing = partBytes(job);
        if (existing > 0) {
            if (!probe.ranges || probe.total < 1) throw new NeedNewLink("Server does not support safe resume. Update link or Reset.");
            if (job.total > 0 && job.total != probe.total) throw new NeedNewLink("New URL points to a different-sized file. Reset or choose the original file.");
            verifyExistingParts(job, probe.total, ephemeralCookies.get(job.id), stop);
        }
        job.total = probe.total;
        job.rangeSupported = probe.ranges;
        // If a refreshed signed URL has a different ETag but its partial samples match,
        // use the freshly observed validator for subsequent byte-range requests.
        job.etag = probe.etag;
        job.lastModified = probe.lastModified;
        if (existing == 0 && (!probe.ranges || probe.total < 262144L)) job.parts = 1;
        if (job.total < 1) job.parts = 1;
        // A very fast transfer may fail before the periodic progress timer fires.
        // Save the verified file length and partition map immediately, otherwise
        // its on-disk partial segments could not be safely resumed after a crash.
        job.updated = 0;
        checkpoint(job, stop);

        if (job.parts == 1 && (!probe.ranges || probe.total < 1)) {
            if (existing > 0) throw new NeedNewLink("This server cannot resume partial files. Reset to restart.");
            fetchStreaming(job, stop);
        } else if (job.parts == 1) {
            fetchPart(job, 0, stop);
        } else {
            ExecutorService partsPool = Executors.newFixedThreadPool(job.parts);
            ArrayList<Future<?>> futures = new ArrayList<>();
            try {
                for (int part=0;part<job.parts;part++) {
                    final int index=part;
                    futures.add(partsPool.submit(() -> {
                        try { fetchPart(job, index, stop); }
                        catch (Exception e) { throw new RuntimeException(e); }
                    }));
                }
                Exception failure = null;
                for (Future<?> f : futures) {
                    try { f.get(); }
                    catch (ExecutionException e) {
                        Throwable cause = e.getCause();
                        if (cause instanceof RuntimeException && cause.getCause() != null) cause = cause.getCause();
                        // Prefer a real HTTP/link failure over cancellations of sibling segments.
                        if (!(cause instanceof Cancelled) || failure == null) {
                            if (failure == null || failure instanceof Cancelled || cause instanceof NeedNewLink)
                                failure = cause instanceof Exception ? (Exception) cause : new IOException(cause);
                        }
                        stop.set(true);
                    }
                }
                if (failure != null) throw failure;
            } finally { partsPool.shutdownNow(); }
        }
        if (stop.get()) throw new Cancelled();
        long received = partBytes(job);
        if (job.total > 0 && received != job.total) throw new IOException("Incomplete file: received " + received + " of " + job.total + " bytes");
        Uri saved = saveCompleted(job);
        job.outputUri = saved.toString(); job.bytes = received; job.speedBps=0; job.state = "done"; job.error="";
        DownloadStore.put(this, job);
        // Delete temporary parts only after the completed file is safely written.
        File[] pieces = DownloadStore.partsFolder(this, job.id).listFiles();
        if (pieces != null) for (File f : pieces) f.delete();
        showNotification("Download complete", job.name, 100, false);
    }
    private static final class Probe {
        final boolean ranges; final long total; final String etag, lastModified;
        Probe(boolean ranges, long total, String etag, String lastModified) {
            this.ranges=ranges; this.total=total; this.etag=etag; this.lastModified=lastModified;
        }
    }
    private Probe inspect(String url, String ua, String cookie) throws Exception {
        HttpURLConnection c = connect(url, ua, cookie, 0L, 0L);
        try {
            int code = c.getResponseCode();
            if (code == 401 || code == 403 || code == 404 || code == 410) throw new NeedNewLink("Link expired or unavailable (HTTP " + code + "). Paste a new link.");
            String encoding = c.getContentEncoding();
            boolean identity = encoding == null || encoding.equalsIgnoreCase("identity");
            String etag = nz(c.getHeaderField("ETag")), lm = nz(c.getHeaderField("Last-Modified"));
            if (code == 206 && identity) {
                Matcher m = CONTENT_RANGE.matcher(nz(c.getHeaderField("Content-Range")));
                if (m.matches() && !"*".equals(m.group(3)) && m.group(1).equals("0"))
                    return new Probe(true, Long.parseLong(m.group(3)), etag, lm);
            }
            if (code == 200) return new Probe(false, identity ? c.getContentLengthLong() : -1, etag, lm);
            throw new IOException("Server did not allow downloading: HTTP " + code);
        } finally { c.disconnect(); }
    }
    private void fetchPart(DownloadJob j, int index, AtomicBoolean stop) throws Exception {
        long start = RangeMath.start(j.total, j.parts, index);
        long end = RangeMath.end(j.total, j.parts, index);
        if (end < start) return;
        File part = DownloadStore.partFile(this, j.id, index);
        if (part.length() > end - start + 1) throw new NeedNewLink("Part file is too large; Reset this download.");
        for (int attempt = 0; attempt < 5; attempt++) {
            if (stop.get()) throw new Cancelled();
            long next = start + part.length();
            if (next > end) return;
            HttpURLConnection c = null;
            try {
                c = connect(j.url, j.userAgent, ephemeralCookies.get(j.id), next, end,
                        !j.etag.isEmpty() && !j.etag.startsWith("W/") ? j.etag : null);
                int status = c.getResponseCode();
                if (status == 401 || status == 403 || status == 404 || status == 410)
                    throw new NeedNewLink("Download link expired (HTTP " + status + "). Update link to resume.");
                if (status != 206 || !validRange(c.getHeaderField("Content-Range"), next, j.total))
                    throw new NeedNewLink("Server did not honor requested byte ranges. Update link or Reset.");
                if (c.getContentEncoding() != null && !c.getContentEncoding().equalsIgnoreCase("identity"))
                    throw new IOException("Compressed range response cannot be safely merged");
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part, true)) {
                    byte[] buffer = new byte[64 * 1024]; long remaining = end - next + 1; int len;
                    while (remaining > 0 && (len = in.read(buffer, 0, (int)Math.min(buffer.length, remaining))) != -1) {
                        if (stop.get()) throw new Cancelled();
                        out.write(buffer, 0, len); remaining -= len;
                        checkpoint(j, stop);
                    }
                    if (remaining != 0) throw new IOException("Connection ended before segment finished");
                }
                return;
            } catch (NeedNewLink | Cancelled e) { throw e; }
            catch (IOException e) {
                if (attempt == 4) throw e;
                Thread.sleep(600L * (attempt + 1) * (attempt + 1));
            } finally { if (c != null) c.disconnect(); }
        }
    }
    private void fetchStreaming(DownloadJob j, AtomicBoolean stop) throws Exception {
        File part = DownloadStore.partFile(this, j.id, 0);
        if (part.length() != 0) throw new NeedNewLink("Cannot resume without HTTP range support; Reset to restart.");
        for (int attempt=0;attempt<5;attempt++) {
            if (stop.get()) throw new Cancelled();
            // Serial servers cannot resume: retry starts at byte zero only.
            if (part.exists() && !part.delete()) throw new IOException("Could not clear failed segment");
            HttpURLConnection c = null;
            try {
                c = connect(j.url, j.userAgent, ephemeralCookies.get(j.id), null, null);
                int status = c.getResponseCode();
                if (status == 401 || status == 403 || status == 404 || status == 410) throw new NeedNewLink("Expired link (HTTP " + status + ")");
                if (status != 200) throw new IOException("HTTP " + status);
                long contentLength = c.getContentLengthLong();
                if (contentLength > 0) j.total = contentLength;
                try (InputStream in=c.getInputStream(); FileOutputStream out=new FileOutputStream(part)) {
                    byte[] buffer=new byte[64*1024]; int n;
                    while ((n=in.read(buffer)) != -1) {
                        if (stop.get()) throw new Cancelled();
                        out.write(buffer,0,n); checkpoint(j, stop);
                    }
                }
                if (j.total > 0 && part.length() != j.total) throw new IOException("Incomplete response");
                return;
            } catch (NeedNewLink | Cancelled e) { throw e; }
            catch (IOException e) { if (attempt==4) throw e; Thread.sleep(600L*(attempt+1)*(attempt+1)); }
            finally { if (c != null) c.disconnect(); }
        }
    }
    /** Sample the beginning and end of each existing part against the replacement URL. */
    private void verifyExistingParts(DownloadJob j, long total, String cookie, AtomicBoolean stop) throws Exception {
        if (j.total <= 0) throw new NeedNewLink("Unknown original file length: cannot safely verify a partial download.");
        for (int index=0;index<j.parts;index++) {
            File f = DownloadStore.partFile(this, j.id, index);
            if (!f.isFile() || f.length()==0) continue;
            long offset=RangeMath.start(total,j.parts,index);
            long size=f.length();
            long max=RangeMath.end(total,j.parts,index)-offset+1;
            if (size>max) throw new NeedNewLink("Partial file does not match new link.");
            compareRange(j, f, 0, Math.min(16384L,size), offset, cookie, stop);
            if (size>16384) compareRange(j, f, size-Math.min(16384L,size), Math.min(16384L,size), offset, cookie, stop);
        }
    }
    private void compareRange(DownloadJob j, File part, long position, long count, long fileOffset, String cookie, AtomicBoolean stop) throws Exception {
        if (stop.get()) throw new Cancelled();
        long from=fileOffset+position, to=from+count-1;
        HttpURLConnection c=connect(j.url, j.userAgent, cookie, from, to);
        try {
            if (c.getResponseCode()!=206 || !validRange(c.getHeaderField("Content-Range"),from,j.total))
                throw new NeedNewLink("Replacement URL does not allow validated resuming.");
            try (InputStream remote=c.getInputStream(); FileInputStream local=new FileInputStream(part)) {
                long skipped=0;
                while (skipped<position) {
                    long step=local.skip(position-skipped);
                    if (step<=0) throw new IOException("Cannot inspect partial download");
                    skipped+=step;
                }
                byte[] localBytes=new byte[8192], remoteBytes=new byte[8192];
                long remaining=count;
                while (remaining>0) {
                    int read=(int)Math.min(localBytes.length,remaining);
                    int readLocal=0;
                    while (readLocal<read) {
                        int n=local.read(localBytes,readLocal,read-readLocal);
                        if (n<0) throw new IOException("Partial file truncated");
                        readLocal+=n;
                    }
                    int at=0,n;
                    while (at<read && (n=remote.read(remoteBytes,at,read-at))!=-1) at+=n;
                    if (at!=read) throw new NeedNewLink("New URL returned an incomplete verification sample");
                    for (int i=0;i<read;i++) if (localBytes[i]!=remoteBytes[i]) throw new NeedNewLink("Different file at new URL. Refusing to corrupt your download.");
                    remaining-=read;
                }
            }
        } finally { c.disconnect(); }
    }
    private static boolean validRange(String range, long expectedStart, long expectedTotal) {
        Matcher m=CONTENT_RANGE.matcher(nz(range));
        if (!m.matches()) return false;
        return Long.parseLong(m.group(1))==expectedStart &&
                !"*".equals(m.group(3)) && Long.parseLong(m.group(3))==expectedTotal;
    }
    private HttpURLConnection connect(String url, String userAgent, String cookie, Long first, Long last) throws IOException {
        return connect(url, userAgent, cookie, first, last, null);
    }
    private HttpURLConnection connect(String url, String userAgent, String cookie, Long first, Long last, String ifRange) throws IOException {
        if (!isHttp(url)) throw new IOException("Only HTTP and HTTPS downloads are allowed");
        URL origin = new URL(url), current = origin;
        for (int hop = 0; hop <= 5; hop++) {
            HttpURLConnection c=(HttpURLConnection)current.openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(15000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent",userAgent);
            c.setRequestProperty("Accept-Encoding","identity");
            // Credentials are sent only to the exact original origin, not a redirected CDN.
            if (cookie!=null && !cookie.isEmpty() && origin.getProtocol().equalsIgnoreCase(current.getProtocol()) &&
                origin.getHost().equalsIgnoreCase(current.getHost()) && origin.getPort()==current.getPort())
                c.setRequestProperty("Cookie",cookie);
            if (first!=null && last!=null) c.setRequestProperty("Range","bytes="+first+"-"+last);
            if (ifRange!=null) c.setRequestProperty("If-Range", ifRange);
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String location = c.getHeaderField("Location");
                c.disconnect();
                if (location == null) throw new IOException("Redirect without location");
                URL next = new URL(current, location);
                if (!isHttp(next.toString())) throw new IOException("Refusing non-HTTP redirect");
                if (current.getProtocol().equalsIgnoreCase("https") && next.getProtocol().equalsIgnoreCase("http"))
                    throw new IOException("Refusing insecure HTTPS downgrade");
                current = next;
                continue;
            }
            return c;
        }
        throw new IOException("Too many download redirects");
    }
    private static boolean isHttp(String value) {
        if (value==null) return false;
        try { String p=new URL(value).getProtocol();return p.equalsIgnoreCase("https")||p.equalsIgnoreCase("http"); }
        catch (Exception ignored) { return false; }
    }
    private static String nz(String s) { return s==null?"":s; }
    private long partBytes(DownloadJob j) {
        long n=0;for(int i=0;i<j.parts;i++) n+=DownloadStore.partFile(this,j.id,i).length();return n;
    }
    private synchronized void checkpoint(DownloadJob job, AtomicBoolean stop) {
        if (stop.get()) return;
        keepAwake();
        long now=System.currentTimeMillis();
        if (now-job.updated<850) return;
        DownloadJob current=DownloadStore.get(this,job.id);
        if (current!=null && "running".equals(current.state)) {
            job.bytes=partBytes(job);
            long[] previous = rateSamples.put(job.id, new long[] {job.bytes, now});
            if (previous != null && now > previous[1] && job.bytes >= previous[0]) {
                long currentBps = DownloadProgress.bytesPerSecond(job.bytes - previous[0], now - previous[1]);
                job.speedBps = DownloadProgress.smooth(job.speedBps, currentBps);
            }
            job.updated=now;
            DownloadStore.put(this,job);
            int percentage=job.total>0 ? (int)Math.min(100,100*job.bytes/job.total) : 0;
            String speed=job.speedBps>0 ? " · "+formatRate(job.speedBps) : "";
            showNotification("Downloading: "+job.name,job.total>0 ? percentage+"%"+speed : "Downloading"+speed,percentage,job.total<=0);
        }
    }
    private synchronized void setResult(DownloadJob job,String state,String message) {
        DownloadJob latest=DownloadStore.get(this,job.id);
        if (latest==null || "done".equals(latest.state)) return;
        // A user-requested pause/update must survive a late worker failure.
        if ("paused".equals(latest.state) && !"paused".equals(state)) return;
        latest.state=state;latest.error=message==null?"":message;latest.bytes=partBytes(latest); latest.speedBps=0;
        rateSamples.remove(latest.id);
        DownloadStore.put(this,latest);
        if (!"paused".equals(state)) showNotification("Jin Browser: "+state,latest.error,0,true);
    }
    private Uri saveCompleted(DownloadJob job) throws IOException {
        ContentResolver resolver = getContentResolver();
        boolean usingTree = job.folderUri != null && !job.folderUri.isEmpty();
        Uri target;
        if (usingTree) {
            // The user chose this folder through Android's official folder picker.
            Uri tree = Uri.parse(job.folderUri);
            String documentId = DocumentsContract.getTreeDocumentId(tree);
            Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, documentId);
            target = DocumentsContract.createDocument(resolver, parent,
                    MimeTypes.resolve(job.name, job.mime), job.name);
        } else {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, job.name);
            values.put(MediaStore.Downloads.MIME_TYPE, MimeTypes.resolve(job.name, job.mime));
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/JinBrowser");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            target = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        }
        if (target == null) throw new IOException("Cannot create file at the chosen location. Select another folder.");
        try {
            try (OutputStream out = resolver.openOutputStream(target, "w")) {
                if (out == null) throw new IOException("Cannot write the selected destination");
                merge(job, out);
            }
            long expected = partBytes(job);
            // For providers that report a physical length, verify before publishing.
            try (ParcelFileDescriptor descriptor = resolver.openFileDescriptor(target, "r")) {
                if (descriptor == null) throw new IOException("Cannot reopen saved file");
                long saved = descriptor.getStatSize();
                if (saved >= 0 && saved != expected)
                    throw new IOException("Saved file incomplete: " + saved + " of " + expected + " bytes");
            }
            if (!usingTree) {
                ContentValues publish = new ContentValues();
                publish.put(MediaStore.Downloads.IS_PENDING, 0);
                if (resolver.update(target, publish, null, null) != 1)
                    throw new IOException("Could not publish file to Downloads");
            }
            return target;
        } catch (Exception error) {
            try { resolver.delete(target, null, null); } catch (Exception ignored) { }
            throw error instanceof IOException ? (IOException) error : new IOException("Save failed", error);
        }
    }
    private static String formatRate(long speed) {
        if (speed >= 1048576) return String.format(java.util.Locale.US, "%.1f MB/s", speed / 1048576.0);
        if (speed >= 1024) return String.format(java.util.Locale.US, "%.0f KB/s", speed / 1024.0);
        return speed + " B/s";
    }
    private void merge(DownloadJob job,OutputStream out) throws IOException {
        byte[] buffer=new byte[128*1024];
        for(int index=0;index<job.parts;index++) {
            try (InputStream in=new FileInputStream(DownloadStore.partFile(this,job.id,index))) {
                int n;while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
            }
        }
        out.flush();
    }
    private synchronized void showNotification(String title,String detail,int progress,boolean indeterminate) {
        Intent intent=new Intent(this,DownloadActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending=PendingIntent.getActivity(this,5,intent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title).setContentText(detail).setContentIntent(pending)
                .setOnlyAlertOnce(true).setOngoing(!active.isEmpty())
                .setProgress(100,progress,indeterminate).build();
        if (!serviceForeground) {startForeground(NOTIFICATION_ID,n);serviceForeground=true;}
        else ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,n);
    }
    private synchronized void keepAwake() {
        long now=SystemClock.elapsedRealtime();
        if(wakeLock!=null&&!active.isEmpty()&&now>=nextWakeRenewal){
            try {wakeLock.acquire(10*60*1000L);nextWakeRenewal=now+8*60*1000L;}
            catch(Exception ignored){}
        }
    }
    private synchronized void stopIfIdle() {
        if (active.isEmpty()) {
            if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}
            nextWakeRenewal=0;
            if (serviceForeground) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                serviceForeground=false;
            }
            stopSelf();
        }
    }
    @Override public void onDestroy() {
        for (AtomicBoolean flag:active.values()) flag.set(true);
        taskPool.shutdownNow();
        if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) {return null;}
    private static final class NeedNewLink extends Exception {NeedNewLink(String text){super(text);}}
    private static final class Cancelled extends Exception {}
}
