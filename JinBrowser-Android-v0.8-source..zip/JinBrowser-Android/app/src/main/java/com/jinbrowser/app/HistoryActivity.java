package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;

/** A real searchable, deletable history screen; bookmarks and downloads are not touched. */
public final class HistoryActivity extends Activity {
    private final ArrayList<JSONObject> entries = new ArrayList<>();
    private final HashSet<String> selected = new HashSet<>();
    private LinearLayout list, controls;
    private EditText search;
    private TextView count, selectButton, deleteButton;
    private boolean selecting = false;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        Ui.init(this);setTheme(Ui.DARK?R.style.Theme_JinBrowser_Dark:R.style.Theme_JinBrowser);
        super.onCreate(b);Ui.status(this);
        prefs=getSharedPreferences("browser",MODE_PRIVATE);
        build();
    }
    private void build() {
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Ui.BG);
        setContentView(root);Ui.fitSystemBars(this,root,0,0,0,0);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body=new LinearLayout(this);body.setOrientation(1);
        body.setPadding(Ui.dp(this,20),Ui.dp(this,16),Ui.dp(this,20),Ui.dp(this,24));scroll.addView(body);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);body.addView(head,Ui.layout(this,-1,62));
        TextView back=Ui.text(this,"‹",34,Ui.WHITE,false);back.setGravity(Gravity.CENTER);
        head.addView(back,Ui.layout(this,40,55));back.setOnClickListener(v->onBackPressed());
        TextView title=Ui.text(this,"History",27,Ui.WHITE,true);head.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,55),1));
        selectButton=Ui.text(this,"Select",14,Ui.CYAN,true);selectButton.setGravity(Gravity.CENTER);
        head.addView(selectButton,Ui.layout(this,66,50));selectButton.setOnClickListener(v->{ selecting=!selecting;selected.clear();render();});
        TextView clear=Ui.text(this,"⋯",29,Ui.WHITE,true);clear.setGravity(Gravity.CENTER);clear.setContentDescription("Clear history options");
        head.addView(clear,Ui.layout(this,37,50));clear.setOnClickListener(v->clearMenu());
        TextView hint=Ui.text(this,"Your recent pages · stored on this device",12,Ui.MUTED,false);
        LinearLayout.LayoutParams hl=Ui.layout(this,-1,31);hl.bottomMargin=Ui.dp(this,10);body.addView(hint,hl);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(Ui.WHITE);search.setHintTextColor(Ui.MUTED);
        search.setHint("⌕    Search your history");search.setTextSize(15);search.setBackground(Ui.pill(this,Ui.PANEL,16));
        search.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),0);body.addView(search,Ui.layout(this,-1,56));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}
            public void onTextChanged(CharSequence s,int a,int b,int c){render();}
            public void afterTextChanged(Editable e){}});
        count=Ui.text(this,"",12,Ui.MUTED,false);count.setPadding(Ui.dp(this,4),Ui.dp(this,20),0,Ui.dp(this,7));body.addView(count,Ui.layout(this,-1,51));
        list=new LinearLayout(this);list.setOrientation(1);body.addView(list);
        controls=new LinearLayout(this);controls.setOrientation(1);controls.setPadding(Ui.dp(this,20),Ui.dp(this,8),Ui.dp(this,20),Ui.dp(this,10));
        controls.setBackgroundColor(Ui.BG);root.addView(controls);
        deleteButton=Ui.button(this,"Delete selected",15);deleteButton.setBackground(Ui.pill(this,0xffb7463f,14));
        deleteButton.setTextColor(0xffffffff);controls.addView(deleteButton,Ui.layout(this,-1,52));
        deleteButton.setOnClickListener(v->confirmDeleteSelected());
    }
    @Override protected void onResume(){super.onResume();reload();}
    private void reload(){entries.clear();try{JSONArray all=new JSONArray(prefs.getString("history","[]"));
        for(int i=0;i<all.length();i++){JSONObject e=all.optJSONObject(i);if(e!=null)entries.add(e);}}
        catch(Exception ignored){}render();}
    private void render(){if(list==null)return;list.removeAllViews();
        selectButton.setText(selecting?"Cancel":"Select");controls.setVisibility(selecting?View.VISIBLE:View.GONE);
        deleteButton.setText("Delete selected ("+selected.size()+")");deleteButton.setEnabled(!selected.isEmpty());
        String query=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int visible=0;String section="";
        for(JSONObject e:entries){String url=e.optString("url"),title=e.optString("title","Webpage");
            if(!title.toLowerCase(Locale.ROOT).contains(query)&&!url.toLowerCase(Locale.ROOT).contains(query))continue;
            String day=dayLabel(e.optLong("ts",0));if(!day.equals(section)){section=day;
                TextView marker=Ui.text(this,day.toUpperCase(Locale.ROOT),12,Ui.CYAN,true);
                marker.setLetterSpacing(.08f);marker.setPadding(Ui.dp(this,5),Ui.dp(this,16),0,Ui.dp(this,10));list.addView(marker);}
            visible++;drawRow(e,url,title);
        }
        count.setText(visible+" pages"+(query.isEmpty()?"":" matching your search"));
        if(visible==0){TextView empty=Ui.text(this,query.isEmpty()?"No history yet":"No matching pages",16,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);list.addView(empty,Ui.layout(this,-1,175));}
    }
    private String dayLabel(long ts){if(ts<=0)return"Older";Calendar now=Calendar.getInstance(),when=Calendar.getInstance();when.setTimeInMillis(ts);
        if(now.get(Calendar.YEAR)==when.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==when.get(Calendar.DAY_OF_YEAR))return"Today";
        now.add(Calendar.DAY_OF_YEAR,-1);if(now.get(Calendar.YEAR)==when.get(Calendar.YEAR)&&now.get(Calendar.DAY_OF_YEAR)==when.get(Calendar.DAY_OF_YEAR))return"Yesterday";
        return new SimpleDateFormat("MMMM d, yyyy",Locale.getDefault()).format(ts);
    }
    private void drawRow(JSONObject e,String url,String title){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this,10),Ui.dp(this,9),Ui.dp(this,7),Ui.dp(this,9));row.setBackground(Ui.pill(this,Ui.PANEL,17));
        LinearLayout.LayoutParams rp=Ui.layout(this,-1,-2);rp.bottomMargin=Ui.dp(this,8);list.addView(row,rp);
        boolean marked=selected.contains(url);
        TextView siteIcon=Ui.text(this,selecting?(marked?"☑":"☐"):"↗",selecting?23:19,Ui.CYAN,true);
        siteIcon.setGravity(Gravity.CENTER);row.addView(siteIcon,Ui.layout(this,41,55));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(1);labels.setPadding(Ui.dp(this,5),0,Ui.dp(this,5),0);
        TextView head=Ui.text(this,title.isEmpty()?"Webpage":title,15,Ui.WHITE,true);head.setSingleLine(true);
        head.setEllipsize(android.text.TextUtils.TruncateAt.END);labels.addView(head,Ui.layout(this,-1,25));
        String host;try{host=Uri.parse(url).getHost();}catch(Exception ex){host=url;}
        TextView desc=Ui.text(this,(host==null?url:host)+"  ·  "+
            (e.optLong("ts",0)>0?new SimpleDateFormat("h:mm a",Locale.getDefault()).format(e.optLong("ts")):"Visited"),12,Ui.MUTED,false);
        desc.setSingleLine(true);desc.setEllipsize(android.text.TextUtils.TruncateAt.END);labels.addView(desc,Ui.layout(this,-1,24));
        row.addView(labels,new LinearLayout.LayoutParams(0,Ui.dp(this,55),1));
        TextView more=Ui.text(this,"⋮",24,Ui.MUTED,true);more.setGravity(Gravity.CENTER);
        row.addView(more,Ui.layout(this,37,49));more.setContentDescription("More options for "+title);
        more.setOnClickListener(v->{PopupMenu menu=new PopupMenu(this,more);
            menu.getMenu().add("Open");menu.getMenu().add("Copy link");menu.getMenu().add("Delete this page");
            menu.setOnMenuItemClickListener(item->{String label=item.getTitle().toString();
                if(label.equals("Open"))open(url);else if(label.equals("Copy link")){
                    ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("History",url));
                    Toast.makeText(this,"Link copied",Toast.LENGTH_SHORT).show();}
                else removeUrls(java.util.Collections.singleton(url));return true;});menu.show();});
        row.setOnClickListener(v->{if(selecting){if(!selected.add(url))selected.remove(url);render();}else open(url);});
        row.setOnLongClickListener(v->{if(!selecting){selecting=true;selected.clear();}selected.add(url);render();return true;});
    }
    private void open(String url){try{Intent page=new Intent(Intent.ACTION_VIEW,Uri.parse(url),this,MainActivity.class);
        page.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(page);finish();}
        catch(Exception ex){Toast.makeText(this,"Cannot open this page",Toast.LENGTH_SHORT).show();}}
    private void removeUrls(java.util.Set<String> urls){JSONArray saved=new JSONArray();for(JSONObject e:entries)if(!urls.contains(e.optString("url")))saved.put(e);
        prefs.edit().putString("history",saved.toString()).apply();selected.clear();reload();}
    private void confirmDeleteSelected(){if(selected.isEmpty())return;new AlertDialog.Builder(this).setTitle("Delete selected pages?")
        .setMessage("Remove "+selected.size()+" history entries? Downloaded files are unaffected.")
        .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,n)->{removeUrls(new HashSet<>(selected));selecting=false;render();}).show();}
    private void clearMenu(){String[] options={"Clear last hour","Clear today","Clear all history"};
        new AlertDialog.Builder(this).setTitle("Clear history").setItems(options,(d,n)->{
            String which=options[n];new AlertDialog.Builder(this).setTitle(which+"?")
                .setMessage("Only browsing history is removed. Bookmarks and downloaded files stay saved.")
                .setNegativeButton("Cancel",null).setPositiveButton("Clear",(dialog,button)->{
                    if(n==2){prefs.edit().remove("history").apply();selecting=false;selected.clear();reload();return;}
                    long cutoff;if(n==0)cutoff=System.currentTimeMillis()-3600000L;
                    else{Calendar today=Calendar.getInstance();today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);
                        today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);cutoff=today.getTimeInMillis();}
                    JSONArray remaining=new JSONArray();for(JSONObject item:entries)
                        if(item.optLong("ts",0)<cutoff)remaining.put(item);
                    prefs.edit().putString("history",remaining.toString()).apply();reload();
                }).show();}).show();}
    @Override public void onBackPressed(){if(selecting){selecting=false;selected.clear();render();return;}super.onBackPressed();}
}
