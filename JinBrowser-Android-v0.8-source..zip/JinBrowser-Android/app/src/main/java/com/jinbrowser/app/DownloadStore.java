package com.jinbrowser.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Service-owned persistent job store. All writes happen in the default app process. */
final class DownloadStore {
    private DownloadStore() {}
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("jin_downloads", Context.MODE_PRIVATE); }
    static synchronized List<DownloadJob> all(Context context) {
        ArrayList<DownloadJob> jobs = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(context).getString("jobs", "[]"));
            for (int i=0;i<a.length();i++) jobs.add(DownloadJob.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return jobs;
    }
    static synchronized DownloadJob get(Context context, String id) {
        for (DownloadJob j : all(context)) if (j.id.equals(id)) return j;
        return null;
    }
    static synchronized void put(Context context, DownloadJob job) {
        List<DownloadJob> list = all(context);
        boolean exists = false;
        for (int i=0;i<list.size();i++) if (list.get(i).id.equals(job.id)) { list.set(i, job); exists = true; break; }
        if (!exists) list.add(0, job);
        JSONArray a = new JSONArray();
        try { for (DownloadJob j : list) a.put(j.toJson()); }
        catch (Exception e) { throw new IllegalStateException("Could not serialize download", e); }
        prefs(context).edit().putString("jobs", a.toString()).commit(); // Durable checkpoints.
    }
    static synchronized void delete(Context c, String id) {
        List<DownloadJob> list = all(c);
        list.removeIf(j -> j.id.equals(id));
        JSONArray a = new JSONArray();
        try { for (DownloadJob j : list) a.put(j.toJson()); }
        catch (Exception e) { return; }
        prefs(c).edit().putString("jobs", a.toString()).commit();
        File folder = partsFolder(c, id);
        File[] files = folder.listFiles();
        if (files != null) for (File f : files) f.delete();
        folder.delete();
    }
    static File partsFolder(Context c, String id) {
        File folder = new File(new File(c.getFilesDir(), "segments"), id.replaceAll("[^a-fA-F0-9-]", ""));
        if (!folder.exists() && !folder.mkdirs() && !folder.exists()) throw new IllegalStateException("Could not create parts directory");
        return folder;
    }
    static File partFile(Context c, String id, int index) {
        return new File(partsFolder(c, id), "part-" + index + ".bin");
    }
}
