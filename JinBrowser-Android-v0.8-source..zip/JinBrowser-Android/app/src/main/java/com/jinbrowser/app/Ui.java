package com.jinbrowser.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Single, accessible visual language for the browser shell. */
final class Ui {
    static int BG = 0xffffffff;
    static int PANEL = 0xfff4f6fa;
    static int CYAN = 0xff366b94;
    static int MUTED = 0xff778394;
    static int WHITE = 0xff1c2532; // Ink in both themes, legacy field name.
    static int STROKE = 0xffe8edf1;
    static boolean DARK = false;
    private Ui() {}

    static void init(Context c) {
        String pref = c.getSharedPreferences("browser", Context.MODE_PRIVATE).getString("theme", "system");
        boolean systemDark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        DARK = "dark".equals(pref) || ("system".equals(pref) && systemDark);
        BG = DARK ? 0xff10151c : 0xffffffff;
        PANEL = DARK ? 0xff1e2935 : 0xfff4f6fa;
        CYAN = DARK ? 0xff8ccafe : 0xff366b94;
        MUTED = DARK ? 0xffa7b6c8 : 0xff778394;
        WHITE = DARK ? 0xfff4f7fb : 0xff1c2532;
        STROKE = DARK ? 0xff364453 : 0xffe8edf1;
    }
    static int dp(Context c, float d) { return Math.round(d * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable glass(Context c, int radius) { return pill(c, PANEL, radius); }
    static GradientDrawable pill(Context c, int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(c, radius));
        g.setStroke(dp(c, 1), STROKE);
        return g;
    }
    static TextView text(Context c, String text, int size, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    static TextView button(Context c, String glyph, int size) {
        TextView v = text(c, glyph, size, WHITE, true);
        v.setGravity(Gravity.CENTER); v.setBackground(glass(c, 13));
        v.setClickable(true); return v;
    }
    static LinearLayout.LayoutParams layout(Context c, int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(c, w), h < 0 ? h : dp(c, h));
    }
    static void status(Activity a) {
        init(a);
        a.getWindow().setStatusBarColor(BG); a.getWindow().setNavigationBarColor(BG);
        a.getWindow().getDecorView().setSystemUiVisibility(DARK ? 0 :
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
    static void fitSystemBars(Activity a, View root, int l, int t, int r, int b) {
        if (Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(dp(a,l)+insets.getSystemWindowInsetLeft(),
                    dp(a,t)+insets.getSystemWindowInsetTop(),
                    dp(a,r)+insets.getSystemWindowInsetRight(),
                    dp(a,b)+insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
    }
}
