# No custom shrink rules are needed in the prototype.
