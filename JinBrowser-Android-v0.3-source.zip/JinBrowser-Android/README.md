# Jin Browser v0.3 — source project

An Android **WebView** browser application and a separate native foreground download engine. This is not a new independent rendering engine or a GeckoView migration. The new tab is deliberately simple: one browser address bar and a real Google Search HTML form, plus direct website shortcuts.

## Included in v0.3

- Android System WebView: HTTP(S) navigation, Android Open-with integration, tabs, bookmarks/history, file uploads, private browsing in a separate process, SSL errors blocked, renderer-crash recovery and safer defaults.
- A minimal, non-3D new tab and flat native UI.
- A file-download popup with filename, connection count and **Save to Downloads** or **Choose folder** via Android Storage Access Framework (SAF).
- Foreground downloader with segmented parallel HTTP range transfers when the server supports them; persisted partial chunks, manual pause/resume, replacement URL and sample validation before reusing partial bytes.
- Download cards display progress, **live bytes/s**, and **estimated remaining time** (when total size and current speed are available). Link copy, file opening, and save location labels are exposed.
- Completed files are saved to `Downloads/JinBrowser` via MediaStore, or to the document tree selected by the user; the output is reopened and length-checked when the provider reports its length. The task is marked completed **only after** a successful save and publication. If saving fails, temporary chunks are retained for retry.
- Optional developer menu enables **USB remote WebView inspection** on a trusted desktop (`chrome://inspect/#devices`) and can be turned back off. This does **not** install Chrome Web Store extensions.

## Requirements and limitations

- Android 10+ / API 29+; current target SDK 35.
- Requires the device's up-to-date Android System WebView. Do not use for sensitive credentials until handset tests have passed.
- Android may suspend background tabs; the app cannot guarantee that all tabs will remain live. Long downloads use a foreground service but Android may still terminate it.
- Server-provided expiry, session cookies, CDN source changes, encrypted streaming formats, captive portals and servers without HTTP range support can prevent resuming. A new URL must point to the **same** file, not just an identically named file.
- Download speed is bounded by the connection/server, not artificially increased beyond available bandwidth.
- `content://` providers that do not report a physical file length can be reopened but cannot be fully length-checked without rereading the file.
- WebExtensions/GeckoView integration, built-in mobile element inspector, complete ad-block lists, and sophisticated per-site background battery controls are **not** implemented in this version.

## Build

Open `JinBrowser-Android` in Android Studio (JDK 17, Android SDK 35, Gradle 8.9). For a headless GitHub Actions build, use the included workflow `.github/workflows/android.yml`; it builds `:app:assembleDebug` and uploads `app-debug.apk` on a push to main. A separately provided workflow supports the existing ZIP-based GitHub repository.

Offline source checks (not an APK or handset test):

```bash
python3 tests/project_smoke.py
mkdir -p /tmp/jin-tests
javac -d /tmp/jin-tests app/src/main/java/com/jinbrowser/app/{RangeMath,DownloadProgress}.java tests/{RangeMathTest,DownloadProgressTest}.java
java -cp /tmp/jin-tests com.jinbrowser.app.RangeMathTest
java -cp /tmp/jin-tests com.jinbrowser.app.DownloadProgressTest
```

## Privacy note

Any saved URLs, including signed download links, are stored in the local app download history. Do not copy sensitive URLs to the clipboard on untrusted devices. Private mode isolates the browsing WebView process but downloaded files are still saved outside the private window. Optional remote debugging is **off by default** and is only intended for a trusted development computer.
