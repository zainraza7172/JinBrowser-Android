package com.jinbrowser.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Minimal browser UI toolkit. No glass or animated decoration. */
final class Ui {
    static final int BG = Color.rgb(20, 24, 30);
    static final int PANEL = Color.rgb(38, 43, 52);
    static final int CYAN = Color.rgb(110, 164, 255);
    static final int MUTED = Color.rgb(158, 166, 178);
    static final int WHITE = Color.rgb(243, 246, 250);
    private Ui() {}

    static int dp(Context c, float d) { return Math.round(d * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable glass(Context c, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL);
        g.setCornerRadius(dp(c, radius));
        g.setStroke(dp(c, 1), Color.rgb(59, 64, 74));
        return g;
    }
    static GradientDrawable pill(Context c, int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radius));
        g.setStroke(dp(c, 1), Color.rgb(70, 77, 89));
        return g;
    }
    static TextView text(Context c, String text, int size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    static TextView button(Context c, String glyph, int size) {
        TextView v = text(c, glyph, size, WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(glass(c, 15));
        v.setElevation(0);
        v.setClickable(true);
        return v;
    }
    static LinearLayout.LayoutParams layout(Context c, int wDp, int hDp) {
        return new LinearLayout.LayoutParams(wDp < 0 ? wDp : dp(c, wDp), hDp < 0 ? hDp : dp(c, hDp));
    }
    static void status(Activity activity) {
        activity.getWindow().setStatusBarColor(BG);
        activity.getWindow().setNavigationBarColor(BG);
        activity.getWindow().getDecorView().setSystemUiVisibility(0);
    }
    /** targetSdk 35 enforces edge-to-edge on Android 15+; avoid obscured toolbars and actions. */
    static void fitSystemBars(Activity a, View root, int left, int top, int right, int bottom) {
        if (Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(dp(a,left)+insets.getSystemWindowInsetLeft(),
                    dp(a,top)+insets.getSystemWindowInsetTop(),
                    dp(a,right)+insets.getSystemWindowInsetRight(),
                    dp(a,bottom)+insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
    }
}
