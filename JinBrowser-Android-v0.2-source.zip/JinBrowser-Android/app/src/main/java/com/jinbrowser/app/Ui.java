package com.jinbrowser.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small dependency-free dark / neon / lifted-glass UI toolkit. */
final class Ui {
    static final int BG = Color.rgb(8, 14, 32);
    static final int PANEL = Color.rgb(25, 36, 66);
    static final int CYAN = Color.rgb(77, 222, 244);
    static final int MUTED = Color.rgb(162, 182, 211);
    static final int WHITE = Color.rgb(241, 249, 255);
    private Ui() {}

    static int dp(Context c, float d) { return Math.round(d * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable glass(Context c, int radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] { Color.rgb(41, 58, 104), Color.rgb(20, 33, 61), Color.rgb(15, 28, 48) });
        g.setCornerRadius(dp(c, radius));
        g.setStroke(dp(c, 1), Color.rgb(69, 92, 131));
        return g;
    }
    static GradientDrawable pill(Context c, int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radius));
        g.setStroke(dp(c, 1), Color.rgb(72, 102, 147));
        return g;
    }
    static TextView text(Context c, String text, int size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    static TextView button(Context c, String glyph, int size) {
        TextView v = text(c, glyph, size, WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(glass(c, 15));
        v.setElevation(dp(c, 6));
        v.setClickable(true);
        v.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(.92f).scaleY(.92f).translationZ(dp(c, 1)).setDuration(100).start();
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).translationZ(0).setDuration(160).start();
                    break;
            }
            return false;
        });
        return v;
    }
    static LinearLayout.LayoutParams layout(Context c, int wDp, int hDp) {
        return new LinearLayout.LayoutParams(wDp < 0 ? wDp : dp(c, wDp), hDp < 0 ? hDp : dp(c, hDp));
    }
    static void status(Activity activity) {
        activity.getWindow().setStatusBarColor(BG);
        activity.getWindow().setNavigationBarColor(BG);
        activity.getWindow().getDecorView().setSystemUiVisibility(0);
    }
    /** targetSdk 35 enforces edge-to-edge on Android 15+; avoid obscured toolbars and actions. */
    static void fitSystemBars(Activity a, View root, int left, int top, int right, int bottom) {
        if (Build.VERSION.SDK_INT < 35) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(dp(a,left)+insets.getSystemWindowInsetLeft(),
                    dp(a,top)+insets.getSystemWindowInsetTop(),
                    dp(a,right)+insets.getSystemWindowInsetRight(),
                    dp(a,bottom)+insets.getSystemWindowInsetBottom());
            return insets;
        });
        root.requestApplyInsets();
    }
}
