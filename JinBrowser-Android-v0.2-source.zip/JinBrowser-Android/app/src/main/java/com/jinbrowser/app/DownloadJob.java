package com.jinbrowser.app;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

/** Persisted download metadata. Parts live separately in private app storage. */
final class DownloadJob {
    String id, url, name, userAgent, mime, state = "queued", error = "", outputUri = "";
    String etag = "", lastModified = "";
    long total = -1, bytes = 0, updated = System.currentTimeMillis();
    int parts = 8;
    boolean rangeSupported = false;

    static DownloadJob create(String url, String name, String userAgent, String mime, long length, int connections) {
        DownloadJob j = new DownloadJob();
        j.id = UUID.randomUUID().toString();
        j.url = url;
        j.name = safeName(name);
        j.userAgent = userAgent == null ? "JinBrowser/0.1" : userAgent;
        j.mime = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
        j.total = length > 0 ? length : -1;
        j.parts = Math.max(1, Math.min(16, connections));
        return j;
    }
    static String safeName(String raw) {
        String candidate = raw == null ? "download.bin" : raw.trim()
                .replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").replaceAll("^\\.+", "");
        if (candidate.isEmpty()) return "download.bin";
        return candidate.length() > 140 ? candidate.substring(0, 140) : candidate;
    }
    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("url", url); o.put("name", name);
        o.put("userAgent", userAgent); o.put("mime", mime);
        o.put("state", state); o.put("error", error); o.put("outputUri", outputUri);
        o.put("etag", etag); o.put("lastModified", lastModified);
        o.put("total", total); o.put("bytes", bytes); o.put("updated", updated);
        o.put("parts", parts); o.put("rangeSupported", rangeSupported);
        return o;
    }
    static DownloadJob fromJson(JSONObject o) {
        DownloadJob j = new DownloadJob();
        j.id = o.optString("id"); j.url = o.optString("url"); j.name = o.optString("name");
        j.userAgent = o.optString("userAgent", "JinBrowser/0.1");
        j.mime = o.optString("mime", "application/octet-stream");
        j.state = o.optString("state", "paused"); j.error = o.optString("error");
        j.outputUri = o.optString("outputUri");
        j.etag = o.optString("etag"); j.lastModified = o.optString("lastModified");
        j.total = o.optLong("total", -1); j.bytes = o.optLong("bytes", 0);
        j.updated = o.optLong("updated", System.currentTimeMillis());
        j.parts = o.optInt("parts", 8); j.rangeSupported = o.optBoolean("rangeSupported", false);
        return j;
    }
}
