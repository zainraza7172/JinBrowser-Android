package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;
import java.io.ByteArrayOutputStream;

/** Real browsing happens in Android WebView. The 3D dashboard is an offline HTML asset. */
public class MainActivity extends Activity {
    private static final int MAX_TABS = 8;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private FrameLayout viewport;
    private EditText address;
    private ProgressBar loading;
    private TextView tabCounter, modeTag, back, forward, securityIndicator;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int UPLOAD_REQUEST = 418;
    private static final int NOTIFICATION_REQUEST = 419;

    protected boolean privateMode() { return false; }
    protected void prepareProcess() {}

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        prepareProcess(); // Must run before creating a WebView in the private process.
        Ui.status(this);
        if (privateMode()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        makeChrome();
        // Android 13+ asks separately before displaying ordinary download notifications.
        if (!privateMode() && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        if (!privateMode()) restoreTabs();
        if (tabs.isEmpty()) newTab(null);
        else showTab(Math.max(0, tabs.size() - 1));
    }

    private void makeChrome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(Ui.dp(this, 10), Ui.dp(this, 7), Ui.dp(this, 10), Ui.dp(this, 8));
        setContentView(root);
        Ui.fitSystemBars(this, root, 10, 7, 10, 8);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), Ui.dp(this, 7));
        TextView mark = Ui.text(this, "◈  JIN BROWSER", 12, Ui.WHITE, true);
        mark.setLetterSpacing(.12f);
        brand.addView(mark, new LinearLayout.LayoutParams(0, Ui.dp(this, 27), 1));
        modeTag = Ui.text(this, privateMode() ? "◉ PRIVATE" : "✦ TURBO", 10, privateMode() ? 0xffc4b8ff : Ui.CYAN, true);
        modeTag.setBackground(Ui.pill(this, 0xff1d2a49, 16));
        modeTag.setPadding(Ui.dp(this, 11), 0, Ui.dp(this, 11), 0);
        brand.addView(modeTag, Ui.layout(this, -2, 28));
        root.addView(brand);

        LinearLayout omnibox = new LinearLayout(this);
        omnibox.setGravity(Gravity.CENTER_VERTICAL);
        omnibox.setBackground(Ui.glass(this, 20));
        omnibox.setElevation(Ui.dp(this, 8));
        omnibox.setPadding(Ui.dp(this, 12), Ui.dp(this, 3), Ui.dp(this, 6), Ui.dp(this, 3));
        securityIndicator = Ui.text(this, "◆", 15, Ui.CYAN, true);
        securityIndicator.setContentDescription("Connection status");
        omnibox.addView(securityIndicator, Ui.layout(this, 27, 45));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(0xffa4b3cf);
        address.setTextSize(14);
        address.setHint("Search or enter URL");
        address.setBackgroundColor(Color.TRANSPARENT);
        address.setSelectAllOnFocus(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, action, e) -> {
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH) {
                navigate(address.getText().toString());
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(), 0);
                address.clearFocus();
                return true;
            }
            return false;
        });
        omnibox.addView(address, new LinearLayout.LayoutParams(0, Ui.dp(this, 49), 1));
        TextView go = Ui.button(this, "→", 21);
        go.setOnClickListener(v -> navigate(address.getText().toString()));
        omnibox.addView(go, Ui.layout(this, 40, 41));
        root.addView(omnibox, Ui.layout(this, -1, 57));

        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        loading.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.TRANSPARENT));
        loading.setVisibility(View.INVISIBLE);
        LinearLayout.LayoutParams lp = Ui.layout(this, -1, 2);
        lp.topMargin = Ui.dp(this, 6);
        root.addView(loading, lp);

        viewport = new FrameLayout(this);
        viewport.setBackgroundColor(Ui.BG);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 1);
        vp.topMargin = Ui.dp(this, 1);
        root.addView(viewport, vp);

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6), 0);
        nav.setBackground(Ui.glass(this, 22));
        nav.setElevation(Ui.dp(this, 10));
        back = navButton(nav, "‹", "Back", () -> { if (tab().view.canGoBack()) tab().view.goBack(); });
        forward = navButton(nav, "›", "Forward", () -> { if (tab().view.canGoForward()) tab().view.goForward(); });
        navButton(nav, "⌂", "Home", this::home);
        navButton(nav, "↓", "Downloads", () -> startActivity(new Intent(this, DownloadActivity.class)));
        tabCounter = navButton(nav, "1", "Tabs", this::openTabs);
        navButton(nav, "⋮", "Menu", this::openMenu);
        root.addView(nav, Ui.layout(this, -1, 66));
    }

    private TextView navButton(LinearLayout nav, String glyph, String desc, Runnable click) {
        TextView v = Ui.text(this, glyph, 24, Ui.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setContentDescription(desc);
        v.setOnClickListener(w -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1);
        lp.leftMargin = Ui.dp(this, 2); lp.rightMargin = Ui.dp(this, 2);
        nav.addView(v, lp);
        return v;
    }
    private static class Tab {
        WebView view;
        String title = "New tab";
        String lastUrl = "";
        boolean pinned = false;
    }
    private Tab tab() { return tabs.get(current); }

    private void newTab(String url) {
        if (tabs.size() >= MAX_TABS) {
            Toast.makeText(this, "Maximum " + MAX_TABS + " tabs. Close one first.", Toast.LENGTH_LONG).show();
            return;
        }
        Tab t = new Tab();
        t.view = createWebView(t);
        tabs.add(t);
        showTab(tabs.size() - 1);
        if (url == null || url.isEmpty()) showHome(t);
        else t.view.loadUrl(url);
        persist();
    }
    private WebView createWebView(Tab t) {
        WebView w = new WebView(this);
        w.setBackgroundColor(Ui.BG);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // WebViews stay instantiated across switches, so tab switching doesn't reload pages.
        // A user can also pin an important tab to increase renderer priority.
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        if (privateMode()) {
            // Avoid intentionally writing page resources to the on-disk WebView HTTP cache.
            // This is a privacy improvement, not a guarantee that Android never caches anything.
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setSaveFormData(false);
        }
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("jin".equalsIgnoreCase(uri.getScheme())) {
                    // Only the bundled start page may trigger internal browser commands.
                    if (req.isForMainFrame() && "https://jin.home/".equals(view.getUrl())) handleJinUrl(uri);
                    return true;
                }
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                if (req.isForMainFrame() && ("mailto".equals(scheme) || "tel".equals(scheme))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                // Small optional host list; intentionally not advertised as comprehensive ad blocking.
                String host = req.getUrl().getHost();
                if (host != null && isKnownTracker(host) && !req.isForMainFrame())
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public void onPageFinished(WebView view, String url) {
                t.lastUrl = url != null && url.startsWith("https://jin.home/") ? "" : url;
                if (!privateMode() && url != null && URLUtil.isNetworkUrl(url) && !url.startsWith("https://jin.home/"))
                    saveHistory(url, t.title);
                if (current >= 0 && tab() == t) updateChrome();
                persist();
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError err) {
                handler.cancel(); // Never automatically bypass an invalid certificate.
                Toast.makeText(MainActivity.this, "Blocked: invalid HTTPS certificate", Toast.LENGTH_LONG).show();
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // On memory-limited devices the OS may kill WebView's renderer.
                // Recover the browser shell rather than crashing the entire app.
                int index = tabs.indexOf(t);
                if (index < 0) return true;
                boolean visible = index == current;
                String recovery = t.lastUrl;
                if (view.getParent() instanceof ViewGroup)
                    ((ViewGroup)view.getParent()).removeView(view);
                tabs.remove(index);
                view.destroy();
                if (tabs.isEmpty()) newTab(null);
                else if (visible) showTab(Math.min(index, tabs.size() - 1));
                else if (index < current) current--;
                persist();
                if (visible) new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Tab closed by Android")
                        .setMessage("Android stopped this page to free memory. The browser recovered. Reopen the last URL?")
                        .setNegativeButton("Stay here", null)
                        .setPositiveButton("Reopen", (d, w) -> {
                            if (recovery != null && URLUtil.isNetworkUrl(recovery)) newTab(recovery);
                        }).show();
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                if (current < 0 || tab() != t) return;
                loading.setVisibility(progress == 100 ? View.INVISIBLE : View.VISIBLE);
                loading.setProgress(progress);
            }
            @Override public void onReceivedTitle(WebView v, String title) {
                t.title = title == null || title.trim().isEmpty() ? "New tab" : title;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try { startActivityForResult(params.createIntent(), UPLOAD_REQUEST); return true; }
                catch (Exception e) { uploadCallback.onReceiveValue(null); uploadCallback = null; return false; }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                // Never silently grant camera/microphone to arbitrary websites.
                runOnUiThread(request::deny);
            }
        });
        w.setDownloadListener((url, agent, disposition, mime, size) -> {
            if (privateMode()) {
                new AlertDialog.Builder(this)
                    .setTitle("Private download")
                    .setMessage("Downloaded files and download records remain visible in the normal Downloads screen. Continue?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Continue", (d, x) -> onDownload(url, agent, disposition, mime, size))
                    .show();
            } else onDownload(url, agent, disposition, mime, size);
        });
        return w;
    }
    private static boolean isKnownTracker(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("google-analytics.com") || h.endsWith(".google-analytics.com") ||
                h.equals("doubleclick.net") || h.endsWith(".doubleclick.net") ||
                h.equals("connect.facebook.net");
    }
    private void showTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        viewport.removeAllViews();
        current = index;
        WebView w = tab().view;
        if (w.getParent() instanceof ViewGroup) ((ViewGroup) w.getParent()).removeView(w);
        viewport.addView(w, new FrameLayout.LayoutParams(-1, -1));
        updateChrome();
    }
    private void updateChrome() {
        if (current < 0) return;
        String url = tab().view.getUrl();
        if (!address.hasFocus()) address.setText(url == null || url.startsWith("https://jin.home/") ? "" : url);
        boolean secure = url != null && url.startsWith("https://") && !url.startsWith("https://jin.home/");
        boolean insecure = url != null && url.startsWith("http://");
        securityIndicator.setText(insecure ? "!" : secure ? "◆" : "✧");
        securityIndicator.setTextColor(insecure ? 0xffffae80 : Ui.CYAN);
        securityIndicator.setContentDescription(insecure ? "Unencrypted HTTP connection" :
                secure ? "HTTPS connection (identity not verified)" : "New tab");
        tabCounter.setText(String.valueOf(tabs.size()));
        back.setTextColor(tab().view.canGoBack() ? Ui.CYAN : Ui.MUTED);
        forward.setTextColor(tab().view.canGoForward() ? Ui.CYAN : Ui.MUTED);
    }
    private void showHome(Tab t) {
        try (InputStream stream = getAssets().open("start.html")) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = stream.read(buffer)) != -1) bytes.write(buffer, 0, n);
            t.view.loadDataWithBaseURL("https://jin.home/", bytes.toString("UTF-8"), "text/html", "UTF-8", null);
            t.lastUrl = "";
        } catch (Exception e) { t.view.loadData("<h1>Jin Browser</h1>", "text/html", "UTF-8"); }
    }
    private void home() { showHome(tab()); }
    private void navigate(String raw) {
        String value = raw.trim(); if (value.isEmpty()) return;
        String target;
        if (value.matches("(?i)^https?://.+")) target = value;
        else if (!value.contains(" ") && (value.matches("(?i)^localhost(:\\d+)?(/.*)?$") || value.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:\\d+)?(/.*)?$"))) target = "https://" + value;
        else target = "https://www.google.com/search?q=" + Uri.encode(value);
        if (!URLUtil.isNetworkUrl(target)) return;
        tab().view.loadUrl(target);
        address.clearFocus();
    }
    private void handleJinUrl(Uri uri) {
        switch (uri.getHost() == null ? "" : uri.getHost()) {
            case "search": navigate(uri.getQueryParameter("q") == null ? "" : uri.getQueryParameter("q")); break;
            case "downloads": startActivity(new Intent(this, DownloadActivity.class)); break;
            case "private": if (!privateMode()) startActivity(new Intent(this, PrivateActivity.class));
                else Toast.makeText(this, "Already in private mode", Toast.LENGTH_SHORT).show(); break;
            default: break;
        }
    }
    private void onDownload(String url, String agent, String disposition, String mime, long declaredSize) {
        if (!URLUtil.isNetworkUrl(url)) return;
        String name = URLUtil.guessFileName(url, disposition, mime);
        final EditText rename = new EditText(this);
        rename.setSingleLine(true); rename.setText(name); rename.selectAll();
        rename.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), Ui.dp(this, 18), 0);
        form.addView(Ui.text(this, "File name", 12, Ui.MUTED, true));
        form.addView(rename, Ui.layout(this, -1, 55));
        form.addView(Ui.text(this, "Connections (server permitting)", 12, Ui.MUTED, true));
        Spinner connections = new Spinner(this);
        String[] speeds = {"1 connection", "4 connections", "8 connections", "16 connections"};
        connections.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, speeds));
        connections.setSelection(2);
        form.addView(connections, Ui.layout(this, -1, 50));
        new AlertDialog.Builder(this)
                .setTitle("⚡ Turbo download")
                .setMessage("Download in the background. Update the URL if a link expires. Multi-part mode depends on server support." +
                        (privateMode() ? " Private browsing downloads are saved normally and remain visible." : ""))
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("START", (dialog, which) -> {
                    String filename = DownloadJob.safeName(rename.getText().toString());
                    int[] choices = {1, 4, 8, 16};
                    DownloadJob j = DownloadJob.create(url, filename, agent, mime, declaredSize, choices[connections.getSelectedItemPosition()]);
                    // Cookies travel only with the current service request; they are never saved to disk.
                    String cookies = CookieManager.getInstance().getCookie(url);
                    TurboDownloadService.enqueue(this, j, cookies);
                    Toast.makeText(this, "Download added. Open ↓ to see progress.", Toast.LENGTH_LONG).show();
                }).show();
    }
    private void openTabs() {
        String[] choices = new String[tabs.size() + 2];
        for (int i = 0; i < tabs.size(); i++) choices[i] = (i == current ? "● " : "○ ") + (i + 1) + "  " + tabs.get(i).title;
        choices[tabs.size()] = "+  New tab";
        choices[tabs.size() + 1] = "×  Close current tab";
        new AlertDialog.Builder(this).setTitle("Open tabs").setItems(choices, (d, index) -> {
            if (index == tabs.size()) newTab(null);
            else if (index == tabs.size() + 1) closeTab();
            else showTab(index);
        }).show();
    }
    private void closeTab() {
        if (tabs.size() == 1) { home(); return; }
        Tab old = tabs.remove(current);
        viewport.removeAllViews();
        old.view.destroy();
        showTab(Math.min(current, tabs.size() - 1));
        persist();
    }
    private void openMenu() {
        PopupMenu p = new PopupMenu(this, modeTag);
        p.getMenu().add("New tab").setOnMenuItemClickListener(item -> { newTab(null); return true; });
        if (!privateMode()) p.getMenu().add("New private window").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(this, PrivateActivity.class)); return true;
        });
        p.getMenu().add("Reload page").setOnMenuItemClickListener(item -> { tab().view.reload(); return true; });
        p.getMenu().add(tab().pinned ? "Unpin tab (normal priority)" : "Pin tab (reduce background reloads)")
                .setOnMenuItemClickListener(item -> {
                    Tab active = tab();
                    active.pinned = !active.pinned;
                    active.view.setRendererPriorityPolicy(active.pinned
                            ? WebView.RENDERER_PRIORITY_IMPORTANT : WebView.RENDERER_PRIORITY_BOUND,
                            !active.pinned);
                    Toast.makeText(this, active.pinned
                            ? "Tab pinned. Android can still close it when memory is low."
                            : "Tab returned to normal priority.", Toast.LENGTH_LONG).show();
                    return true;
                });
        if (!privateMode()) {
            p.getMenu().add("☆ Bookmark page").setOnMenuItemClickListener(item -> { addBookmark(); return true; });
            p.getMenu().add("Bookmarks").setOnMenuItemClickListener(item -> { showSaved("bookmarks"); return true; });
            p.getMenu().add("History").setOnMenuItemClickListener(item -> { showSaved("history"); return true; });
            p.getMenu().add("Clear browsing data").setOnMenuItemClickListener(item -> { clearBrowsingData(); return true; });
        }
        p.getMenu().add("Desktop site (toggle)").setOnMenuItemClickListener(item -> {
            WebSettings s = tab().view.getSettings();
            boolean desktop = !s.getUseWideViewPort();
            s.setUseWideViewPort(desktop);
            s.setLoadWithOverviewMode(desktop);
            String agent = s.getUserAgentString().replace("; wv", "");
            s.setUserAgentString(desktop ? agent.replace("Android", "X11; Linux x86_64") : null);
            tab().view.reload(); return true;
        });
        p.getMenu().add("Copy page URL").setOnMenuItemClickListener(item -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("URL", tab().view.getUrl()));
            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show(); return true;
        });
        p.getMenu().add("Real engine details").setOnMenuItemClickListener(item -> {
            PackageInfo engine = WebView.getCurrentWebViewPackage();
            String provider = engine == null ? "Unavailable" : engine.packageName;
            String version = engine == null ? "Unknown" : engine.versionName;
            new AlertDialog.Builder(this)
                    .setTitle("Browser rendering engine")
                    .setMessage("Jin Browser uses the installed Chromium-based Android System WebView.\n\n"
                            + "Provider: " + provider + "\nVersion: " + version
                            + "\nAndroid: " + Build.VERSION.RELEASE
                            + "\n\nThis is an actual web rendering engine, not a simulated webpage. "
                            + "It is not a new engine written from scratch.")
                    .setPositiveButton("OK", null).show();
            return true;
        });
        p.getMenu().add("Battery / background settings").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            return true;
        });
        p.getMenu().add("Downloads").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(this, DownloadActivity.class)); return true;
        });
        p.show();
    }
    private void addBookmark() {
        String url = tab().view.getUrl();
        if (url == null || !URLUtil.isNetworkUrl(url) || url.startsWith("https://jin.home/")) return;
        try {
            JSONArray saved = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("bookmarks", "[]"));
            for (int i=0;i<saved.length();i++) if (url.equals(saved.getJSONObject(i).optString("url"))) {
                Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show(); return;
            }
            JSONObject item = new JSONObject().put("url", url).put("title", tab().title);
            saved.put(item);
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("bookmarks", saved.toString()).apply();
            Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { Toast.makeText(this, "Could not save bookmark", Toast.LENGTH_SHORT).show(); }
    }
    private void saveHistory(String url, String title) {
        try {
            JSONArray previous = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("history", "[]"));
            JSONArray next = new JSONArray();
            next.put(new JSONObject().put("url", url).put("title", title));
            for (int i=0;i<Math.min(previous.length(),199);i++) {
                JSONObject item = previous.optJSONObject(i);
                if (item != null && !url.equals(item.optString("url"))) next.put(item);
            }
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("history", next.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void showSaved(String kind) {
        try {
            JSONArray a = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString(kind, "[]"));
            if (a.length() == 0) { Toast.makeText(this, "No " + kind + " yet", Toast.LENGTH_SHORT).show(); return; }
            String[] labels = new String[a.length()];
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                labels[i]=o.optString("title", "Page") + "\n" + o.optString("url", "");
            }
            new AlertDialog.Builder(this).setTitle(kind.equals("history") ? "Recent history" : "Bookmarks")
                .setItems(labels, (dialog,which)->navigate(a.optJSONObject(which).optString("url")))
                .setNegativeButton("Close", null).show();
        } catch (Exception ignored) { Toast.makeText(this,"Unable to read saved pages",Toast.LENGTH_SHORT).show(); }
    }
    private void clearBrowsingData() {
        new AlertDialog.Builder(this).setTitle("Clear browsing data?")
            .setMessage("Delete normal browsing history, bookmarks, cookies and website storage. Downloads are preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (dialog,which)->{
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                for (Tab t : tabs) { t.view.clearCache(true); t.view.clearHistory(); }
                getSharedPreferences("browser", MODE_PRIVATE).edit().remove("bookmarks").remove("history").apply();
                Toast.makeText(this,"Browsing data cleared",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void persist() {
        if (privateMode() || current < 0) return;
        JSONArray arr = new JSONArray();
        for (Tab t : tabs) arr.put(t.lastUrl == null ? "" : t.lastUrl);
        getSharedPreferences("browser", MODE_PRIVATE).edit().putString("tabs", arr.toString()).apply();
    }
    private void restoreTabs() {
        String raw = getSharedPreferences("browser", MODE_PRIVATE).getString("tabs", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < Math.min(a.length(), MAX_TABS); i++) {
                String url = a.optString(i, "");
                if (!url.isEmpty() && URLUtil.isNetworkUrl(url)) newTab(url);
                else newTab(null);
            }
        } catch (Exception ignored) { tabs.clear(); }
    }
    @Override public void onBackPressed() {
        if (tab().view.canGoBack()) tab().view.goBack();
        else if (tabs.size() > 1) closeTab();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); persist(); /* No pauseTimers: it freezes every WebView. */ }
    @Override protected void onDestroy() {
        for (Tab t : tabs) { if (t.view.getParent() instanceof ViewGroup) ((ViewGroup)t.view.getParent()).removeView(t.view); t.view.destroy(); }
        tabs.clear();
        if (privateMode()) { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); }
        super.onDestroy();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPLOAD_REQUEST && uploadCallback != null) {
            uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            uploadCallback = null;
        }
    }
}
