# Jin Browser — Android beta 0.2

A native Android browser shell built with Java + Android System WebView, a 3D CSS new-tab dashboard, and a separate foreground HTTP download service. The project has **no advertising SDK, analytics SDK, or required account**. It uses only the Android Gradle Plugin (no third-party runtime libraries).

## Features in this source release

- **3D neon/glass new-tab UI:** animated CSS cube and quick-launch tiles. `app/src/main/assets/start.html` is the dashboard and `preview/New_Tab_Preview.html` (included in this archive) shows the mock-up in an ordinary desktop/mobile browser.
- **Basic browser:** address/search box, up to 8 tabs kept as live WebView instances across tab switches, reload, history, bookmarks, desktop-mode toggle and session URL restoration. Android may still kill background tabs if memory is low. **Pin tab** raises renderer priority, but is not a guarantee against reloads.
- **Private window:** separate Android process and separate WebView data directory; no normal history/bookmark persistence and best-effort cookie/storage clearing on close or private-process startup. Private downloads intentionally remain visible in the standard Downloads list (the app warns you). **Not an audited anonymous browser.** The same private process can retain a session while its window is open; temporary files may survive an abrupt crash until the next cleanup.
- **Turbo downloads:** 1, 4, 8 or 16 parallel ranged HTTP connections when the server supports byte ranges; automatic retry, per-part persistent checkpoints, Pause/Resume, manual `New link` replacement (with size and **sample-based**, not cryptographic, verification), direct-URL downloads, foreground notification and Android Downloads folder export. A server that ignores range requests uses a single stream that **cannot be resumed safely**; use Reset to start over. Video streams/DRM are not captured by this version.
- **Baseline protection:** Android Safe Browsing, no automatic HTTPS-error bypass, third-party cookies disallowed, file-access disabled, a **short illustrative tracker host list** (not comprehensive blocking), and no cloud telemetry in project code.

## Build an APK

### Option A — Android Studio

1. Extract `JinBrowser-Android-v0.2-source.zip` on a computer and open the `JinBrowser-Android` directory as an Android Studio project.
2. Install Android SDK Platform **35**, Build Tools **35.0.0**, JDK **17**, and Gradle **8.9**. The archive has **no Gradle wrapper JAR**, because the generation environment was offline. Point Android Studio to a Gradle 8.9 installation or generate a normal wrapper with `gradle wrapper --gradle-version 8.9` if Gradle is already installed.
3. Sync the project and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone to install. Use an Android 10+ device; Android 13+ asks permission for notifications.

### Option B — GitHub Actions (no local SDK)

1. Create a private GitHub repository and upload the **extracted project files** with `.github/workflows/android.yml` in place.
2. Open the repository's **Actions** tab. A push to `main`/`master` starts **Build Jin Browser APK**. Alternatively choose **Run workflow**.
3. After a successful build, download the **JinBrowser-debug-apk** workflow artifact; extract the ZIP to obtain `app-debug.apk`.

The generated debug APK is intended for testing; don't publish a release build without an independent security/privacy review and full device tests. The local environment did not have an Android SDK or network access, so **an APK was not compiled or installed here**. This is real native browser source, not a browser installed on your phone until you build the APK.

## How to use expired-link recovery

1. Start a direct file download from any supported site, or go to **Downloads → Paste a direct download URL**.
2. If it stops with **LINK NEEDED**, visit the original website again and copy a fresh URL for the **same file**.
3. Open **Downloads → New link**, paste the fresh URL, tap **Update**, then **Resume**.
4. The downloader checks the byte count and representative saved bytes against the replacement file. This detects many mismatches but is **not proof of file identity**. For important files, verify the completed file's official SHA-256 checksum.

## Known limitations and roadmap

- A browser cannot take more bandwidth than the ISP, server and Android allow. Higher connection counts help only when the server permits parallel downloading, and may worsen network congestion.
- During the final merge, partial segments and the destination file may coexist; reserve approximately **twice the file size** as free storage for large downloads.
- Android can freeze/kill background WebViews regardless of tab pinning. Foreground download service keeps supported file downloads running subject to Android limits, not every webpage or script.
- HTTP-only sites are allowed but unencrypted; the address bar shows an orange warning indicator.
- Android System WebView lacks some capabilities of a full custom browser engine (extensions, built-in VPN, browser-grade anti-fingerprinting). This version does not claim those capabilities.
- Future versions: richer tab-grid UI, per-site permissions, audio/media controls, encrypted sensitive download metadata, stronger privacy/data deletion, validated HLS support where allowed, and automated end-to-end device tests.

## Basic offline test

```sh
mkdir -p /tmp/jin-test
javac -d /tmp/jin-test app/src/main/java/com/jinbrowser/app/RangeMath.java tests/RangeMathTest.java
java -cp /tmp/jin-test com.jinbrowser.app.RangeMathTest
```

The GitHub workflow runs the offline checks **and** attempts a real Android APK build. See `.github/workflows/android.yml`. This environment can run offline source checks but does **not** contain the Android SDK or a phone emulator, so an installable APK and end-to-end device behavior have **not been verified here**.
