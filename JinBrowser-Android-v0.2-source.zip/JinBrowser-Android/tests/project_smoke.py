"""Offline project-structure checks. These do not replace an Android APK build/device test."""
from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
ns = '{http://schemas.android.com/apk/res/android}'
permissions = {el.attrib[ns + 'name'] for el in manifest.findall('uses-permission')}
for permission in ('INTERNET', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_DATA_SYNC'):
    assert 'android.permission.' + permission in permissions, permission
app = manifest.find('application')
assert app is not None
activities = {el.get(ns + 'name'): el for el in app.findall('activity')}
assert '.MainActivity' in activities and '.PrivateActivity' in activities and '.DownloadActivity' in activities
assert activities['.PrivateActivity'].get(ns + 'process') == ':private'
assert activities['.PrivateActivity'].get(ns + 'exported') == 'false'
services = {el.get(ns + 'name'): el for el in app.findall('service')}
assert services['.TurboDownloadService'].get(ns + 'foregroundServiceType') == 'dataSync'
start = (root/'app/src/main/assets/start.html').read_text()
for token in ('jin://search', 'jin://private', 'jin://downloads', 'perspective:', 'transform-style:preserve-3d'):
    assert token in start, token
main = (root/'app/src/main/java/com/jinbrowser/app/MainActivity.java').read_text()
for token in ('new WebView(this)', 'getCurrentWebViewPackage', 'setDataDirectorySuffix'):
    if token != 'setDataDirectorySuffix': assert token in main, token
private = (root/'app/src/main/java/com/jinbrowser/app/PrivateActivity.java').read_text()
assert 'setDataDirectorySuffix' in private
service = (root/'app/src/main/java/com/jinbrowser/app/TurboDownloadService.java').read_text()
for token in ('bytes=', 'Content-Range', 'verifyExistingParts', 'ACTION_UPDATE', 'ACTION_PAUSE', 'ACTION_RESUME', 'startForeground'):
    assert token in service, token
for xml in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(xml)
print('PASS: manifest, XML resources, 3D dashboard, WebView integration, private process and download feature wiring.')
