# Jin Browser ka APK phone par kaise banayein

**Is ZIP ke andar real Java/Android browser source hai. ZIP ko APK samajh kar install na karein.**

## Sab se asaan free method: GitHub Actions

1. Apne phone par `JinBrowser-Android-v0.2-source.zip` download aur extract karo (Files app ya ZArchiver se).
2. GitHub par **new PRIVATE repository** banao, example `jin-browser-private`.
3. Extracted `JinBrowser-Android` folder ke *andar* wali files/folders repo ke **root** mein upload karo. Repo root mein `app/`, `tests/`, `settings.gradle` aur hidden `.github/workflows/android.yml` hona chahiye. **Sirf ZIP upload karoge to APK nahi banegi.**
4. Repo ki **Actions** tab kholo; workflow ka naam **Build Jin Browser APK** hai. Push ke baad workflow chalta hai, ya `Run workflow` press karo.
5. Build successful ho to us run ki **Artifacts** section se `JinBrowser-debug-apk` download karo. Usme se `app-debug.apk` extract kar ke apne Android 10+ phone par install karo.
6. Unknown sources se installation ki permission sirf apni trusted Files app ko do. APK developer test build hai, independently audited/public release nahi.

## PC / Android Studio

- Project `JinBrowser-Android` Android Studio mein kholo.
- Android SDK 35, build-tools 35.0.0, Java 17 aur Gradle 8.9 install/sync karo.
- `Build > Build APK(s)` se APK banao.

## Important

- Browser Android System WebView ka real Chromium-based renderer use karta hai. Scratch se likha hua independent Chromium fork nahi hai.
- `Keep Alive` sirf renderer priority badhata hai; Android RAM kam hone par tab band/refresh kar sakta hai.
- 1/4/8/16 split download aur refreshed direct URL **sirf compliant HTTP range servers** par safe resume support karte hain.
- Public Play Store release se pehle real phone par functional, privacy aur security testing zaroori hai.

## Sirf phone hai? Termux se poora project GitHub par bhejo

Pehle GitHub par ek **nayi, empty, PRIVATE repo** `JinBrowser-Android` banao, phir phone par Termux mein ye commands chalao. `YOURNAME` aur email apne account ke mutabiq replace karo.

```sh
pkg update && pkg install git unzip
termux-setup-storage
mkdir -p ~/jinbrowser && cd ~/jinbrowser
unzip /sdcard/Download/JinBrowser-Android-v0.2-source.zip
cd JinBrowser-Android
git init -b main
git config user.name "YOURNAME"
git config user.email "you@example.com"
git add .
git commit -m "Jin Browser Android beta"
git remote add origin https://github.com/YOURNAME/JinBrowser-Android.git
git push -u origin main
```

GitHub authentication maange to apne GitHub account ka supported authentication method use karo. Password/token kabhi kisi ko na bhejo ya repo ke andar save na karo. GitHub par **Actions** se APK artifact hasil karo.
