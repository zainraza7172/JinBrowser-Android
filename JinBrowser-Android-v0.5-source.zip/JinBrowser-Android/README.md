# Jin Browser v0.5 — JIN RESUME 71

Android 10+ WebView browser for personal testing. Native Java, no 3D effects.

## Main changes since v0.4
- Unified compact top address/search bar with instant local-history and optional online suggestions, debounced without blocking browsing.
- New minimal branded homepage, theme-aware light/dark styling, no fake about:blank URL or rounded margins around the webpage.
- Native tab switcher with per-tab close button, private window with a separate WebView data directory, user-tapped popup tabs.
- Grouped menu, bookmarks/history, user-selected desktop UA, page sharing, app links and Gmail app handoff when installed.
- HTTP(s) segmented download with checkpointing, current speed and ETA, resume/link replacement after verifying existing segments, Downloads folder publishing.
- Download filenames are tappable; Open sends the persisted content URI, detected MIME and Android read permission. APK opening is separately confirmed.
- Foreground download service for better background transfers, pause and retry, dedicated download picker.

## Boundaries
- Uses Android System WebView; **not** Google Chrome; the browser cannot access Chrome's native extensions or its existing sessions.
- Gmail handoff opens the installed app and can use **its existing signed-in account**; this app never reads Android account tokens. Google may restrict sign-in inside embedded WebView.
- A page in RAM generally stays loaded when the app is minimized, but Android may kill the process; tabs/URLs are persisted for restore.
- Desktop user-agent/viewports improve compatibility but WebView cannot provide all desktop Chrome features.
- No guaranteed or artificially constant transfer speed. Connection counts are user adjustable and automatic byte-range fallback is used when safe.
- No guarantee that downloaded DRM, blob:, streaming-video or servers without HTTP byte-range support can resume.
- Source/unit tests do not substitute Android SDK compilation or device tests. **Do not use for banking or sensitive credentials until audited.**

## Build
Use the top-level `build-apk-v0.5.yml` from the release package in your GitHub repo's `.github/workflows/build-apk.yml` and upload the source ZIP at repo root. A push triggers the build and uploads the debug APK as an artifact.
