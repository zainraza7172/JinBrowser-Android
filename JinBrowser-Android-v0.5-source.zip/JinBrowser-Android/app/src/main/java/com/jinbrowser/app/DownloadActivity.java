package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.os.Build;
import android.provider.Settings;
import android.graphics.Color;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

/** Foreground download dashboard with manual URL renewal and no external dependencies. */
public final class DownloadActivity extends Activity {
    private LinearLayout jobs;
    private ScrollView scroll;
    private static final int PICK_FOLDER = 504;
    private DownloadJob folderJob;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() { render(); handler.postDelayed(this, 1200); }
    };
    @Override public void onCreate(Bundle saved) {
        Ui.init(this);
        setTheme(Ui.DARK ? R.style.Theme_JinBrowser_Dark : R.style.Theme_JinBrowser);
        super.onCreate(saved);
        Ui.status(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 15), Ui.dp(this, 15), Ui.dp(this, 15), 0);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        Ui.fitSystemBars(this, root, 15, 15, 15, 0);
        TextView title=Ui.text(this, "Downloads", 23, Ui.WHITE, true);
        root.addView(title, Ui.layout(this, -1, 46));
        TextView note=Ui.text(this, "Active downloads · Completed files · Resume", 12, Ui.MUTED, false);
        note.setMaxLines(3);
        LinearLayout.LayoutParams subtitle=Ui.layout(this,-1,-2);subtitle.bottomMargin=Ui.dp(this,13);
        root.addView(note,subtitle);
        TextView paste = Ui.button(this, "+  Paste a direct download URL", 13);
        LinearLayout.LayoutParams pasteLp=Ui.layout(this,-1,48);pasteLp.bottomMargin=Ui.dp(this,14);
        root.addView(paste,pasteLp);
        paste.setOnClickListener(v -> addDirectUrl());
        scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        jobs=new LinearLayout(this);
        jobs.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(jobs);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    @Override protected void onResume(){super.onResume();handler.post(refresh);}
    @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
    private void render() {
        int y=scroll.getScrollY();
        jobs.removeAllViews();
        List<DownloadJob> list=DownloadStore.all(this);
        if (list.isEmpty()) {
            TextView empty=Ui.text(this,"No downloads yet. Start one from Jin Browser.",16,Ui.MUTED,false);
            empty.setGravity(Gravity.CENTER);
            jobs.addView(empty,Ui.layout(this,-1,260));return;
        }
        for (DownloadJob j:list) renderJob(j);
        scroll.post(() -> scroll.scrollTo(0,y));
    }
    private void renderJob(DownloadJob j) {
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this,16),Ui.dp(this,13),Ui.dp(this,16),Ui.dp(this,14));
        card.setBackground(Ui.glass(this,16));
        card.setElevation(0);
        LinearLayout.LayoutParams outer=Ui.layout(this,-1,-2);outer.bottomMargin=Ui.dp(this,13);
        jobs.addView(card,outer);
        TextView filename=Ui.text(this,j.name,15,Ui.WHITE,true);filename.setMaxLines(2);
        card.addView(filename);
        if ("done".equals(j.state)) {
            filename.setContentDescription("Open saved file " + j.name);
            filename.setOnClickListener(v -> openFile(j));
        }
        int stateColor = "done".equals(j.state)?0xff18875b:("running".equals(j.state)?Ui.CYAN:("link-needed".equals(j.state)?0xffbc5f20:0xff755baf));
        TextView status=Ui.text(this,j.state.toUpperCase(Locale.ROOT).replace('-',' '),11,stateColor,true);
        LinearLayout.LayoutParams statusLp=Ui.layout(this,-1,30);
        card.addView(status,statusLp);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff283a5b));
        boolean indefinite=j.total<=0 && "running".equals(j.state);
        bar.setIndeterminate(indefinite);
        if (j.total>0)bar.setProgress((int)Math.min(1000,1000.0*j.bytes/j.total));
        card.addView(bar,Ui.layout(this,-1,5));
        String progress=human(j.bytes)+(j.total>0?" / "+human(j.total)+"   ·   "+(int)Math.min(100,100.0*j.bytes/j.total)+"%":"   ·   Total size unknown");
        TextView bytes=Ui.text(this,progress,12,Ui.MUTED,false);
        LinearLayout.LayoutParams bytesLp=Ui.layout(this,-1,35);
        card.addView(bytes,bytesLp);
        String destination = j.folderUri != null && !j.folderUri.isEmpty() ? "Chosen folder" : "Downloads / JinBrowser";
        String rate = "running".equals(j.state) ?
                (j.speedBps > 0 ? human(j.speedBps) + "/s · " + eta(j.total,j.bytes,j.speedBps) + " left" : "Calculating speed…")
                : ("done".equals(j.state) ? "Saved · " + destination : "Save to: " + destination);
        TextView details=Ui.text(this,rate,12,Ui.MUTED,false);
        card.addView(details,Ui.layout(this,-1,30));
        if(j.error!=null&&!j.error.isEmpty()){
            TextView error=Ui.text(this,j.error,11,0xffffb9ae,false);error.setMaxLines(3);
            LinearLayout.LayoutParams errorLp=Ui.layout(this,-1,-2);errorLp.bottomMargin=Ui.dp(this,9);
            card.addView(error,errorLp);
        }
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(actions);
        if("running".equals(j.state)) action(actions,"Ⅱ  Pause",()->command(TurboDownloadService.ACTION_PAUSE,j.id,null));
        if("paused".equals(j.state)||"error".equals(j.state)||"link-needed".equals(j.state)||"queued".equals(j.state)){
            action(actions,"▶ Resume",()->command(TurboDownloadService.ACTION_RESUME,j.id,null));
            action(actions,"↻ New link",()->updateLink(j));
        }
        if("error".equals(j.state)||"link-needed".equals(j.state))
            action(actions,"Reset",()->new AlertDialog.Builder(this).setTitle("Reset partial file?")
                    .setMessage("Discard saved segments and start this file from zero. This cannot be undone.")
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Reset",(d,w)->command(TurboDownloadService.ACTION_RESET,j.id,null)).show());
        if("done".equals(j.state))action(actions,"↗ Open",()->openFile(j));
        if (!"running".equals(j.state)) action(actions,"×",()->new AlertDialog.Builder(this).setTitle("Remove download?")
                .setMessage("Removes this entry and any partial segments. Completed files remain in your Downloads folder.")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Remove",(d,w)->{DownloadStore.delete(this,j.id);render();}).show());
        LinearLayout tools=new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams toolLp=Ui.layout(this,-1,-2); toolLp.topMargin=Ui.dp(this,8);
        card.addView(tools,toolLp);
        action(tools,"Copy link",()->{
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                    .setPrimaryClip(ClipData.newPlainText("Download URL",j.url));
            Toast.makeText(this,"Download link copied",Toast.LENGTH_SHORT).show();
        });
        if (!"done".equals(j.state) && !"running".equals(j.state))
            action(tools,"Change folder",()->chooseFolder(j));
        if ("done".equals(j.state)) action(tools,"Show in Files",()->showFile(j));
    }
    private static String eta(long total,long bytes,long speed) {
        if(total<=0 || speed<=0)return "unknown time";
        long sec=DownloadProgress.etaSeconds(total, bytes, speed);
        if(sec<0)return "unknown time";
        if(sec<60)return sec+" sec";
        if(sec<3600)return (sec/60)+"m "+(sec%60)+"s";
        return (sec/3600)+"h "+((sec%3600)/60)+"m";
    }
    private void chooseFolder(DownloadJob job) {
        folderJob=job;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {startActivityForResult(i,PICK_FOLDER);} catch(Exception error) {
            folderJob=null; Toast.makeText(this,"Folder picker unavailable",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FOLDER){
            DownloadJob job=folderJob;folderJob=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && job!=null){
                try{
                    Uri folder=data.getData();
                    getContentResolver().takePersistableUriPermission(folder,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    job.folderUri=folder.toString(); DownloadStore.put(this,job);
                    render();
                }catch(Exception error){Toast.makeText(this,"Selected folder cannot be saved",Toast.LENGTH_LONG).show();}
            }
        }
    }
    private void action(LinearLayout row,String text,Runnable click){
        TextView b=Ui.text(this,text,11,Ui.WHITE,true);b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.pill(this,Ui.PANEL,13));
        b.setPadding(Ui.dp(this,8),0,Ui.dp(this,8),0);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,Ui.dp(this,40),1);
        lp.rightMargin=Ui.dp(this,5);row.addView(b,lp);b.setOnClickListener(v->click.run());
    }
    private void updateLink(DownloadJob j){
        EditText field=new EditText(this);field.setSingleLine(true);field.setText(j.url);
        field.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI|android.text.InputType.TYPE_CLASS_TEXT);
        field.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Paste new file URL")
                .setMessage("Use a fresh URL for the same file. Jin checks original size and samples your saved segments before resuming.")
                .setView(field).setNegativeButton("Cancel",null)
                .setPositiveButton("Update",(dialog,which)->{
                    String url=field.getText().toString().trim();
                    if(!url.matches("(?i)^https?://.+")){Toast.makeText(this,"Enter an HTTP(S) URL",Toast.LENGTH_SHORT).show();return;}
                    command(TurboDownloadService.ACTION_UPDATE,j.id,url);
                }).show();
    }
    private void addDirectUrl() {
        EditText field=new EditText(this);
        field.setHint("https://example.com/file.zip");
        field.setSingleLine(true);
        field.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI|android.text.InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("New turbo download")
                .setMessage("Paste a direct HTTP(S) file URL. Jin checks whether resumable 4-part downloading is supported.")
                .setView(field).setNegativeButton("Cancel",null)
                .setPositiveButton("Start",(dialog,which)->{
                    String url=field.getText().toString().trim();
                    if (!url.matches("(?i)^https?://.+")) {
                        Toast.makeText(this,"Enter a direct HTTP(S) file URL",Toast.LENGTH_LONG).show();return;
                    }
                    String guessed=URLUtil.guessFileName(url,null,null);
                    DownloadJob job=DownloadJob.create(url,guessed,
                            android.webkit.WebSettings.getDefaultUserAgent(this),
                            "application/octet-stream",-1,4);
                    TurboDownloadService.enqueue(this,job,null);
                    handler.postDelayed(this::render,350);
                }).show();
    }
    private void command(String action,String id,String url){
        TurboDownloadService.send(this,action,id,url,null);
        handler.postDelayed(this::render,250);
    }
    private String actualMime(DownloadJob j) {
        String providerMime = null;
        if (j.outputUri != null && !j.outputUri.isEmpty()) {
            try { providerMime = getContentResolver().getType(Uri.parse(j.outputUri)); }
            catch (Exception ignored) {}
        }
        // The persisted filename is authoritative for common generic server responses,
        // particularly .apk, for which Samsung's chooser needs the package-archive MIME.
        String derived = MimeTypes.resolve(j.name, j.mime);
        return "application/octet-stream".equals(derived)
                ? MimeTypes.resolve(j.name, providerMime) : derived;
    }
    private boolean readable(DownloadJob j) {
        if (j.outputUri == null || j.outputUri.isEmpty()) return false;
        try (android.os.ParcelFileDescriptor fd =
                     getContentResolver().openFileDescriptor(Uri.parse(j.outputUri), "r")) {
            if (fd == null) return false;
            return fd.getStatSize() != 0;
        } catch (Exception e) {
            Toast.makeText(this,"Saved file unavailable. Check Files → Downloads → JinBrowser", Toast.LENGTH_LONG).show();
            return false;
        }
    }
    private void openFile(DownloadJob j) {
        if (!readable(j)) return;
        String mime = actualMime(j);
        if ("application/vnd.android.package-archive".equals(mime)) {
            new AlertDialog.Builder(this).setTitle("Open APK installer?")
                    .setMessage("Only install APK files you trust. Android will ask for installation permission if needed.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Continue", (d, w) -> launchFile(j, mime)).show();
        } else launchFile(j, mime);
    }
    private void launchFile(DownloadJob j, String mime) {
        if ("application/vnd.android.package-archive".equals(mime) &&
                Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this).setTitle("Allow installation from Jin Browser")
                    .setMessage("Enable 'Allow from this source' in Android Settings, then return to Downloads and tap Open again.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open settings", (d,w) -> {
                        Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + getPackageName()));
                        try { startActivity(settings); }
                        catch (Exception ex) { Toast.makeText(this,"Open system Settings → Apps → Jin Browser",Toast.LENGTH_LONG).show(); }
                    }).show();
            return;
        }
        Uri uri = Uri.parse(j.outputUri);
        Intent open = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime);
        open.setClipData(ClipData.newUri(getContentResolver(), j.name, uri));
        open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            if ("application/vnd.android.package-archive".equals(mime)) startActivity(open);
            else startActivity(Intent.createChooser(open, "Open " + j.name));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "No compatible app installed. Use Show in Files.", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Cannot open this file with an installed app. Try Show in Files.", Toast.LENGTH_LONG).show();
        }
    }
    private void showFile(DownloadJob j) {
        if (!readable(j)) return;
        try {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            // DocumentsUI can use the saved document URI as its initial location on many devices.
            if (Build.VERSION.SDK_INT >= 26) picker.putExtra(
                    android.provider.DocumentsContract.EXTRA_INITIAL_URI, Uri.parse(j.outputUri));
            startActivity(picker);
        } catch (Exception error) {
            Toast.makeText(this, "Open My Files → Internal storage → Download → JinBrowser", Toast.LENGTH_LONG).show();
        }
    }
    private static String human(long bytes){
        if(bytes<1024)return bytes+" B";
        if(bytes<1048576)return String.format(Locale.US,"%.1f KB",bytes/1024.0);
        if(bytes<1073741824L)return String.format(Locale.US,"%.1f MB",bytes/1048576.0);
        return String.format(Locale.US,"%.2f GB",bytes/1073741824.0);
    }
}
