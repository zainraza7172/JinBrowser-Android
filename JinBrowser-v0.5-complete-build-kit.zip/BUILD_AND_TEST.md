# Jin Browser v0.5 — JIN RESUME 71

**Status:** Android v0.5 source code and release package prepared; source smoke tests and Java unit tests passed locally. **Android APK compilation and on-device operation are not verified.**

## Installable APK via your existing GitHub repository

Repository: https://github.com/zainraza7172/JinBrowser-Android

1. Upload `JinBrowser-Android-v0.5-source.zip` to the repository **root**, using GitHub's **Add file → Upload files**.
2. Edit `.github/workflows/build-apk.yml`, replacing its **entire contents** with `build-apk-v0.5.yml`, and commit. The workflow's `push` event automatically triggers the v0.5 APK build. If it does not, select **Actions → Build Jin Browser v0.5 APK → Run workflow**.
3. After a green checkmark, open that workflow run and download the `JinBrowser-v0.5-debug-APK` artifact ZIP. Extract `app-debug.apk` and install. The artifact is a debug APK, not a Play Store release.
4. If Android says this is a conflicting signature, first back up bookmarks/download references before uninstalling the old version. Downloaded files in shared storage usually remain, but old app data may be lost.

The ZIP has a top-level `JinBrowser-Android/` folder. It is **source**, not an APK. You must build it first.

## Changes since v0.4

- One compact omnibox: search and web addresses, history suggestions plus optional online Google suggestions; online suggestions are off for private windows.
- Light/dark/system options; quiet branded homepage with Google, YouTube and Gmail shortcut.
- Full-width webpages without an artificial border; native tab switcher with per-tab ×, separate private window, user-triggered popups.
- Background-aware foreground download service, published downloads in `Downloads/JinBrowser` or a chosen Android documents folder, speed/ETA, pause/resume, signed-link replacement with partial content sampling, 1/4/8/16 connections.
- Saved-file MIME inference; handoff of saved content URI and read access to an installed compatible app; APKs require Android's explicit unknown-app setting.
- Per-site desktop user agent (best effort); open page in installed app, mailto/tel app intents and open Gmail (which uses the Gmail app's already-logged-in account if available).
- Live tab views while the app remains alive, URL restoration after Android terminates the app, optional WebView USB debugging.

## What cannot be guaranteed

- Any third-party download server can throttle, reject parallel ranges, revoke links or block resuming. Jin cannot force a fixed Wi-Fi speed.
- Android may kill a browser process when memory is low; URLs can be restored, but an in-page unsaved form cannot always be recovered.
- Google may block authentication within Android WebView. Using the installed Gmail app sidesteps account-token access by Jin Browser; no browser should try to copy Android credentials without authorization.
- Desktop site is user-agent/viewport emulation in Android System WebView, not desktop Chrome.
- Chrome extensions are **not** supported in v0.5; deliberate scope decision.
- Source tests do not prove successful Android compilation, actual background behavior or cross-app opening on Samsung devices. Do not use this debug build for sensitive credentials until security testing is complete.

## Device acceptance checklist

1. Open the new-tab page, type `z`, confirm local/online suggestions, search and navigate; verify Google results fill the screen width.
2. Switch Light, Dark, System from Settings. Open/close tabs and verify a private window does not expose normal cookies/history.
3. Open a website and try Desktop site, then switch back. Use menu to open Gmail app and the page in an installed compatible app.
4. Download a test PDF to `Downloads/JinBrowser`, watch actual speed and ETA, open it directly in a PDF app, then use Show in Files.
5. On a resumable test server, pause/resume a file and verify checksum of the final download. Test replacement links only when pointing to exactly the same bytes.
6. Minimize browser and return, then test Android low-memory process death separately.
