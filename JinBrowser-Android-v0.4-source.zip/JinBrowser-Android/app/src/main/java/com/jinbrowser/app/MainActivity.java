package com.jinbrowser.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.Settings;
import android.view.KeyEvent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;
import java.io.ByteArrayOutputStream;

/** Android WebView browser with a minimal new tab and a native download manager. */
public class MainActivity extends Activity {
    private static final int MAX_TABS = 12;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private FrameLayout viewport;
    private EditText address;
    private ProgressBar loading;
    private TextView tabCounter, modeTag, back, forward, securityIndicator;
    private int lastSelectedTab = 0;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int UPLOAD_REQUEST = 418;
    private static final int NOTIFICATION_REQUEST = 419;
    private static final int DOWNLOAD_FOLDER_REQUEST = 420;
    private DownloadJob pendingFolderJob;
    private String pendingFolderCookie;

    protected boolean privateMode() { return false; }
    protected void prepareProcess() {}

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        prepareProcess(); // Must run before creating a WebView in the private process.
        WebView.setWebContentsDebuggingEnabled(!privateMode() && getSharedPreferences("browser", MODE_PRIVATE).getBoolean("developer_debugging", false));
        Ui.status(this);
        if (privateMode()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        makeChrome();
        // Android 13+ asks separately before displaying ordinary download notifications.
        if (!privateMode() && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        if (!privateMode()) {
            lastSelectedTab = getSharedPreferences("browser", MODE_PRIVATE).getInt("current_tab", 0);
            restoreTabs();
        }
        String launchUrl = externalPage(getIntent());
        if (tabs.isEmpty()) newTab(launchUrl);
        else if (launchUrl == null) showTab(Math.min(Math.max(0, lastSelectedTab), tabs.size() - 1));
        else if (tabs.size() < MAX_TABS) newTab(launchUrl);
        else { showTab(Math.max(0, tabs.size() - 1)); tab().view.loadUrl(launchUrl); }
    }

    /** Full-bleed webpage: no rounded browser frame or outer horizontal margins. */
    private void makeChrome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        Ui.fitSystemBars(this, root, 0, 0, 0, 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(Ui.dp(this, 13), Ui.dp(this, 4), Ui.dp(this, 13), Ui.dp(this, 8));
        header.setBackgroundColor(Ui.BG);
        root.addView(header, Ui.layout(this, -1, -2));

        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = Ui.text(this, privateMode() ? "JIN   /   PRIVATE" : "JIN", 17,
                privateMode() ? 0xff6859b6 : Ui.WHITE, true);
        mark.setLetterSpacing(.11f);
        brand.addView(mark, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1));
        modeTag = Ui.text(this, "⋮", 26, Ui.WHITE, true);
        modeTag.setGravity(Gravity.CENTER);
        modeTag.setBackground(Ui.pill(this, Ui.PANEL, 12));
        modeTag.setContentDescription("Open browser menu");
        modeTag.setOnClickListener(v -> openMenu());
        brand.addView(modeTag, Ui.layout(this, 44, 40));
        header.addView(brand, Ui.layout(this, -1, 44));

        LinearLayout omnibox = new LinearLayout(this);
        omnibox.setGravity(Gravity.CENTER_VERTICAL);
        omnibox.setBackground(Ui.glass(this, 14));
        omnibox.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 4), 0);
        securityIndicator = Ui.text(this, "⌕", 21, Ui.CYAN, true);
        securityIndicator.setGravity(Gravity.CENTER);
        securityIndicator.setContentDescription("Page connection information");
        omnibox.addView(securityIndicator, Ui.layout(this, 28, 47));

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Ui.WHITE);
        address.setHintTextColor(Ui.MUTED);
        address.setTextSize(15);
        address.setHint("Search or enter address");
        address.setBackgroundColor(Color.TRANSPARENT);
        address.setSelectAllOnFocus(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, action, e) -> {
            if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_SEARCH ||
                    (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER && e.getAction() == KeyEvent.ACTION_DOWN)) {
                navigate(address.getText().toString());
                hideKeyboard();
                return true;
            }
            return false;
        });
        omnibox.addView(address, new LinearLayout.LayoutParams(0, Ui.dp(this, 49), 1));
        TextView go = Ui.text(this, "→", 23, Ui.CYAN, true);
        go.setGravity(Gravity.CENTER);
        go.setContentDescription("Go to address or search");
        go.setOnClickListener(v -> { navigate(address.getText().toString()); hideKeyboard(); });
        omnibox.addView(go, Ui.layout(this, 43, 47));
        header.addView(omnibox, Ui.layout(this, -1, 51));

        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.CYAN));
        loading.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.TRANSPARENT));
        loading.setVisibility(View.INVISIBLE);
        root.addView(loading, Ui.layout(this, -1, 2));

        viewport = new FrameLayout(this);
        viewport.setBackgroundColor(Color.WHITE);
        root.addView(viewport, new LinearLayout.LayoutParams(-1, 0, 1));

        View separator = new View(this);
        separator.setBackgroundColor(0xffe7ecf2);
        root.addView(separator, Ui.layout(this, -1, 1));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        nav.setBackgroundColor(Ui.BG);
        back = navButton(nav, "‹", "Back", () -> { if (tab().view.canGoBack()) tab().view.goBack(); });
        forward = navButton(nav, "›", "Forward", () -> { if (tab().view.canGoForward()) tab().view.goForward(); });
        navButton(nav, "⌂", "Home", this::home);
        tabCounter = navButton(nav, "1", "Tabs", this::openTabs);
        root.addView(nav, Ui.layout(this, -1, 53));
    }

    private void hideKeyboard() {
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    private TextView navButton(LinearLayout nav, String glyph, String desc, Runnable click) {
        TextView v = Ui.text(this, glyph, 26, Ui.WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setContentDescription(desc);
        v.setOnClickListener(w -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1);
        nav.addView(v, lp);
        return v;
    }
    private static class Tab {
        WebView view;
        String title = "New tab";
        String lastUrl = "";
        boolean pinned = false;
        boolean desktop = false;
    }
    private Tab tab() { return tabs.get(current); }

    private void newTab(String url) {
        if (tabs.size() >= MAX_TABS) {
            Toast.makeText(this, "Maximum " + MAX_TABS + " tabs. Close one first.", Toast.LENGTH_LONG).show();
            return;
        }
        Tab t = new Tab();
        t.view = createWebView(t);
        tabs.add(t);
        showTab(tabs.size() - 1);
        if (url == null || url.isEmpty()) showHome(t);
        else t.view.loadUrl(url);
        persist();
    }
    private WebView createWebView(Tab t) {
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.WHITE);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // WebViews stay instantiated across switches, so tab switching doesn't reload pages.
        // A user can also pin an important tab to increase renderer priority.
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        if (privateMode()) {
            // Avoid intentionally writing page resources to the on-disk WebView HTTP cache.
            // This is a privacy improvement, not a guarantee that Android never caches anything.
            s.setCacheMode(WebSettings.LOAD_NO_CACHE);
            s.setSaveFormData(false);
        }
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // Android document picker grants temporary access to selected file uploads.
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(true); // Open user-initiated target=_blank links as tabs.
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);
        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("jin".equalsIgnoreCase(uri.getScheme())) {
                    // Only the bundled start page may trigger internal browser commands.
                    if (req.isForMainFrame() && "https://jin.home/".equals(view.getUrl())) handleJinUrl(uri);
                    return true;
                }
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                if (req.isForMainFrame() && ("mailto".equals(scheme) || "tel".equals(scheme))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                // Small optional host list; intentionally not advertised as comprehensive ad blocking.
                String host = req.getUrl().getHost();
                if (host != null && isKnownTracker(host) && !req.isForMainFrame())
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                return null;
            }
            @Override public void onPageFinished(WebView view, String url) {
                t.lastUrl = url != null && url.startsWith("https://jin.home/") ? "" : url;
                if (!privateMode() && url != null && URLUtil.isNetworkUrl(url) && !url.startsWith("https://jin.home/"))
                    saveHistory(url, t.title);
                if (current >= 0 && tab() == t) updateChrome();
                persist();
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError err) {
                handler.cancel(); // Never automatically bypass an invalid certificate.
                Toast.makeText(MainActivity.this, "Blocked: invalid HTTPS certificate", Toast.LENGTH_LONG).show();
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // On memory-limited devices the OS may kill WebView's renderer.
                // Recover the browser shell rather than crashing the entire app.
                int index = tabs.indexOf(t);
                if (index < 0) return true;
                boolean visible = index == current;
                String recovery = t.lastUrl;
                if (view.getParent() instanceof ViewGroup)
                    ((ViewGroup)view.getParent()).removeView(view);
                tabs.remove(index);
                view.destroy();
                if (tabs.isEmpty()) newTab(null);
                else if (visible) showTab(Math.min(index, tabs.size() - 1));
                else if (index < current) current--;
                persist();
                if (visible) new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Tab closed by Android")
                        .setMessage("Android stopped this page to free memory. The browser recovered. Reopen the last URL?")
                        .setNegativeButton("Stay here", null)
                        .setPositiveButton("Reopen", (d, w) -> {
                            if (recovery != null && URLUtil.isNetworkUrl(recovery)) newTab(recovery);
                        }).show();
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean isDialog,
                    boolean isUserGesture, android.os.Message resultMsg) {
                if (!isUserGesture || tabs.size() >= MAX_TABS) return false;
                // The transport needs a fresh WebView; loading the home page first
                // can interfere with window.open / target=_blank navigation.
                Tab popup = new Tab();
                popup.view = createWebView(popup);
                tabs.add(popup);
                showTab(tabs.size() - 1);
                persist();
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup.view);
                resultMsg.sendToTarget();
                return true;
            }
            @Override public void onProgressChanged(WebView view, int progress) {
                if (current < 0 || tab() != t) return;
                loading.setVisibility(progress == 100 ? View.INVISIBLE : View.VISIBLE);
                loading.setProgress(progress);
            }
            @Override public void onReceivedTitle(WebView v, String title) {
                t.title = title == null || title.trim().isEmpty() ? "New tab" : title;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                try { startActivityForResult(params.createIntent(), UPLOAD_REQUEST); return true; }
                catch (Exception e) { uploadCallback.onReceiveValue(null); uploadCallback = null; return false; }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                // Never silently grant camera/microphone to arbitrary websites.
                runOnUiThread(request::deny);
            }
        });
        w.setDownloadListener((url, agent, disposition, mime, size) -> {
            if (privateMode()) {
                new AlertDialog.Builder(this)
                    .setTitle("Private download")
                    .setMessage("Downloaded files and download records remain visible in the normal Downloads screen. Continue?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Continue", (d, x) -> onDownload(url, agent, disposition, mime, size))
                    .show();
            } else onDownload(url, agent, disposition, mime, size);
        });
        return w;
    }
    private static boolean isKnownTracker(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("google-analytics.com") || h.endsWith(".google-analytics.com") ||
                h.equals("doubleclick.net") || h.endsWith(".doubleclick.net") ||
                h.equals("connect.facebook.net");
    }
    private void showTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        viewport.removeAllViews();
        current = index;
        WebView w = tab().view;
        if (w.getParent() instanceof ViewGroup) ((ViewGroup) w.getParent()).removeView(w);
        viewport.addView(w, new FrameLayout.LayoutParams(-1, -1));
        updateChrome();
    }
    private void updateChrome() {
        if (current < 0) return;
        String url = tab().view.getUrl();
        if (!address.hasFocus()) address.setText(url == null || url.startsWith("https://jin.home/") ? "" : url);
        boolean secure = url != null && url.startsWith("https://") && !url.startsWith("https://jin.home/");
        boolean insecure = url != null && url.startsWith("http://");
        securityIndicator.setText(insecure ? "!" : secure ? "◆" : "✧");
        securityIndicator.setTextColor(insecure ? 0xffffae80 : Ui.CYAN);
        securityIndicator.setContentDescription(insecure ? "Unencrypted HTTP connection" :
                secure ? "HTTPS connection (identity not verified)" : "New tab");
        tabCounter.setText("▢" + tabs.size());
        back.setTextColor(tab().view.canGoBack() ? Ui.CYAN : Ui.MUTED);
        forward.setTextColor(tab().view.canGoForward() ? Ui.CYAN : Ui.MUTED);
    }
    private void showHome(Tab t) {
        try (InputStream stream = getAssets().open("start.html")) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = stream.read(buffer)) != -1) bytes.write(buffer, 0, n);
            t.view.loadDataWithBaseURL("https://jin.home/", bytes.toString("UTF-8"), "text/html", "UTF-8", null);
            t.lastUrl = "";
        } catch (Exception e) { t.view.loadData("<h1>Jin Browser</h1>", "text/html", "UTF-8"); }
    }
    private void home() { showHome(tab()); }
    /** Only explicit HTTPS/HTTP links from external intents are opened. */
    private static String externalPage(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return null;
        Uri data = intent.getData();
        if (data == null) return null;
        String scheme = data.getScheme();
        return "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme) ? data.toString() : null;
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = externalPage(intent);
        if (url == null || tabs.isEmpty()) return;
        if (tabs.size() < MAX_TABS) newTab(url);
        else tab().view.loadUrl(url);
    }
    private void navigate(String raw) {
        String value = raw.trim(); if (value.isEmpty()) return;
        String target;
        if (value.matches("(?i)^https?://.+")) target = value;
        else if (!value.contains(" ") && (value.matches("(?i)^localhost(:\\d+)?(/.*)?$") || value.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:\\d+)?(/.*)?$"))) target = "https://" + value;
        else target = "https://www.google.com/search?q=" + Uri.encode(value);
        if (!URLUtil.isNetworkUrl(target)) return;
        tab().view.loadUrl(target);
        address.clearFocus();
    }
    private void handleJinUrl(Uri uri) {
        switch (uri.getHost() == null ? "" : uri.getHost()) {
            case "search": navigate(uri.getQueryParameter("q") == null ? "" : uri.getQueryParameter("q")); break;
            case "downloads": startActivity(new Intent(this, DownloadActivity.class)); break;
            case "private": if (!privateMode()) startActivity(new Intent(this, PrivateActivity.class));
                else Toast.makeText(this, "Already in private mode", Toast.LENGTH_SHORT).show(); break;
            default: break;
        }
    }
    private void onDownload(String url, String agent, String disposition, String mime, long declaredSize) {
        if (!URLUtil.isNetworkUrl(url)) return;
        String name = URLUtil.guessFileName(url, disposition, mime);
        final EditText rename = new EditText(this);
        rename.setSingleLine(true); rename.setText(name); rename.selectAll();
        rename.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), Ui.dp(this, 18), 0);
        form.addView(Ui.text(this, "File name", 12, Ui.MUTED, true));
        form.addView(rename, Ui.layout(this, -1, 55));
        form.addView(Ui.text(this, "Connections (server permitting)", 12, Ui.MUTED, true));
        Spinner connections = new Spinner(this);
        String[] speeds = {"1 connection", "4 connections", "8 connections", "16 connections"};
        connections.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, speeds));
        connections.setSelection(2);
        form.addView(connections, Ui.layout(this, -1, 50));
        form.addView(Ui.text(this, "Location: Downloads / JinBrowser (or choose a folder)", 12, Ui.MUTED, false));
        new AlertDialog.Builder(this)
                .setTitle("Download file")
                .setMessage("Select where to save. If a link expires, paste its replacement in Downloads." +
                        (privateMode() ? " Private browsing downloads remain visible in Downloads." : ""))
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Choose folder", (dialog, which) -> {
                    DownloadJob j = makeDownloadJob(url, agent, mime, declaredSize, rename, connections);
                    pendingFolderJob = j;
                    pendingFolderCookie = CookieManager.getInstance().getCookie(url);
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try { startActivityForResult(pick, DOWNLOAD_FOLDER_REQUEST); }
                    catch (Exception error) { pendingFolderJob=null; pendingFolderCookie=null;
                        Toast.makeText(this,"Folder picker unavailable", Toast.LENGTH_LONG).show(); }
                })
                .setPositiveButton("Save to Downloads", (dialog, which) -> {
                    DownloadJob j = makeDownloadJob(url, agent, mime, declaredSize, rename, connections);
                    TurboDownloadService.enqueue(this, j, CookieManager.getInstance().getCookie(url));
                    startActivity(new Intent(this, DownloadActivity.class));
                }).show();
    }
    private DownloadJob makeDownloadJob(String url, String agent, String mime, long declaredSize,
                                        EditText rename, Spinner connections) {
        int[] options = {1, 4, 8, 16};
        return DownloadJob.create(url, rename.getText().toString(), agent, mime, declaredSize,
                options[Math.max(0, Math.min(3, connections.getSelectedItemPosition()))]);
    }
    /** Individual close buttons, tab switch and new/private actions in one screen. */
    private void openTabs() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        TextView heading = Ui.text(this, privateMode() ? "Private tabs" : "Your tabs", 21, Ui.WHITE, true);
        panel.addView(heading, Ui.layout(this, -1, 48));
        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel)
                .setNegativeButton("Done", null).create();
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView add = Ui.text(this, "+  New tab", 15, Ui.CYAN, true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(Ui.pill(this, Ui.PANEL, 12));
        add.setOnClickListener(v -> { dialog.dismiss(); newTab(null); });
        actions.addView(add, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1));
        TextView privateAction = Ui.text(this, privateMode() ? "Close private" : "◈  Private", 14, Ui.WHITE, true);
        privateAction.setGravity(Gravity.CENTER);
        privateAction.setOnClickListener(v -> {
            dialog.dismiss();
            if (privateMode()) finish();
            else startActivity(new Intent(this, PrivateActivity.class));
        });
        actions.addView(privateAction, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1));
        panel.addView(actions, Ui.layout(this, -1, 50));
        View line = new View(this); line.setBackgroundColor(0xffe8ebf2);
        panel.addView(line, Ui.layout(this, -1, 1));
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        panel.addView(scroll, Ui.layout(this, -1, -2));
        for (int i=0; i<tabs.size(); i++) {
            final int index = i;
            Tab item = tabs.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
            row.setBackground(Ui.pill(this, index == current ? 0xffeaf2ff : Ui.BG, 10));
            LinearLayout.LayoutParams rp = Ui.layout(this, -1, 65); rp.topMargin=Ui.dp(this,7);
            rows.addView(row, rp);
            TextView title = Ui.text(this, item.title, 14, Ui.WHITE, true);
            title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.addView(title, Ui.layout(this,-1,27));
            TextView url = Ui.text(this, item.lastUrl == null || item.lastUrl.isEmpty() ? "New tab" : item.lastUrl,
                    11, Ui.MUTED, false);
            url.setSingleLine(true); url.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(url, Ui.layout(this,-1,22));
            row.addView(info, new LinearLayout.LayoutParams(0,Ui.dp(this,52),1));
            info.setOnClickListener(v -> { showTab(index); dialog.dismiss(); });
            TextView close = Ui.text(this, "×", 27, Ui.MUTED, false);
            close.setGravity(Gravity.CENTER);
            close.setContentDescription("Close tab: " + item.title);
            close.setOnClickListener(v -> { dialog.dismiss(); closeTabAt(index); openTabs(); });
            row.addView(close,Ui.layout(this, 47, 50));
        }
        dialog.show();
    }

    private void closeTabAt(int index) {
        if (index < 0 || index >= tabs.size()) return;
        if (tabs.size() == 1) { showTab(0); home(); return; }
        Tab old = tabs.remove(index);
        if (old.view.getParent() instanceof ViewGroup)
            ((ViewGroup) old.view.getParent()).removeView(old.view);
        old.view.destroy();
        if (index < current) current--;
        else if (index == current) current = Math.min(index, tabs.size()-1);
        showTab(current);
        persist();
    }
    private void closeTab() {
        closeTabAt(current);
    }
    private void openMenu() {
        PopupMenu p = new PopupMenu(this, modeTag);
        p.getMenu().add("＋  New tab").setOnMenuItemClickListener(item -> { newTab(null); return true; });
        p.getMenu().add(privateMode() ? "◈  Close private window" : "◈  New private window")
                .setOnMenuItemClickListener(item -> {
                    if (privateMode()) finish();
                    else startActivity(new Intent(this, PrivateActivity.class));
                    return true;
                });
        p.getMenu().add("▢  Tabs").setOnMenuItemClickListener(item -> { openTabs(); return true; });
        p.getMenu().add("↓  Downloads").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(this, DownloadActivity.class)); return true;
        });
        android.view.SubMenu pages = p.getMenu().addSubMenu("Page tools");
        pages.add("Reload / Stop").setOnMenuItemClickListener(item -> {
            if (tab().view.getProgress() < 100) tab().view.stopLoading();
            else tab().view.reload(); return true;
        });
        pages.add("Find in page").setOnMenuItemClickListener(item -> {
            EditText query = new EditText(this); query.setSingleLine(true);
            query.setHint("Find text");
            new AlertDialog.Builder(this).setTitle("Find in page").setView(query)
                .setPositiveButton("Find", (d, x) -> {
                    tab().view.findAllAsync(query.getText().toString());
                    Toast.makeText(this, "Matching text highlighted", Toast.LENGTH_SHORT).show();
                }).setNeutralButton("Clear", (d,x) -> tab().view.clearMatches())
                .setNegativeButton("Cancel", null).show();
            return true;
        });
        pages.add("Desktop site").setCheckable(true).setChecked(tab().desktop)
                .setOnMenuItemClickListener(item -> {
                    Tab t=tab(); t.desktop = !t.desktop;
                    WebSettings settings = t.view.getSettings();
                    settings.setUseWideViewPort(t.desktop);
                    settings.setLoadWithOverviewMode(t.desktop);
                    settings.setUserAgentString(t.desktop
                            ? WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Android", "X11; Linux x86_64")
                            : null);
                    t.view.reload(); return true;
                });
        pages.add("Share page").setOnMenuItemClickListener(item -> {
            String url=tab().view.getUrl();
            if (url == null || !URLUtil.isNetworkUrl(url)) return true;
            Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,url);
            startActivity(Intent.createChooser(share,"Share page"));return true;
        });
        pages.add("Copy page URL").setOnMenuItemClickListener(item -> {
            String url=tab().view.getUrl();
            if (url != null && URLUtil.isNetworkUrl(url)) {
                ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                        .setPrimaryClip(ClipData.newPlainText("Page URL",url));
                Toast.makeText(this,"Link copied",Toast.LENGTH_SHORT).show();
            } return true;
        });
        android.view.SubMenu library = p.getMenu().addSubMenu("Library");
        if (!privateMode()) {
            library.add("☆  Bookmark page").setOnMenuItemClickListener(item -> { addBookmark(); return true; });
            library.add("Bookmarks").setOnMenuItemClickListener(item -> { showSaved("bookmarks"); return true; });
            library.add("History").setOnMenuItemClickListener(item -> { showSaved("history"); return true; });
        }
        library.add("Downloads").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(this, DownloadActivity.class));return true;
        });
        android.view.SubMenu settings = p.getMenu().addSubMenu("Settings & tools");
        settings.add("Developer options").setOnMenuItemClickListener(item -> { showDeveloperOptions(); return true; });
        settings.add("Engine details").setOnMenuItemClickListener(item -> {
            PackageInfo engine = WebView.getCurrentWebViewPackage();
            String provider = engine == null ? "Unavailable" : engine.packageName;
            String version = engine == null ? "Unknown" : engine.versionName;
            new AlertDialog.Builder(this).setTitle("Rendering engine")
                .setMessage("Jin Browser runs on Android System WebView (Chromium).\n\nProvider: "
                    + provider + "\nVersion: " + version
                    + "\n\nChrome Web Store extensions are not supported by this engine.")
                .setPositiveButton("OK",null).show(); return true;
        });
        settings.add("Battery / background access").setOnMenuItemClickListener(item -> {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:"+getPackageName())));return true;
        });
        if (!privateMode()) settings.add("Clear browsing data").setOnMenuItemClickListener(item -> {
            clearBrowsingData();return true;
        });
        p.show();
    }
    private void showDeveloperOptions() {
        if (privateMode()) {
            new AlertDialog.Builder(this).setTitle("Developer options")
                    .setMessage("Remote WebView inspection is disabled in private mode.")
                    .setPositiveButton("OK", null).show(); return;
        }
        boolean active = getSharedPreferences("browser", MODE_PRIVATE).getBoolean("developer_debugging", false);
        new AlertDialog.Builder(this).setTitle("Developer options")
                .setMessage("Remote WebView debugging is " + (active ? "ON" : "OFF") +
                        ".\n\nWith USB debugging enabled, connect your Android phone to a trusted PC and visit chrome://inspect/#devices in desktop Chrome. " +
                        "This is not Chrome extension support or a built-in mobile inspector. " +
                        "Turn debugging off after use; a connected computer may inspect opened pages.")
                .setNegativeButton("Close", null)
                .setNeutralButton("Turn OFF", (d, w) -> setDeveloperDebugging(false))
                .setPositiveButton("Turn ON", (d, w) -> setDeveloperDebugging(true)).show();
    }
    private void setDeveloperDebugging(boolean enabled) {
        getSharedPreferences("browser", MODE_PRIVATE).edit().putBoolean("developer_debugging", enabled).apply();
        WebView.setWebContentsDebuggingEnabled(enabled);
        Toast.makeText(this, enabled ? "Remote inspection enabled" : "Remote inspection disabled", Toast.LENGTH_SHORT).show();
    }
    private void addBookmark() {
        String url = tab().view.getUrl();
        if (url == null || !URLUtil.isNetworkUrl(url) || url.startsWith("https://jin.home/")) return;
        try {
            JSONArray saved = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("bookmarks", "[]"));
            for (int i=0;i<saved.length();i++) if (url.equals(saved.getJSONObject(i).optString("url"))) {
                Toast.makeText(this, "Already bookmarked", Toast.LENGTH_SHORT).show(); return;
            }
            JSONObject item = new JSONObject().put("url", url).put("title", tab().title);
            saved.put(item);
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("bookmarks", saved.toString()).apply();
            Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { Toast.makeText(this, "Could not save bookmark", Toast.LENGTH_SHORT).show(); }
    }
    private void saveHistory(String url, String title) {
        try {
            JSONArray previous = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString("history", "[]"));
            JSONArray next = new JSONArray();
            next.put(new JSONObject().put("url", url).put("title", title));
            for (int i=0;i<Math.min(previous.length(),199);i++) {
                JSONObject item = previous.optJSONObject(i);
                if (item != null && !url.equals(item.optString("url"))) next.put(item);
            }
            getSharedPreferences("browser", MODE_PRIVATE).edit().putString("history", next.toString()).apply();
        } catch (Exception ignored) {}
    }
    private void showSaved(String kind) {
        try {
            JSONArray a = new JSONArray(getSharedPreferences("browser", MODE_PRIVATE).getString(kind, "[]"));
            if (a.length() == 0) { Toast.makeText(this, "No " + kind + " yet", Toast.LENGTH_SHORT).show(); return; }
            String[] labels = new String[a.length()];
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                labels[i]=o.optString("title", "Page") + "\n" + o.optString("url", "");
            }
            new AlertDialog.Builder(this).setTitle(kind.equals("history") ? "Recent history" : "Bookmarks")
                .setItems(labels, (dialog,which)->navigate(a.optJSONObject(which).optString("url")))
                .setNegativeButton("Close", null).show();
        } catch (Exception ignored) { Toast.makeText(this,"Unable to read saved pages",Toast.LENGTH_SHORT).show(); }
    }
    private void clearBrowsingData() {
        new AlertDialog.Builder(this).setTitle("Clear browsing data?")
            .setMessage("Delete normal browsing history, bookmarks, cookies and website storage. Downloads are preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (dialog,which)->{
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                for (Tab t : tabs) { t.view.clearCache(true); t.view.clearHistory(); }
                getSharedPreferences("browser", MODE_PRIVATE).edit().remove("bookmarks").remove("history").apply();
                Toast.makeText(this,"Browsing data cleared",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void persist() {
        if (privateMode() || current < 0) return;
        JSONArray arr = new JSONArray();
        for (Tab t : tabs) arr.put(t.lastUrl == null ? "" : t.lastUrl);
        getSharedPreferences("browser", MODE_PRIVATE).edit().putString("tabs", arr.toString())
                .putInt("current_tab", current).apply();
    }
    private void restoreTabs() {
        String raw = getSharedPreferences("browser", MODE_PRIVATE).getString("tabs", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < Math.min(a.length(), MAX_TABS); i++) {
                String url = a.optString(i, "");
                if (!url.isEmpty() && URLUtil.isNetworkUrl(url)) newTab(url);
                else newTab(null);
            }
        } catch (Exception ignored) { tabs.clear(); }
    }
    @Override public void onBackPressed() {
        if (tab().view.canGoBack()) tab().view.goBack();
        else if (tabs.size() > 1) closeTab();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); persist(); /* No pauseTimers: it freezes every WebView. */ }
    @Override protected void onDestroy() {
        for (Tab t : tabs) { if (t.view.getParent() instanceof ViewGroup) ((ViewGroup)t.view.getParent()).removeView(t.view); t.view.destroy(); }
        tabs.clear();
        if (privateMode()) { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData(); }
        super.onDestroy();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DOWNLOAD_FOLDER_REQUEST) {
            DownloadJob job = pendingFolderJob;
            String cookie = pendingFolderCookie;
            pendingFolderJob = null; pendingFolderCookie = null;
            if (resultCode == RESULT_OK && job != null && data != null && data.getData() != null) {
                Uri folder = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(folder,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    job.folderUri = folder.toString();
                    TurboDownloadService.enqueue(this, job, cookie);
                    startActivity(new Intent(this, DownloadActivity.class));
                } catch (Exception error) {
                    Toast.makeText(this,"Cannot access selected folder. Choose Downloads instead.",Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == UPLOAD_REQUEST && uploadCallback != null) {
            uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            uploadCallback = null;
        }
    }
}
