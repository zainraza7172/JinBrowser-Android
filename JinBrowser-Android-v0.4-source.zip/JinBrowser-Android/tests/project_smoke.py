"""Structural assertions for offline CI; requires Android SDK build before release."""
from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parents[1]
ns = '{http://schemas.android.com/apk/res/android}'
manifest = ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
permissions = {el.attrib[ns+'name'] for el in manifest.findall('uses-permission')}
for permission in ('INTERNET','FOREGROUND_SERVICE','FOREGROUND_SERVICE_DATA_SYNC'):
    assert 'android.permission.' + permission in permissions, permission
app = manifest.find('application')
activities = {el.get(ns+'name'):el for el in app.findall('activity')}
for name in ('.MainActivity','.PrivateActivity','.DownloadActivity'):
    assert name in activities, name
assert activities['.PrivateActivity'].get(ns+'process')==':private'
assert activities['.PrivateActivity'].get(ns+'exported')=='false'
assert activities['.MainActivity'].get(ns+'launchMode')=='singleTop'
assert any(x.get(ns+'name')=='android.intent.action.VIEW' for x in activities['.MainActivity'].findall('intent-filter/action'))
services = {el.get(ns+'name'):el for el in app.findall('service')}
assert services['.TurboDownloadService'].get(ns+'foregroundServiceType')=='dataSync'
for xml in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(xml)
start=(root/'app/src/main/assets/start.html').read_text()
assert 'https://www.google.com/search' in start and '<form' in start
assert 'preserve-3d' not in start and '⚡' not in start
main=(root/'app/src/main/java/com/jinbrowser/app/MainActivity.java').read_text()
for token in ('new WebView(this)','setDownloadListener','ACTION_OPEN_DOCUMENT_TREE','setWebContentsDebuggingEnabled','onShowFileChooser','EditorInfo.IME_ACTION_GO','Copy page URL','startActivity(new Intent(this, DownloadActivity.class))','onNewIntent(Intent intent)','externalPage(Intent intent)'):
    assert token in main, token
download=(root/'app/src/main/java/com/jinbrowser/app/DownloadActivity.java').read_text()
for token in ('speedBps','etaSeconds','Copy link','Change folder','ACTION_OPEN_DOCUMENT_TREE','New link'):
    assert token in download, token
service=(root/'app/src/main/java/com/jinbrowser/app/TurboDownloadService.java').read_text()
for token in ('Content-Range','verifyExistingParts','ACTION_UPDATE','ACTION_PAUSE','ACTION_RESUME','startForeground','MediaStore.Downloads.IS_PENDING','DocumentsContract.createDocument','openFileDescriptor','formatRate'):
    assert token in service, token
job=(root/'app/src/main/java/com/jinbrowser/app/DownloadJob.java').read_text()
for token in ('folderUri','speedBps'):
    assert token in job, token
assert 'setSupportMultipleWindows(true)' in main and 'onCreateWindow' in main
assert 'setAllowContentAccess(true)' in main
assert 'closeTabAt(index)' in main and 'lastSelectedTab' in main
assert 'Ui.fitSystemBars(this, root, 0, 0, 0, 0)' in main
assert 'setClipData(ClipData.newUri' in download and 'showFile(DownloadJob' in download
assert 'ACTION_OPEN_DOCUMENT' in download
print('PASS: v0.4 manifest, full-bleed navigation, native tabs, popup tabs, document uploads, saved file opening and resume architecture.')
