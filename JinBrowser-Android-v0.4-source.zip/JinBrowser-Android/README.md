# Jin Browser v0.4 — JIN RESUME 71

## Scope delivered in source
- Flat edge-to-edge browsing view: no outer margins or decorative webpage border.
- Branded clean home page and real omnibox search/URL routing.
- Bottom back, forward, home and tab switcher; top-right grouped menu.
- Native per-tab close button, new tab and separate private window.
- User-triggered target=_blank tabs and Android document uploads.
- Download manager with source v0.3 parallel HTTP ranges, rate/ETA, pause, replacement link, SAF folder selection and MediaStore Downloads publishing.
- Open downloaded file with proper content URI grant, detected MIME and separate Show in Files action.
- Optional remote WebView debugging, *not* desktop Chrome extension support.

## Honest limitations
- This version uses Android System WebView / Chromium, not a forked Chromium browser engine.
- Chrome extension install is not supported; future engine decision needed.
- Download speeds depend on network and server; neither 8 MB/s nor background execution under all OS conditions can be guaranteed.
- WebView blob: and DRM-protected stream downloads are not supported.
- Android SDK compilation and real-device QA must be performed before release. Debug APK is for testing.

## Test on device
1. Search text and type explicit URL in omnibox; check fullscreen webpage with no side card border.
2. Open a link with target=_blank, switch tabs and close each using its own ×.
3. Open private window then close it and return to normal tabs.
4. Upload a small file with Android document picker.
5. Download a PDF: verify MediaStore Downloads/JinBrowser; tap Open and Show in Files.
6. Pause, resume and replace URL with a different verified link to same file.
7. Check HTTP/HTTPS navigation, site compatibility, crash restore, low-memory tab behavior.
